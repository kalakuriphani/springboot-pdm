package com.hsbc.pdm.controller;

import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.productservice.model.ProductTemplate;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.UUID;

import static com.hsbc.pdm.controllers.RestExceptionHandler.ErrorModel;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ProductTemplateControllerTest extends AbstractControllerTest {

    private static final String PDM_TOKEN = UUID.randomUUID().toString();

    @Test
    public void get_by_product_type_should_return_single_product_template() {
        for (ProductTypeEnum productType : ProductTypeEnum.values()) {
            get_by_product_type_should_return_single_product_template(productType);
        }
    }

    private void get_by_product_type_should_return_single_product_template(ProductTypeEnum productType) {
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/product-template/{type}"));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(productType.name());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.get(uri), PDM_TOKEN).build();

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", "ROLE-1");

        // call method under test
        ResponseEntity<ProductTemplate> response = template.exchange(request, ProductTemplate.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());

        ProductTemplate actual = response.getBody();
        Assert.assertEquals(productType.name(), actual.getProductType());
        Assert.assertNotNull(actual.getSchema());
        Assert.assertNotNull(actual.getTitle());
    }

    @Test
    public void get_should_return_a_list_of_product_types() {
        URI uri = UriComponentsBuilder.fromHttpUrl(url("/product-template")).build().toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.get(uri), PDM_TOKEN).build();

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", "ROLE-1");

        // call method under test
        ResponseEntity<List<ProductTemplate>> response = template.exchange(request, new ParameterizedTypeReference<List<ProductTemplate>>() {});

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(ProductTypeEnum.values().length, response.getBody().size());

        for (ProductTemplate productTemplate : response.getBody()) {
            Assert.assertNotNull(productTemplate.getProductType());
            ProductTypeEnum.valueOf(productTemplate.getProductType()); // thi will throw an exception for an invalid value
            Assert.assertNotNull(productTemplate.getSchema());
            Assert.assertNotNull(productTemplate.getTitle());
        }
    }

    @Test
    public void get_by_product_type_when_ProductType_is_invalid_should_return_404() {
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/product-template/{type}"));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand("INVALID-PRODUCT-TYPE");
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.get(uri), PDM_TOKEN).build();

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", "ROLE-1");

        // call method under test
        template.setErrorHandler(new DoNothingResponseErrorHandler());
        ResponseEntity<ErrorModel> response = template.exchange(request, ErrorModel.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Product type INVALID-PRODUCT-TYPE does not exist", response.getBody().getFriendlyMessage());
        assertNotNull(response.getBody().getStackTrace());
    }
}
