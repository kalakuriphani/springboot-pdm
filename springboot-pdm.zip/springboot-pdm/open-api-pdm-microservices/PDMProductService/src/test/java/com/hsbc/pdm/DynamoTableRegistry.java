package com.hsbc.pdm;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

import static com.hsbc.pdm.entities.dynamo.DynamoProduct.ID_FIELD;
import static com.hsbc.pdm.entities.dynamo.DynamoProduct.PRODUCT_TYPE_INTERNAL_FIELD;
import static com.hsbc.pdm.entities.dynamo.DynamoProductAudit.TIMESTAMP_FIELD;
import static com.hsbc.pdm.entities.dynamo.DynamoProductAudit.USERNAME_FIELD;

/**
 * Created by 44023148 on 06/03/2017.
 */
@Component
public class DynamoTableRegistry {

    protected static final String PDM_PRODUCTS_TABLE = "pdm-products";
    protected static final String PDM_PRODUCT_AUDITS_TABLE = "pdm-product-audits";


    @Autowired
    private Environment environment;

    @Value("${aws.dynamo.signingRegion}")
    private String signingRegion;

    protected AmazonDynamoDB dynamoClient;

    private AWSCredentials awsCredentials;

    @PostConstruct
    public void doPostConstruct() {
        AmazonDynamoDBClientBuilder clientBuilder = AmazonDynamoDBClientBuilder.standard();
        clientBuilder.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(getLocalServiceEndpoint(), signingRegion));
        awsCredentials = new BasicAWSCredentials("dummy-access-key", "dummy-secret-access-key");
        dynamoClient = clientBuilder
                .withCredentials(getAWSCredentialsProvider())
                .build();
    }


    public void createProductsTable() {
        ArrayList<AttributeDefinition> attributeDefinitions= new ArrayList<>();
        attributeDefinitions.add(new AttributeDefinition().withAttributeName(PRODUCT_TYPE_INTERNAL_FIELD).withAttributeType("S"));
        attributeDefinitions.add(new AttributeDefinition().withAttributeName(ID_FIELD).withAttributeType("S"));

        ArrayList<KeySchemaElement> keySchema = new ArrayList<>();
        keySchema.add(new KeySchemaElement().withAttributeName(PRODUCT_TYPE_INTERNAL_FIELD).withKeyType(KeyType.HASH));
        keySchema.add(new KeySchemaElement().withAttributeName(ID_FIELD).withKeyType(KeyType.RANGE));

        CreateTableRequest request = new CreateTableRequest()
                .withTableName(PDM_PRODUCTS_TABLE)
                .withKeySchema(keySchema)
                .withAttributeDefinitions(attributeDefinitions)
                .withProvisionedThroughput(new ProvisionedThroughput()
                        .withReadCapacityUnits(5L)
                        .withWriteCapacityUnits(5L));

        dynamoClient.createTable(request);
    }

    public void createProductAuditsTable() {
        ArrayList<AttributeDefinition> attributeDefinitions= new ArrayList<>();
        attributeDefinitions.add(new AttributeDefinition().withAttributeName(USERNAME_FIELD).withAttributeType("S"));
        attributeDefinitions.add(new AttributeDefinition().withAttributeName(TIMESTAMP_FIELD).withAttributeType("S"));

        ArrayList<KeySchemaElement> keySchema = new ArrayList<>();
        keySchema.add(new KeySchemaElement().withAttributeName(USERNAME_FIELD).withKeyType(KeyType.HASH));
        keySchema.add(new KeySchemaElement().withAttributeName(TIMESTAMP_FIELD).withKeyType(KeyType.RANGE));

        CreateTableRequest request = new CreateTableRequest()
                .withTableName(PDM_PRODUCT_AUDITS_TABLE)
                .withKeySchema(keySchema)
                .withAttributeDefinitions(attributeDefinitions)
                .withProvisionedThroughput(new ProvisionedThroughput()
                        .withReadCapacityUnits(5L)
                        .withWriteCapacityUnits(5L));

        dynamoClient.createTable(request);
    }

    public void recreateProductsTable() {
        if (tableExists(PDM_PRODUCTS_TABLE)) {
            dynamoClient.deleteTable(PDM_PRODUCTS_TABLE);
        }
        createProductsTable();
    }

    public void recreateProductAuditsTable() {
        if (tableExists(PDM_PRODUCT_AUDITS_TABLE)) {
            dynamoClient.deleteTable(PDM_PRODUCT_AUDITS_TABLE);
        }
        createProductAuditsTable();
    }

    public boolean tableExists(String tableName) {
        return getTableNames().contains(tableName);
    }

    public List<String> getTableNames() {
        ListTablesResult result = dynamoClient.listTables();
        return result.getTableNames();
    }

    private AWSCredentialsProvider getAWSCredentialsProvider() {
        return new AWSCredentialsProvider() {
            @Override
            public AWSCredentials getCredentials() {
                return awsCredentials;
            }

            @Override
            public void refresh() {
                // do nothing here
            }
        };
    }

    private String getLocalServiceEndpoint() {
        return environment.getProperty("aws.dynamo.localServiceEndpoint");
    }
}
