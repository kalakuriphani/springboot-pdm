package com.hsbc.pdm;

import com.hsbc.pdm.entities.Product;
import com.hsbc.pdm.entities.ProductVariation;
import org.bson.Document;
import org.junit.Assert;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ProductAssert {

    private ProductAssert() {}

    public static void assertEquals(Product expected, Product actual) {
        Assert.assertNotNull(expected);
        Assert.assertNotNull(actual);
        Assert.assertEquals(expected.getId(), actual.getId());
        Assert.assertEquals(expected.getProductTypeInternalEnum(), actual.getProductTypeInternalEnum());
        Assert.assertEquals(expected.getCreatedAt(), actual.getCreatedAt());
        Assert.assertEquals(expected.getCreatedBy(), actual.getCreatedBy());
        Assert.assertEquals(expected.getStatusEnum(), actual.getStatusEnum());
        Assert.assertEquals(expected.getVersion(), actual.getVersion());

        Assert.assertNotNull(actual.getVariations());
        Assert.assertEquals(expected.getVariations().size(), actual.getVariations().size());

        if (actual.getVariations().get(0) instanceof ProductVariation) {
            assertEquals((ProductVariation) expected.getVariations().get(0), (ProductVariation) actual.getVariations().get(0));
        } else {
            assertEquals((ProductVariation) expected.getVariations().get(0), (Map) actual.getVariations().get(0));
        }
    }

    public static void assertEquals(ProductVariation expected, ProductVariation actual) {
        Assert.assertEquals(expected.getId(), actual.getId());
        Assert.assertEquals(expected.getVariationName(), actual.getVariationName());
        Assert.assertEquals(expected.getStartDate(), actual.getStartDate());
        Assert.assertEquals(expected.getExpiryDate(), actual.getExpiryDate());
        assertProductDetailsEquals(expected.getDetails(), actual.getDetails());
    }

    public static void assertEquals(ProductVariation expected, Map<String, Object> actual) {
        Assert.assertEquals(expected.getId(), actual.get("id"));
        Assert.assertEquals(expected.getVariationName(), actual.get("variationName"));
        Assert.assertEquals(expected.getStartDate().getTime(), actual.get("startDate"));
        Assert.assertEquals(expected.getExpiryDate().getTime(), actual.get("expiryDate"));
        assertProductDetailsEquals(expected.getDetails(), new Document((Map<String, Object>) actual.get("details")));
    }

    public static void assertProductDetailsEquals(Map<String, Object> expected, Map<String, Object> actual) {
        Assert.assertNotNull(expected);
        Assert.assertNotNull(actual);
        assertDocumentFields(expected, actual);
    }

    private static void assertDocumentFields(Map<String, Object> expected, Map<String, Object> actual) {
        for (Map.Entry<String, Object> expectedEntry : expected.entrySet()) {
            if (!actual.containsKey(expectedEntry.getKey())) {
                Assert.fail(String.format("Property expected ( property = %s ), but was not found", expectedEntry.getKey()));
            }
            Object actualValue = actual.get(expectedEntry.getKey());
            if (expectedEntry.getValue() == null && actualValue != null) {
                Assert.fail(String.format("Expected NULL value, but was NOT NULL ( property = %s )", expectedEntry.getKey()));
            } else if (expectedEntry.getValue() != null && actualValue == null) {
                Assert.fail(String.format("Expected NOT NULL value, but was NULL ( property = %s )", expectedEntry.getKey()));
            } else if (expectedEntry.getValue() == null && actualValue == null) {
                continue; // next property
            }
            // at this point both have values
            if (expectedEntry.getValue() instanceof Map && actualValue instanceof Map) {
                assertDocumentFields((Map) expectedEntry.getValue(), (Map) actualValue);
            } else if (expectedEntry.getValue() instanceof List && actualValue instanceof List) {
                Set<?> expectedValues = new HashSet<>((List<?>) expectedEntry.getValue());
                Set<?> actualValues = new HashSet<>((List<?>) actualValue);
                Assert.assertEquals("List size does not match", expectedValues.size(), actualValues.size());
                Assert.assertEquals("List items don't match", expectedValues.containsAll(actualValues), actualValues.containsAll(expectedValues));
            } else if (!(expectedEntry.getValue() instanceof Map) && !expectedEntry.getValue().getClass().equals(actualValue.getClass())) {
                Assert.fail(String.format("Expected class is %s, but was %s [key = %s]", expectedEntry.getValue().getClass(), actualValue.getClass(), expectedEntry.getKey()));
            } else {
                String message = String.format("Expected value '%s' ( property = %s ), but was '%s'", expectedEntry.getValue(), actualValue, expectedEntry.getKey());
                Assert.assertEquals(message, expectedEntry.getValue(), actualValue);
            }
        }
        for (Map.Entry<String, Object> actualEntry : actual.entrySet()) {
            if (!expected.containsKey(actualEntry.getKey())) {
                Assert.fail(String.format("Property not expected ( property = %s ), but was found", actualEntry.getKey()));
            }
        }
    }
}
