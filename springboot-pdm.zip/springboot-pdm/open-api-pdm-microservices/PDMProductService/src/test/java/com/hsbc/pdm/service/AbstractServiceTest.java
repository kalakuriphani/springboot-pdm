package com.hsbc.pdm.service;

import com.hsbc.openbanking.jsonschema.JsonSchemaType;
import com.hsbc.openbanking.jsonschema.wrapper.ProductWrapper;
import com.hsbc.openbanking.jsonschema.wrapper.ProductWrapperFactory;
import com.hsbc.pdm.AbstractTest;
import com.hsbc.pdm.Datastore;
import com.hsbc.pdm.LocalDynamoDbContainer;
import com.hsbc.pdm.common.JsonSchemaUtils;
import com.hsbc.pdm.common.UserRoles;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.productservice.model.ProductVariation;
import org.junit.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.User;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Date;

@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public abstract class AbstractServiceTest<ID> extends AbstractTest<ID> {

    protected final static Date YESTERDAY_DATE = Date.from(LocalDateTime.now().minusDays(1).toInstant(ZoneOffset.UTC));

    protected static final Object CAN_DO_EVERYTHING_PRINCIPAL = new User("dummy-user", "N/A", UserRoles.AUTHORITIES);


    @Autowired
    protected Datastore datastore;

    @Autowired
    private ProductWrapperFactory productWrapperFactory;

    @BeforeClass
    public static void beforeClass() {
        LocalDynamoDbContainer.start();
    }

    @AfterClass
    public static void afterClass() {
        LocalDynamoDbContainer.stop();
    }

    @Before
    public void setUp() {
        datastore.truncate();
    }


    protected String getProductName(ProductTypeEnum productType, String productVersion, ProductVariation variation) {
        JsonSchemaType schemaType = JsonSchemaUtils.getJsonSchemaType(productType, productVersion);
        ProductWrapper productWrapper = productWrapperFactory.build(schemaType, variation.getDetails());
        return productWrapper.getProductName();
    }

    protected String getProductName(ProductTypeEnum productType, String productVersion, com.hsbc.pdm.entities.ProductVariation variation) {
        JsonSchemaType schemaType = JsonSchemaUtils.getJsonSchemaType(productType, productVersion);
        ProductWrapper productWrapper = productWrapperFactory.build(schemaType, variation.getDetails());
        return productWrapper.getProductName();
    }

}
