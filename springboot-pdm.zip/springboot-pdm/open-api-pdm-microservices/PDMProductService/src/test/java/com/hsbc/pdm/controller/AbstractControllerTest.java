package com.hsbc.pdm.controller;

import com.hsbc.pdm.AbstractTest;
import com.hsbc.pdm.Datastore;
import com.hsbc.pdm.LocalDynamoDbContainer;
import com.hsbc.pdm.auth.AuthorityProvider;
import com.hsbc.pdm.auth.PDMUser;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.RequestEntity;
import org.springframework.http.RequestEntity.BodyBuilder;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.session.Session;
import org.springframework.session.SessionRepository;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext(methodMode = DirtiesContext.MethodMode.AFTER_METHOD)
public class AbstractControllerTest<ID> extends AbstractTest<ID> {

    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String PDM_TOKEN_AUTHORIZATION = "PDM-Token";
    private static final String X_PDM_TOKEN_HEADER = "X-PDM-Token";
    private static final String X_AUTH_TOKEN_HEADER = "X-Auth-Token";

    @Value("${local.server.port}")
    private int port;

//    @Value("${server.contextPath}")
    private String contextPath = "";

    private URL base;

    protected RestTemplate template;

    private RestTemplateBuilder templateBuilder;

    @Autowired
    protected Datastore datastore;

    @Autowired
    protected AuthenticationProvider authenticationProvider;

    @Autowired
    protected SessionRepository sessionRepository;

    @Mock
    private AuthorityProvider authorityProvider;

    @BeforeClass
    public static void beforeClass() {
        LocalDynamoDbContainer.start();
    }

    @AfterClass
    public static void afterClass() {
        LocalDynamoDbContainer.stop();
    }

    @Before
    public void setUp() {
        datastore.truncate();
        try {
            base = new URL("http://localhost:" + port + contextPath);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
        templateBuilder = new RestTemplateBuilder();
        template = templateBuilder.build();

        /**
         * This mocks all calls to PDM Authority provider, hence making testing less dependent on remote service.
         */
        ReflectionTestUtils.setField(authenticationProvider, "authorityProvider", authorityProvider);
    }

    protected String url(String relativeUrl) {
        return base.toString() + relativeUrl;
    }

    /**
     * Expand request entity with mandatory headers.
     */
    protected <E extends RequestEntity.HeadersBuilder> E expandHeaders(E builder, String xPDMToken) {
        return (E) builder
                .accept(APPLICATION_JSON)
                .header(AUTHORIZATION_HEADER, PDM_TOKEN_AUTHORIZATION)
                .header(X_PDM_TOKEN_HEADER, xPDMToken);
    }

    /**
     * Expand request entity with mandatory headers.
     */
    protected BodyBuilder expandHeaders(BodyBuilder builder, String xPDMToken) {
        return builder
                .contentType(APPLICATION_JSON)
                .header(AUTHORIZATION_HEADER, PDM_TOKEN_AUTHORIZATION)
                .header(X_PDM_TOKEN_HEADER, xPDMToken);
    }

    protected void assertLocationPresent(HttpHeaders headers) {
        Assert.assertNotNull("Location is not present", headers.get("location"));
        String location = headers.get("location").toString();
        try {
            new URL("http://localhost" + location);
        }
        catch (MalformedURLException e) {
            Assert.fail("Invalid location format ( location = " + location + ") ");
        }
    }

    protected void mockAuthorityProvider(String sessionId, String username, String... roles) {
        PDMUser user = new PDMUser(username, "N/A", buildAuthorities(roles));
        doReturn(user).when(authorityProvider).getPDMUser(sessionId);
    }

    protected void verifyAuthorityProvider(String sessionId) {
        verify(authorityProvider).getPDMUser(sessionId);
        reset(authorityProvider);
    }

    @Deprecated
    private List<GrantedAuthority> buildAuthorities(String... roles) {
        return super.getAuthorities(roles);
    }

    protected Session createSession(Authentication authentication) {
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        securityContext.setAuthentication(authentication);
        Session session = sessionRepository.createSession();
        session.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, securityContext);
        return session;
    }

    /**
     * Use this handler when you want your RestTemplate to return gracefully
     * regardless of the response status code.
     */
    protected class DoNothingResponseErrorHandler implements ResponseErrorHandler {

        @Override
        public boolean hasError(ClientHttpResponse clientHttpResponse) throws IOException {
            return false;
        }

        @Override
        public void handleError(ClientHttpResponse clientHttpResponse) throws IOException {

        }
    }
}
