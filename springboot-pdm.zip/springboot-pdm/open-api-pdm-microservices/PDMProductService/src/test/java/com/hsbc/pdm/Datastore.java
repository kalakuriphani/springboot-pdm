package com.hsbc.pdm;

import com.hsbc.pdm.entities.ProductVariation;
import com.hsbc.pdm.entities.dynamo.DynamoProduct;
import com.hsbc.pdm.entities.dynamo.DynamoProductAudit;
import com.hsbc.pdm.repository.ProductAuditRepository;
import com.hsbc.pdm.repository.ProductRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@Component
public class Datastore<PRODUCT, ID> {

    private static final Logger LOG = LoggerFactory.getLogger(Datastore.class);

    @Autowired
    private ProductRepository<PRODUCT, ID> productRepository;

    @Autowired
    private ProductAuditRepository productAuditRepository;

    @Autowired
    private DynamoTableRegistry dynamoTableRegistry;

    public void truncate() {
        dynamoTableRegistry.recreateProductsTable();
        dynamoTableRegistry.recreateProductAuditsTable();
    }

    public void auditCreate(String username, DynamoProduct product)  {
        audit(username, product, "INSERT");
    }

    public void auditUpdate(String username, DynamoProduct product, DynamoProductAudit.ProductDifference... differences)  {
        audit(username, product, "MODIFY", differences);
    }

    private void audit(String username, DynamoProduct product, String eventType, DynamoProductAudit.ProductDifference... differences)  {
        DynamoProductAudit audit = new DynamoProductAudit();
        audit.setUsername(username);
        audit.setTimestamp(new Date());
        audit.setEventType(eventType);
        audit.setProductKey(new DynamoProductAudit.ProductKey(product.getId(), product.getProductTypeInternal()));

        List<ProductVariation> variations = product.getVariations();
        List<ProductVariation> approvedVariations = product.getApprovedVariations();

        product.setVariations(Collections.emptyList());
        product.setApprovedVariations(Collections.emptyList());

        audit.setProductEntry(product);
        audit.setProductDifferences(Arrays.asList(differences));
        productAuditRepository.save(audit);

        product.setVariations(variations);
        product.setApprovedVariations(approvedVariations);
    }

    public void auditCreate(String username, ID productId)  {
        audit(username, productId, "INSERT");
    }

    public void auditUpdate(String username, ID productId, DynamoProductAudit.ProductDifference... differences)  {
        audit(username, productId, "MODIFY", differences);
    }

    private void audit(String username, ID productId, String eventType, DynamoProductAudit.ProductDifference... differences)  {
        DynamoProduct product = (DynamoProduct) productRepository.findOne(productId);
        audit(username, product, eventType, differences);
    }


}
