package com.hsbc.pdm;

import com.hsbc.openbanking.jsonschema.JsonSchemaType;
import com.hsbc.openbanking.jsonschema.wrapper.ProductWrapper;
import com.hsbc.openbanking.jsonschema.wrapper.ProductWrapperFactory;
import com.hsbc.pdm.common.JsonSchemaUtils;
import com.hsbc.pdm.common.model.ProductDetails;
import com.hsbc.pdm.common.model.ProductTypeEnum;

import java.util.*;

public class ProductDetailsSamples {

    private static ProductWrapperFactory productWrapperFactory = new ProductWrapperFactory();

    private ProductDetailsSamples() {}

    public static Map<String, Object> buildProductDetails(String productName, ProductTypeEnum productType, String productVersion) {
        JsonSchemaType schemaType = JsonSchemaUtils.getJsonSchemaType(productType, productVersion);
        ProductWrapper product = productWrapperFactory.build(schemaType, new ProductDetails());
        product.setProductName(productName);
        product.setProductType(productType.getExternalName());
        product.setProductSegment(Arrays.asList("Basic", "Premium"));

        setupOrganisation(product);
        setupProduct(product);
        setupEligibility(product);
        setupFeesAndCharges(product);
        setupBenefits(product);

        return product.getContent();
    }

    private static void setupOrganisation(ProductWrapper productWrapper) {
        Map<String, Object> organisation = new HashMap<>();
        productWrapper.getContent().put("Organisation", organisation);

        Map<String, Object> parentOrganisation = new HashMap<>();
        organisation.put("ParentOrganisation", parentOrganisation);

        Map<String, Object> organisationName = new HashMap<>();
        parentOrganisation.put("LEI","");
        parentOrganisation.put("BIC","MIDLGB22");
        parentOrganisation.put("OrganisationName", organisationName);
        organisationName.put("LegalName", "HSBCG");


        Map<String, Object> brand = new HashMap<>();
        organisation.put("Brand", brand);

        brand.put("TrademarkID", "HSBC UK");
        brand.put("TrademarkIPOCode", "UK");
    }

    private static void setupEligibility(ProductWrapper productWrapper) {
        Map<String, Object> eligibility = new HashMap<>();
        productWrapper.getContent().put("Eligibility", eligibility);

        eligibility.put("AgeRestricted", Boolean.TRUE.toString());
        eligibility.put("OtherFinancialHoldingRequired", Boolean.FALSE.toString());
        eligibility.put("Description", "some description");
        eligibility.put("IncomeTurnoverRelated", Boolean.FALSE.toString());
        eligibility.put("ResidencyRestricted", Boolean.TRUE.toString());
        eligibility.put("ThirdSectorOrganisations", Boolean.FALSE.toString());
        eligibility.put("PreviousBankruptcy", Boolean.FALSE.toString());
    }

    private static void setupProduct(ProductWrapper productWrapper) {
        Map<String, Object> product = productWrapper.getContent();

        product.put("InternationalPaymentsSupported", Boolean.TRUE.toString());
        product.put("Contactless", Boolean.TRUE.toString());
        product.put("CreditScoringPartOfAccountOpeningForGettingAnAccount", Boolean.FALSE.toString());
        product.put("ChequeBookAvailable", Boolean.FALSE.toString());
        product.put("OverdraftOffered", Boolean.TRUE.toString());

        product.put("ProductIdentifier", "some product identifier");
        product.put("CardWithdrawalLimit", "300.00");
        product.put("ProductDescription", "some product description");

        product.put("TsandCs", Arrays.asList("some TsandCs"));
        product.put("AccessChannels", Arrays.asList("ATM", "Branch", "MobileApps"));
        product.put("CardType", Arrays.asList("BasicCard", "Cashcard", "ContactlessCashcard"));
        product.put("Currency", Arrays.asList("GBP"));
        product.put("ProductURL", Arrays.asList("http://some.org"));

        Map<String, Object> caPricing = new HashMap<>();
        product.put("CAPricing", Arrays.asList(caPricing));

        caPricing.put("ProductSubType", "Regular");
        caPricing.put("CAPricingItem", new HashMap<>());

        Map<String, Object> creditInterest = new HashMap<>();
        product.put("CreditInterest", creditInterest);

        creditInterest.put("CreditCharged", Boolean.FALSE.toString());
    }

    private static void setupBenefits(ProductWrapper productWrapper) {
        Map<String, Object> benefits = new HashMap<>();
        productWrapper.getContent().put("Benefits", benefits);

        benefits.put("Benefit", Boolean.FALSE.toString());
    }

    private static void setupFeesAndCharges(ProductWrapper productWrapper) {
        Map<String, Object> feesAndCharges = new HashMap<>();
        productWrapper.getContent().put("FeesAndCharges", Arrays.asList(feesAndCharges));

        feesAndCharges.put("ProductSubType", "Regular");

        Map<String, Object> fees = new HashMap<>();
        feesAndCharges.put("Fees", fees);

        Map<String, Object> feeDetails = new HashMap<>();
        fees.put("FeeDetails", Arrays.asList(feeDetails));

        feeDetails.put("FeeSubType", "Regular");

        Map<String, Object> feeDetail = new HashMap<>();
        feeDetails.put("FeeDetail", feeDetail);

        feeDetail.put("FeeType", "ATMDonation");

        Map<String, Object> feeSubDetails = new HashMap<>();
        feeDetail.put("FeeSubDetails", feeSubDetails);

        feeSubDetails.put("FeeFrequency", "AccountOpening");
        feeSubDetails.put("Negotiable", Boolean.FALSE.toString());
    }
}
