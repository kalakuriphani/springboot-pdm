package com.hsbc.pdm.service;

import com.hsbc.pdm.common.UserRoles;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;

import java.util.Set;

public class UserServiceTest extends AbstractServiceTest {

    @Autowired
    private UserService userService;

    @Test
    public void getRoles_when_ser_has_roles_should_return_roles() {
        Authentication authentication = createDummyAuthentication("ROLE-1", "ROLE-2");

        // call method under test
        Set<String> roles = userService.getRoles(authentication);

        // assert
        Assert.assertEquals(2, roles.size());
        Assert.assertEquals(true, roles.contains("ROLE-1"));
        Assert.assertEquals(true, roles.contains("ROLE-2"));
    }

    @Test
    public void getRoles_when_user_has_no_roles_should_return_empty_set() {
        Authentication authentication = createDummyAuthentication(/* no roles */);

        // call method under test
        Set<String> roles = userService.getRoles(authentication);

        // assert
        Assert.assertEquals(0, roles.size());
    }

    @Test
    public void isInRole_should_return_true() {
        Authentication authentication = createAuthentication("ROLE-1", "ROLE-2");

        // call method under test
        boolean isInRole = userService.isInRole(authentication, "ROLE-2");

        // assert
        Assert.assertEquals(true, isInRole);
    }

    @Test
    public void isInRole_should_return_false() {
        Authentication authentication = createAuthentication("ROLE-1", "ROLE-2");

        // call method under test
        boolean isInRole = userService.isInRole(authentication, "ROLE-236");

        // assert
        Assert.assertEquals(false, isInRole);
    }

    @Test
    public void isMaker_should_return_true() {
        for (String role : UserRoles.RoleType.MAKER_ROLES.getRoles()) {
            // call method under test
            boolean isMaker = userService.isMaker(createDummyAuthentication(role));
            // assert
            Assert.assertEquals(true, isMaker);
        }
    }

    @Test
    public void isMaker_should_return_false() {
        for (String role : UserRoles.RoleType.CHECKER_ROLES.getRoles()) {
            // call method under test
            boolean isMaker = userService.isMaker(createAuthentication(role));
            // assert
            Assert.assertEquals(false, isMaker);
        }
        // assert a dummy role
        Assert.assertEquals(false, userService.isMaker(createAuthentication("NOT-MAKER-ROLE")));
    }

    @Test
    public void isChecker_should_return_true() {
        for (String role : UserRoles.RoleType.CHECKER_ROLES.getRoles()) {
            // call method under test
            boolean isChecker = userService.isChecker(createDummyAuthentication(role));
            // assert
            Assert.assertEquals(true, isChecker);
        }
    }

    @Test
    public void isChecker_should_return_false() {
        for (String role : UserRoles.RoleType.MAKER_ROLES.getRoles()) {
            // call method under test
            boolean isChecker = userService.isChecker(createAuthentication(role));
            // assert
            Assert.assertEquals(false, isChecker);
        }
        // assert a dummy role
        Assert.assertEquals(false, userService.isChecker(createAuthentication("NOT-CHECKER-ROLE")));
    }
}
