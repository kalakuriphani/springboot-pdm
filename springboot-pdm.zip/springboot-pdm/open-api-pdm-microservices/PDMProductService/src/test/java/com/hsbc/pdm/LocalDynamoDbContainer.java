package com.hsbc.pdm;

import com.sun.org.apache.bcel.internal.generic.NEW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.ServerSocket;
import java.util.concurrent.TimeUnit;

/**
 * Created by 44023148 on 06/03/2017.
 */
public class LocalDynamoDbContainer {

    private static final Logger LOG = LoggerFactory.getLogger(LocalDynamoDbContainer.class);

    private static String NEW_LINE = System.getProperty("line.separator");

    private static Process process = null;

    public static final int PORT = getLocalDynamoPort();

    static {
        System.setProperty("aws.dynamo.localServiceEndpoint", "http://localhost:" + PORT);
    }


    public static void start() {
        try {
            createDataDirectory();
            runLocalDynamoDB();
        } catch (Exception e) {
            throw new RuntimeException("Failed to start Local DynamoDB container", e);
        }
    }

    public static void stop() {
        if (process != null && process.isAlive()) {
            LOG.info("Stopping local DynamoDB...");
            process.destroy();
            LOG.info("Local DynamoDB stopped");
        }
        process = null;
    }

    private static StringBuilder readProcessOutput(StringBuilder sb) {
        try {
            InputStream is = process.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append(NEW_LINE);
            }
            return sb;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static StringBuilder readProcessErrors(StringBuilder sb) {
        try {
            InputStream is = process.getErrorStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append(NEW_LINE);
            }
            return sb;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static String getWorkingPath() throws IOException, InterruptedException {
        process = Runtime.getRuntime().exec("pwd");
        process.waitFor();
        StringBuilder output = readProcessOutput(new StringBuilder());
        String pwd = output.toString().replace(NEW_LINE, "");
        process = Runtime.getRuntime().exec("ls -l");
        process.waitFor();
        output = readProcessOutput(new StringBuilder());
        if (output.indexOf("dynamodb_local") == -1) {
            // dynamodb_local no found, go one level up
            pwd += "/..";
        }

        File dir = new File(pwd);
        if (!dir.exists()) {
            throw new RuntimeException(pwd + " directory does not exists");
        }
        LOG.info("Working directory = " + dir.getCanonicalPath());
        return dir.getCanonicalPath();
    }

    private static void createDataDirectory() throws IOException, InterruptedException {
        String dbdata = getWorkingPath() + "/dynamodb_local/db-data";
        if (new File(dbdata).exists()) {
            LOG.info(dbdata + " directory exists");
            return;
        }

        process = Runtime.getRuntime().exec("mkdir " + dbdata);
        int exitCode = process.waitFor();
        if (exitCode != 0) {
            StringBuilder output = readProcessErrors(new StringBuilder());
            LOG.error("Failed to create DynamoDB data directory ( exit code = {} ) with output:" + NEW_LINE + output.toString(), exitCode);
            throw new RuntimeException(String.format("Failed to create DynamoDB data directory ( exit code = %s )", exitCode));
        }

        File dir = new File(dbdata);
        if (!dir.exists()) {
            throw new RuntimeException(dbdata + " directory does not exists");
        }
    }

    private static void runLocalDynamoDB() throws IOException, InterruptedException {
        LOG.info("Spin up local DynamoDB on port " + PORT + "...");
        StringBuilder output;
        process = Runtime.getRuntime().exec("java -Djava.library.path=" + getWorkingPath() + "/dynamodb_local/DynamoDBLocal_lib "
                + "-jar " + getWorkingPath() + "/dynamodb_local/DynamoDBLocal.jar "
                + "-port " + PORT + " "
                + "-dbPath " + getWorkingPath() + "/dynamodb_local/db-data "
                + "-optimizeDbBeforeStartup -delayTransientStatuses -sharedDb"
        );
        if (process.waitFor(1, TimeUnit.SECONDS)) {
            int exitCode = process.exitValue();
            output = readProcessErrors(new StringBuilder());
            LOG.error("Run local DynamoDB command terminated ( exit code = {} ) with output:" + NEW_LINE + output.toString(), exitCode);
            throw new RuntimeException(String.format("Local DynamoDB could not be run ( exit code = %s )", exitCode));
        } else {
            LOG.info("Local DynamoDB is up and running");
        }
    }

    private static Integer getLocalDynamoPort() {
        for (int port = 10000; port <= 60000; port++) {
            if (isLocalPortFree(port)) {
                return port;
            }
        }
        throw new RuntimeException("Could not generaget random port for local DynamoDB");
    }

    private static boolean isLocalPortFree(int port) {
        try {
            new ServerSocket(port).close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
