package com.hsbc.pdm;

import com.hsbc.pdm.config.dynamo.DynamoBeansConfig;
import org.bson.types.ObjectId;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.ActiveProfiles;

/**
 * Created by 44023148 on 03/02/2017.
 */
@Configuration
//@TestConfiguration
@Profile("dynamo")
@ActiveProfiles("dynamo")
public class DynamoTestConfig extends DynamoBeansConfig {

    @Bean
    public ProductEntitySamples productEntitySamples() {
        return new ProductEntitySamples<ObjectId>();
    }

}
