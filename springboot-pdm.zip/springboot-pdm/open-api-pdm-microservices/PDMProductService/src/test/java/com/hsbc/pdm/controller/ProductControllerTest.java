package com.hsbc.pdm.controller;

import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.productservice.model.Product;
import com.hsbc.pdm.repository.ProductRepository;
import org.bson.types.ObjectId;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.*;

public class ProductControllerTest<ID> extends AbstractControllerTest<ID> {

    private static final String PDM_TOKEN = UUID.randomUUID().toString();

    private static final String URL_GET_PRODUCT_TEMPLATE = "/product/{product-type}/{product-version}/{product-status}/{product-id}";

    @Autowired
    private ProductRepository<com.hsbc.pdm.entities.Product<ID>, ID> productRepository;

    @Test
    public void get_existing_product_should_return_product() {
        com.hsbc.pdm.entities.Product<ID> expected = productEntitySamples.getExisting();
        process(expected);
        ID productId = productRepository.insert(expected).getId();

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url(URL_GET_PRODUCT_TEMPLATE));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(expected.getProductTypeInternal(), expected.getProductTypeVersion(), expected.getStatus(), productId.toString());
        URI uri = uriComponents.toUri();

        RequestEntity<Void> request = expandHeaders(RequestEntity.get(uri), PDM_TOKEN).build();

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", ALL_ROLES);

        // call method under test
        ResponseEntity<Product> response = template.exchange(request, Product.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());

        Assert.assertEquals(expected.getId().toString(), response.getBody().getId());
        Assert.assertEquals(expected.getProductTypeInternalEnum(), response.getBody().getProductType());
        Assert.assertEquals(expected.getStatusEnum(), response.getBody().getStatus());
    }

    @Test
    public void get_non_existing_product_should_return_404_NOT_FOUND() {
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url(URL_GET_PRODUCT_TEMPLATE));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(ProductTypeEnum.BCA.name(), "1.0", StatusEnum.DRAFT.name(), ObjectId.get().toString());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.get(uri), PDM_TOKEN).build();

        /**
         * We are expecting 404 in our response which will cause spring's default error handler to throw, so
         * here we are resetting default error handler with one that does nothing.
         */
        template.setErrorHandler(new DoNothingResponseErrorHandler());

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", "ROLE-1");

        // call method under test
        ResponseEntity<Product> response = template.exchange(request, Product.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
    }

    @Test
    public void get_products_should_return_list_of_products() {
        com.hsbc.pdm.entities.Product<ID> expected = productEntitySamples.getExisting();
        process(expected);
        productRepository.insert(expected).getId();

        URI uri = UriComponentsBuilder.fromHttpUrl(url("/product")).build().toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.get(uri), PDM_TOKEN).build();

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", ALL_ROLES);

        // call method under test
        ResponseEntity<List<Product>> response = template.exchange(request, new ParameterizedTypeReference<List<Product>>() {});

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());

        Assert.assertEquals(true, response.getBody().size() > 0);
        for (Product product : response.getBody()) {
            assertAllProductFieldsNotNull(product);
        }
    }

    private void assertAllProductFieldsNotNull(Product product) {
        Assert.assertNotNull(product.getId());
        Assert.assertNotNull(product.getProductType());
        Assert.assertNotNull(product.getProductTypeVersion());
        Assert.assertNotNull(product.getVariations());
        Assert.assertEquals(true, product.getVariations().size() > 0);
        Assert.assertNotNull(product.getProductName());
        Assert.assertNotNull(product.getProductSegment());
        Assert.assertNotNull(product.getStatus());
        Assert.assertNotNull(product.getCreatedAt());
        Assert.assertNotNull(product.getCreatedBy());
        Assert.assertNotNull(product.getUpdatedAt());
        Assert.assertNotNull(product.getUpdatedBy());
        Assert.assertNotNull(product.getCountry());
        Assert.assertNotNull(product.getVersion());

        if (product.getStatus() == StatusEnum.APPROVED
                || product.getStatus() == StatusEnum.SUBMITTED_FOR_DELETION
                || product.getStatus() == StatusEnum.DELETED
                || product.getStatus() == StatusEnum.PUBLISHED
                || product.getStatus() == StatusEnum.SUSPENDED) {
            Assert.assertNotNull(product.getApprovedAt());
            Assert.assertNotNull(product.getApprovedBy());
        }
    }

    @Test
    public void get_products_by_status_should_return_list_of_products() {
        com.hsbc.pdm.entities.Product<ID> entity = productEntitySamples.getApproved("some product name");
        process(entity);
        productRepository.insert(entity);
        entity = productEntitySamples.get("some other product name", entity.getProductTypeInternalEnum(), entity.getProductTypeVersion());
        entity.setStatusEnum(StatusEnum.DRAFT);
        process(entity);
        productRepository.insert(entity);

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/product/status/{status}"));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(StatusEnum.APPROVED.toString().toLowerCase());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.get(uri), PDM_TOKEN).build();

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", "ROLE-1");

        // call method under test
        ResponseEntity<List<Product>> response = template.exchange(request, new ParameterizedTypeReference<List<Product>>() {});

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());

        Assert.assertEquals(1, response.getBody().size());
        assertAllProductFieldsNotNull(response.getBody().get(0));
    }

    @Test
    public void get_products_by_type_should_return_list_of_products() {
        com.hsbc.pdm.entities.Product<ID> expected = productEntitySamples.getExisting();
        process(expected);
        productRepository.insert(expected);

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/product/{type}/collection"));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(ProductTypeEnum.PCAHSBC.toString().toLowerCase());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.get(uri), PDM_TOKEN).build();

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", ALL_ROLES);

        // call method under test
        ResponseEntity<List<Product>> response = template.exchange(request, new ParameterizedTypeReference<List<Product>>() {});

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertEquals(true, response.getBody().size() > 0);
        for (Product p : response.getBody()) {
            assertEquals(ProductTypeEnum.PCAHSBC, p.getProductType());
        }
    }
}
