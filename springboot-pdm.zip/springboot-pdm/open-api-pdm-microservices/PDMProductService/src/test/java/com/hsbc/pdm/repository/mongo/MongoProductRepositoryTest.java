package com.hsbc.pdm.repository.mongo;

import com.hsbc.pdm.entities.Product;
import com.hsbc.pdm.entities.mongo.MongoProduct;
import com.hsbc.pdm.repository.AbstractRepositoryTest;
import org.bson.types.ObjectId;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;

import static com.hsbc.pdm.ProductAssert.assertEquals;

@Ignore
@ActiveProfiles(value = { "default", "mongo" })
public class MongoProductRepositoryTest extends AbstractRepositoryTest<ObjectId> {

    @Autowired
    private MongoProductRepository productRepository;

    @Test
    public void insert() {
        MongoProduct product = (MongoProduct) productEntitySamples.getBrandNew();

        // call method under test
        productRepository.insert(product);

        // assert
        Product actual = productRepository.findOne(product.getId());
        assertEquals(product, actual);
    }
}
