package com.hsbc.pdm;

import com.hsbc.openbanking.jsonschema.JsonSchemaType;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.entities.ProductTemplate;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.Date;

public class ProductTemplateSamples {

    public static final ObjectId PCA_PRODUCT_TEMPLATE_ID = ObjectId.get();
    public static final ObjectId BCA_PRODUCT_TEMPLATE_ID = ObjectId.get();

    private ProductTemplateSamples() {}

    public static ProductTemplate buildProductTemplate(ProductTypeEnum type) {
        switch (type) {
            case PCAHSBC:
                return buildPCA();
            case BCA:
                return buildBCA();
            default:
                throw new RuntimeException("Unexpected product type = " + type);
        }
    }

    private static ProductTemplate buildPCA() {
        ProductTemplate productTemplate = new ProductTemplate();
        productTemplate.setId(PCA_PRODUCT_TEMPLATE_ID);
        productTemplate.setTypeEnum(ProductTypeEnum.PCAHSBC);
        productTemplate.setTitle("Personal Current Account");
        productTemplate.setCreatedAt(new Date());
        productTemplate.setCreatedBy("test-user");
        productTemplate.setStatusEnum(StatusEnum.DRAFT);
        productTemplate.setVersion(1);

        Document schema = new Document();
        schema.append("documentVersion", JsonSchemaType.PCA_HSBC_PRODUCT_1_2_4.getVersion());
        productTemplate.setSchema(schema);

        return productTemplate;
    }

    private static ProductTemplate buildBCA() {
        ProductTemplate productTemplate = new ProductTemplate();
        productTemplate.setId(BCA_PRODUCT_TEMPLATE_ID);
        productTemplate.setTypeEnum(ProductTypeEnum.BCA);
        productTemplate.setTitle("Business Current Account");
        productTemplate.setCreatedAt(new Date());
        productTemplate.setCreatedBy("test-user");
        productTemplate.setStatusEnum(StatusEnum.DRAFT);
        productTemplate.setVersion(1);

        Document schema = new Document();
        schema.append("documentVersion", JsonSchemaType.BCA_PRODUCT_1_2_4 .getVersion());
        productTemplate.setSchema(schema);

        return productTemplate;
    }
}
