package com.hsbc.pdm.controller;

import com.hsbc.pdm.common.ProductFactory;
import com.hsbc.pdm.common.UserRoles;
import com.hsbc.pdm.common.WorkflowActions;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.productservice.model.Product;
import com.hsbc.pdm.repository.ProductRepository;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static com.hsbc.pdm.ProductModelSamples.*;
import static com.hsbc.pdm.common.model.StatusEnum.*;
import static org.junit.Assert.*;

public class ProductWorkflowControllerTest<ID> extends AbstractControllerTest<ID> {

    private static final String PDM_TOKEN = UUID.randomUUID().toString();

    private static final String PRODUCT_WORKFLOW_ACTIONS_URL = "/workflow/product/{product-type}/{product-status}/{product-id}/action";

    @Autowired
    private ProductRepository<com.hsbc.pdm.entities.Product<ID>, ID> productRepository;

    @Autowired
    private ProductFactory<ID> productFactory;


    @Test
    public void create_new_product_should_return_201_CREATED() {
        Product product = getBrandNew(PRODUCT_ID, ProductTypeEnum.SMEL, PRODUCT_VERSION_SMEL);

        URI uri = UriComponentsBuilder.fromHttpUrl(url("/workflow/product")).build().toUri();
        RequestEntity<Product> request = expandHeaders(RequestEntity.post(uri), PDM_TOKEN)
                .header("x-pdm-workflow-action", WorkflowActions.ACTION_EDIT)
                .body(product);

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_SME_MAKER);

        // call method under test
        ResponseEntity<Map> response = template.exchange(request, Map.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(true, response.getHeaders().containsKey("Location"));
        assertEquals(true, response.getHeaders().get("Location").get(0).length() > 0);
    }

    @Test
    public void copy_product_should_return_201_CREATED() {
        Product product = getBrandNew(PRODUCT_ID, ProductTypeEnum.SMEL, PRODUCT_VERSION_SMEL);
        product.setStatus(APPROVED);

        URI uri = UriComponentsBuilder.fromHttpUrl(url("/workflow/product")).build().toUri();
        RequestEntity<Product> request = expandHeaders(RequestEntity.post(uri), PDM_TOKEN)
                .header("x-pdm-workflow-action", WorkflowActions.ACTION_COPY)
                .body(product);

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_SME_MAKER);

        // call method under test
        ResponseEntity<Map> response = template.exchange(request, Map.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(true, response.getHeaders().containsKey("Location"));
        assertEquals(true, response.getHeaders().get("Location").get(0).length() > 0);

        com.hsbc.pdm.entities.Product<ID> actual = productRepository.getByStatus(DRAFT.toString()).get(0);
        assertEquals(true, actual.getProductName().startsWith("some product name - copy from "));
        assertEquals(product.getProductType(), actual.getProductTypeInternalEnum());
        assertEquals(DRAFT, actual.getStatusEnum());
    }

    @Test
    public void update_product_should_return_200_OK() {
        com.hsbc.pdm.entities.Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(StatusEnum.DRAFT);
        product.setProductTypeInternalEnum(ProductTypeEnum.SMEL);
        process(product);
        ID productId = productRepository.insert(product).getId();

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/workflow/product/{product-type}/{id}"));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(product.getProductTypeInternal(), productId.toString());
        URI uri = uriComponents.toUri();
        RequestEntity<Product> request = expandHeaders(RequestEntity.put(uri), PDM_TOKEN)
                .header("x-pdm-workflow-action", WorkflowActions.ACTION_EDIT)
                .body(get(product));

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_SME_MAKER);

        // call method under test
        ResponseEntity<Void> response = template.exchange(request, Void.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());

        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        assertEquals(DRAFT, productRepository.findOne(id).getStatusEnum());
    }

    @Test
    public void approveChange_product_should_return_200_OK() throws Exception {
        com.hsbc.pdm.entities.Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(StatusEnum.SUBMITTED_FOR_APPROVAL);
        process(product);
        ID productId = productRepository.insert(product).getId();

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/workflow/product/{product-type}/{id}"));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(product.getProductTypeInternal(), productId.toString());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.put(uri), PDM_TOKEN)
                .header("x-pdm-workflow-action", WorkflowActions.ACTION_APPROVE_CHANGE_REQUEST)
                .body(null);

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);

        // call method under test
        ResponseEntity<Void> response = template.exchange(request, Void.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());

        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        com.hsbc.pdm.entities.Product<ID> actual = productRepository.findOne(id);
        assertEquals(APPROVED, actual.getStatusEnum());
        assertNotNull(actual.getApprovedAt());
        assertNotNull(actual.getApprovedBy());
    }

    @Test
    public void approveDelete_product_should_return_200_OK() throws Exception {
        com.hsbc.pdm.entities.Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(StatusEnum.SUBMITTED_FOR_DELETION);
        product.setProductTypeInternalEnum(ProductTypeEnum.SMEL);
        process(product);
        ID productId = productRepository.insert(product).getId();

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/workflow/product/{product-type}/{id}"));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(product.getProductTypeInternal(), productId.toString());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.put(uri), PDM_TOKEN)
                .header("x-pdm-workflow-action", WorkflowActions.ACTION_APPROVE_DELETE_REQUEST)
                .body(null);

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_SME_CHECKER);

        // call method under test
        ResponseEntity<Void> response = template.exchange(request, Void.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());

        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        assertEquals(DELETED, productRepository.findOne(id).getStatusEnum());
    }

    @Test
    public void requestApprove_product_should_return_200_OK() {
        com.hsbc.pdm.entities.Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(DRAFT);
        process(product);
        ID productId = productRepository.insert(product).getId();

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/workflow/product/{product-type}/{id}"));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(product.getProductTypeInternal(), productId.toString());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.put(uri), PDM_TOKEN)
                .header("x-pdm-workflow-action", WorkflowActions.ACTION_REQUEST_APPROVE)
                .body(null);

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);

        // call method under test
        ResponseEntity<Void> response = template.exchange(request, Void.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());

        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        assertEquals(SUBMITTED_FOR_APPROVAL, productRepository.findOne(id).getStatusEnum());
    }

    @Test
    public void requestDelete_product_should_return_200_OK() {
        com.hsbc.pdm.entities.Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(APPROVED);
        product.setProductTypeInternalEnum(ProductTypeEnum.SMEL);
        process(product);
        ID productId = productRepository.insert(product).getId();

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/workflow/product/{product-type}/{id}"));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(product.getProductTypeInternal(), productId.toString());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.put(uri), PDM_TOKEN)
                .header("x-pdm-workflow-action", WorkflowActions.ACTION_REQUEST_DELETE)
                .body(null);

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_SME_MAKER);

        // call method under test
        ResponseEntity<Void> response = template.exchange(request, Void.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());

        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        assertEquals(SUBMITTED_FOR_DELETION, productRepository.findOne(id).getStatusEnum());
    }

    @Test
    public void rejectApprove_product_should_return_200_OK() {
        com.hsbc.pdm.entities.Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(SUBMITTED_FOR_APPROVAL);
        product.setProductTypeInternalEnum(ProductTypeEnum.SMEL);
        process(product);
        ID productId = productRepository.insert(product).getId();

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/workflow/product/{product-type}/{id}"));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(product.getProductTypeInternal(), productId.toString());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.put(uri), PDM_TOKEN)
                .header("x-pdm-workflow-action", WorkflowActions.ACTION_REJECT_CHANGE_REQUEST)
                .body(null);

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_SME_CHECKER);

        // call method under test
        ResponseEntity<Void> response = template.exchange(request, Void.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());

        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        assertEquals(DRAFT, productRepository.findOne(id).getStatusEnum());
    }

    @Test
    public void rejectDelete_product_should_return_200_OK() {
        com.hsbc.pdm.entities.Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(SUBMITTED_FOR_DELETION);
        product.setProductTypeInternalEnum(ProductTypeEnum.SMEL);
        process(product);
        ID productId = productRepository.insert(product).getId();

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/workflow/product/{product-type}/{id}"));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(product.getProductTypeInternal(), productId.toString());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.put(uri), PDM_TOKEN)
                .header("x-pdm-workflow-action", WorkflowActions.ACTION_REJECT_DELETE_REQUEST)
                .body(null);

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_SME_CHECKER);

        // call method under test
        ResponseEntity<Void> response = template.exchange(request, Void.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());

        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        assertEquals(APPROVED, productRepository.findOne(id).getStatusEnum());
    }

    @Test
    public void hardDelete_product_should_return_200_OK() {
        com.hsbc.pdm.entities.Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(DRAFT);
        product.setProductTypeInternalEnum(ProductTypeEnum.SMEL);
        process(product);
        ID productId = productRepository.insert(product).getId();

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/workflow/product/{product-type}/{id}"));
        uriBuilder.queryParam("version", product.getVersion());
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(product.getProductTypeInternal(), productId.toString());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.delete(uri), PDM_TOKEN).build();

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_SME_MAKER);

        // call method under test
        ResponseEntity<Void> response = template.exchange(request, Void.class);

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());

        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        assertNull(productRepository.findOne(id));
    }

    @Test
    public void getProductActions_should_return_actions() {
        // setup data
        com.hsbc.pdm.entities.Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(DRAFT);
        product.setProductTypeInternalEnum(ProductTypeEnum.CCC);
        process(product);
        productRepository.insert(product);

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url(PRODUCT_WORKFLOW_ACTIONS_URL));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(product.getProductTypeInternal(), product.getStatus(), product.getId());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.get(uri), PDM_TOKEN).build();

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_CMB_CCC_MAKER);

        // call method under test
        ResponseEntity<List<String>> response = template.exchange(request, new ParameterizedTypeReference<List<String>>() {});

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(true, response.getBody().size() > 0);
    }

    @Test
    public void getProductActions_when_Product_is_Not_Accessible_should_return_no_actions() {
        // setup data
        com.hsbc.pdm.entities.Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(DRAFT);
        product.setProductTypeInternalEnum(ProductTypeEnum.PCAHSBC); // PCA HSBC, hence not accessible
        process(product);
        productRepository.insert(product);

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url(PRODUCT_WORKFLOW_ACTIONS_URL));
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(product.getProductTypeInternal(), product.getStatus(), product.getId());
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.get(uri), PDM_TOKEN).build();

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_FD_CHECKER); // can access PCA FD only

        // call method under test
        ResponseEntity<List<String>> response = template.exchange(request, new ParameterizedTypeReference<List<String>>() {});

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(true, response.getBody().size() == 0);
    }

    @Test
    public void getProductTypeACL() {
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url("/workflow/acl/product-type"));
        UriComponents uriComponents = uriBuilder.build();
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = expandHeaders(RequestEntity.get(uri), PDM_TOKEN).build();

        // set expectations
        mockAuthorityProvider(PDM_TOKEN, "dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_CMB_CCC_CHECKER);

        // call method under test
        ResponseEntity<Map<String, Set<ProductTypeEnum>>> response = template.exchange(request, new ParameterizedTypeReference<Map<String, Set<ProductTypeEnum>>>() {});

        // verify expectations have been met
        verifyAuthorityProvider(PDM_TOKEN);

        // assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());

        Map<String, Set<ProductTypeEnum>> productTypeACL = response.getBody();

        Assert.assertEquals(0, productTypeACL.get("makerOf").size());
        Assert.assertEquals(1, productTypeACL.get("checkerOf").size());
        Assert.assertEquals(true, productTypeACL.get("checkerOf").contains(ProductTypeEnum.CCC));
    }
}
