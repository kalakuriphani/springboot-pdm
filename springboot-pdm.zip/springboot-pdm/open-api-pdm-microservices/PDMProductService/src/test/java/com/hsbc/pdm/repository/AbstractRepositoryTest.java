package com.hsbc.pdm.repository;

import com.hsbc.pdm.AbstractTest;
import com.hsbc.pdm.Datastore;
import com.hsbc.pdm.LocalDynamoDbContainer;
import com.hsbc.pdm.entities.Product;
import org.junit.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public abstract class AbstractRepositoryTest<ID> extends AbstractTest<ID> {

    @Autowired
    protected Datastore<Product<ID>, ID> datastore;

    @BeforeClass
    public static void beforeClass() {
        LocalDynamoDbContainer.start();
    }

    @AfterClass
    public static void afterClass() {
        LocalDynamoDbContainer.stop();
    }

    @Before
    public void setUp() {
        datastore.truncate();
    }
}
