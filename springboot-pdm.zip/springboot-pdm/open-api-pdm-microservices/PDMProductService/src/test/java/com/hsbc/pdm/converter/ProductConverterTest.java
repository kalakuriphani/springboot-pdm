package com.hsbc.pdm.converter;

import com.hsbc.pdm.productservice.model.Product;
import com.hsbc.pdm.service.AbstractServiceTest;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.List;

import static com.hsbc.pdm.common.model.StatusEnum.*;

public class ProductConverterTest<ID> extends AbstractServiceTest<ID> {

    @Autowired
    private ProductConverter<ID> productConverter;

    @Test
    public void convert_when_product_is_DRAFT_only() {
        com.hsbc.pdm.entities.Product<ID> entity = productEntitySamples.getExisting();
        entity.setStatusEnum(DRAFT);
        entity.setApprovedVariations(Collections.emptyList());
        Assert.assertEquals(true, entity.getVariations().size() > 0); // PREREQUISITE

        // call method under test
        List<Product> products = productConverter.convert(entity);

        // assert
        Assert.assertEquals(1, products.size());
        assertProduct(entity, products.get(0));
        Assert.assertEquals(DRAFT, products.get(0).getStatus());
        Assert.assertEquals(true, products.get(0).getVariations().size() > 0);
    }

    @Test
    public void convert_when_product_is_SUBMITTED_FOR_APPROVAL_only() {
        com.hsbc.pdm.entities.Product<ID> entity = productEntitySamples.getExisting();
        entity.setStatusEnum(SUBMITTED_FOR_APPROVAL);
        entity.setApprovedVariations(Collections.emptyList());
        Assert.assertEquals(true, entity.getVariations().size() > 0); // PREREQUISITE

        // call method under test
        List<Product> products = productConverter.convert(entity);

        // assert
        Assert.assertEquals(1, products.size());
        assertProduct(entity, products.get(0));
        Assert.assertEquals(true, products.get(0).getVariations().size() > 0);
        Assert.assertEquals(SUBMITTED_FOR_APPROVAL, products.get(0).getStatus());
    }

    @Test
    public void convert_when_product_is_APPROVED_only() {
        com.hsbc.pdm.entities.Product<ID> entity = productEntitySamples.getExisting();
        entity.setStatusEnum(APPROVED);
        entity.setApprovedVariations(entity.getVariations());
        entity.setVariations(Collections.emptyList());
        Assert.assertEquals(true, entity.getApprovedVariations().size() > 0); // PREREQUISITE

        // call method under test
        List<Product> products = productConverter.convert(entity);

        // assert
        Assert.assertEquals(1, products.size());
        assertProduct(entity, products.get(0));
        Assert.assertEquals(APPROVED, products.get(0).getStatus());
        Assert.assertEquals(true, products.get(0).getVariations().size() > 0);
    }

    @Test
    public void convert_when_product_is_SUBMITTED_FOR_DELETION_only() {
        com.hsbc.pdm.entities.Product<ID> entity = productEntitySamples.getExisting();
        entity.setStatusEnum(SUBMITTED_FOR_DELETION);
        entity.setApprovedVariations(entity.getVariations());
        entity.setVariations(Collections.emptyList());
        Assert.assertEquals(true, entity.getApprovedVariations().size() > 0); // PREREQUISITE

        // call method under test
        List<Product> products = productConverter.convert(entity);

        // assert
        Assert.assertEquals(2, products.size());
        assertProduct(entity, products.get(0));
        Assert.assertEquals(SUBMITTED_FOR_DELETION, products.get(0).getStatus());
        Assert.assertEquals(true, products.get(0).getVariations().size() > 0);
        assertProduct(entity, products.get(1));
        Assert.assertEquals(APPROVED, products.get(1).getStatus());
        Assert.assertEquals(true, products.get(1).getVariations().size() > 0);
    }

    @Test
    public void convert_when_product_is_DELETED_only() {
        com.hsbc.pdm.entities.Product<ID> entity = productEntitySamples.getExisting();
        entity.setStatusEnum(DELETED);
        entity.setApprovedVariations(entity.getVariations());
        entity.setVariations(Collections.emptyList());
        Assert.assertEquals(true, entity.getApprovedVariations().size() > 0); // PREREQUISITE

        // call method under test
        List<Product> products = productConverter.convert(entity);

        // assert
        Assert.assertEquals(1, products.size());
        assertProduct(entity, products.get(0));
        Assert.assertEquals(true, products.get(0).getVariations().size() > 0);
        Assert.assertEquals(DELETED, products.get(0).getStatus());
    }

    @Test
    public void convert_when_product_is_DRAFT_and_APPROVED() {
        com.hsbc.pdm.entities.Product<ID> entity = productEntitySamples.getExisting();
        Assert.assertEquals(true, entity.getVariations().size() > 0); // PREREQUISITE
        entity.setStatusEnum(DRAFT);
        entity.setApprovedVariations(entity.getVariations());

        // call method under test
        List<Product> products = productConverter.convert(entity);

        // assert
        Assert.assertEquals(2, products.size());
        assertProduct(entity, products.get(0));
        Assert.assertEquals(DRAFT, products.get(0).getStatus());
        Assert.assertEquals(true, products.get(0).getVariations().size() > 0);
        assertProduct(entity, products.get(1));
        Assert.assertEquals(APPROVED, products.get(1).getStatus());
        Assert.assertEquals(true, products.get(1).getVariations().size() > 0);
    }

    @Test
    public void convert_when_product_is_SUBMITTED_FOR_APPROVAL_and_APPROVED() {
        com.hsbc.pdm.entities.Product<ID> entity = productEntitySamples.getExisting();
        Assert.assertEquals(true, entity.getVariations().size() > 0); // PREREQUISITE
        entity.setStatusEnum(SUBMITTED_FOR_APPROVAL);
        entity.setApprovedVariations(entity.getVariations());

        // call method under test
        List<Product> products = productConverter.convert(entity);

        // assert
        Assert.assertEquals(2, products.size());
        assertProduct(entity, products.get(1));
        Assert.assertEquals(APPROVED, products.get(1).getStatus());
        Assert.assertEquals(true, products.get(1).getVariations().size() > 0);
        assertProduct(entity, products.get(0));
        Assert.assertEquals(SUBMITTED_FOR_APPROVAL, products.get(0).getStatus());
        Assert.assertEquals(true, products.get(0).getVariations().size() > 0);
    }

    @Test
    public void convert_from_entity_to_dto() {
        com.hsbc.pdm.entities.Product<ID> entity = productEntitySamples.getExisting();
        entity.setApprovedVariations(entity.getVariations());

        // call method under test
        List<Product> products = productConverter.convert(entity);

        // assert
        Assert.assertEquals(2, products.size()); // contains both DRAFT & APPROVED
        assertProduct(entity, products.get(0));
        assertProduct(entity, products.get(1));
        Assert.assertEquals(DRAFT, products.get(0).getStatus());
        Assert.assertEquals(APPROVED, products.get(1).getStatus());
    }

    private void assertProduct(com.hsbc.pdm.entities.Product<ID> expected, Product actual) {
        Assert.assertEquals(expected.getId().toString(), actual.getId());
        Assert.assertEquals(expected.getProductTypeInternalEnum(), actual.getProductType());
        Assert.assertEquals(expected.getProductTypeVersion(), actual.getProductTypeVersion());
        Assert.assertEquals(expected.getCreatedAt(), actual.getCreatedAt());
        Assert.assertEquals(expected.getUpdatedAt(), actual.getUpdatedAt());
        Assert.assertEquals(expected.getApprovedAt(), actual.getApprovedAt());
        Assert.assertEquals(expected.getCreatedBy(), actual.getCreatedBy());
        Assert.assertEquals(expected.getUpdatedBy(), actual.getUpdatedBy());
        Assert.assertEquals(expected.getApprovedBy(), actual.getApprovedBy());
        Assert.assertEquals(expected.getCountry(), actual.getCountry());
        Assert.assertEquals(expected.getVersion().intValue(), actual.getVersion());
    }
}
