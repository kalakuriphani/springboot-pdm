package com.hsbc.pdm;

import com.hsbc.openbanking.jsonschema.ProductDetailsProcessor;
import com.hsbc.pdm.auth.PDMAuthenticationToken;
import com.hsbc.pdm.entities.Product;
import com.hsbc.pdm.entities.ProductVariation;
import org.junit.Ignore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by 44023148 on 27/01/2017.
 */
@Ignore
public abstract class AbstractTest<ID> {

    protected static final Object BLANK_CREDENTIAL = null;

    protected static final Object PRODUCT_ID_DOES_NOT_MATTER = null;

    protected static final String[] ALL_ROLES = new String[] {
        "INFODIR-OBA-PDM-CMB-MAKER",
        "INFODIR-OBA-PDM-CMB-CHECKER",
        "INFODIR-OBA-PDM-RWMB-MAKER",
        "INFODIR-OBA-PDM-RWMB-CHECKER",
        "INFODIR-OBA-PDM-SME-MAKER",
        "INFODIR-OBA-PDM-SME-CHECKER",
        "INFODIR-OBA-PDM-FD-MAKER",
        "INFODIR-OBA-PDM-FD-CHECKER",
        "INFODIR-OBA-PDM-MANDS-MAKER",
        "INFODIR-OBA-PDM-MANDS-CHECKER",
        "INFODIR-OBA-PDM-CMB-CCC-MAKER",
        "INFODIR-OBA-PDM-CMB-CCC-CHECKER",
        "INFODIR-OBA-PDM-SUPPORT",
    };


    @Autowired
    protected ProductEntitySamples<ID> productEntitySamples;

    @Autowired
    protected ProductDetailsProcessor productDetailsProcessor;


    protected Authentication createAuthentication(String username, String... roles) {
        List<GrantedAuthority> authorities = getAuthorities(roles);
        Authentication authentication = new PDMAuthenticationToken("pdm-token", "auth-token", createUser(username, roles), BLANK_CREDENTIAL, authorities);
        authentication.setAuthenticated(true);
        return authentication;
    }

    protected Authentication createDummyAuthentication(String... roles) {
        return createAuthentication("dummy-user", roles);
    }

    protected UserDetails createUser(String username, String... roles) {
        return new User(username, "N/A", getAuthorities(roles));
    }

    protected List<GrantedAuthority> getAuthorities(String... roles) {
        return Arrays.stream(roles).map((Function<String, GrantedAuthority>) SimpleGrantedAuthority::new).collect(Collectors.toList());
    }

    protected void process(Product<ID> product) {
        try {
            process(product.getVariations());
            process(product.getApprovedVariations());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    protected void process(List<ProductVariation> variations) throws IOException {
        for (ProductVariation variation : variations) {
            variation.setDetails(productDetailsProcessor.process(variation.getDetails()));
        }
    }
}
