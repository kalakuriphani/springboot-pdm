package com.hsbc.pdm.service;

import com.hsbc.pdm.ProductAssert;
import com.hsbc.pdm.common.*;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.converter.ProductVariationConverter;
import com.hsbc.pdm.entities.Product;
import com.hsbc.pdm.entities.dynamo.DynamoProductAudit;
import com.hsbc.pdm.repository.ProductRepository;
import com.hsbc.pdm.repository.dynamo.DynamoProductAuditRepository;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

import static com.hsbc.pdm.ProductModelSamples.*;
import static com.hsbc.pdm.common.UserRoles.*;
import static com.hsbc.pdm.common.WorkflowActions.*;
import static com.hsbc.pdm.common.model.StatusEnum.*;
import static java.util.Arrays.asList;

public class ProductWorkflowServiceTest<ID> extends AbstractServiceTest<ID> {

    private static final String[] NO_EXPECTED_ACTIONS = new String[0];

    @Autowired
    private ProductWorkflowService<ID> productWorkflowService;

    @Autowired
    private ProductRepository<Product<ID>, ID> productRepository;

    @Autowired
    private ProductVariationConverter productVariationConverter;

    @Autowired
    private ProductFactory<ID> productFactory;


    @Test
    public void create_new_product_should_insert() {
        com.hsbc.pdm.productservice.model.Product product = getBrandNew(PRODUCT_ID, ProductTypeEnum.SMEL, PRODUCT_VERSION_SMEL);

        Authentication authentication = createAuthentication("dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_SME_MAKER);

        // call method under test
        ID id = productWorkflowService.create(product, authentication);

        // assert
        Product<ID> actual = productRepository.findOne(productFactory.createId(id.toString(), product.getProductType()));
        Assert.assertEquals(getProductName(product.getProductType(), PRODUCT_VERSION_PCA_HSBC, product.getVariations().get(0)), actual.getProductName());
        Assert.assertEquals(product.getProductType(), actual.getProductTypeInternalEnum());
        Assert.assertEquals(DRAFT, actual.getStatusEnum());
        Assert.assertEquals("dummy-user", actual.getCreatedBy());
        Assert.assertNotNull(actual.getCreatedAt());
        Assert.assertNotNull(actual.getVariations());
        Assert.assertEquals(1, actual.getVariations().size());
        ProductAssert.assertProductDetailsEquals(product.getVariations().get(0).getDetails(), actual.getVariations().get(0).getDetails());
        Assert.assertEquals(0, actual.getApprovedVariations().size());
    }

    @Test
    public void copy_product_should_insert_as_DRAFT() {
        com.hsbc.pdm.productservice.model.Product product = getBrandNew(PRODUCT_ID, ProductTypeEnum.SMEL, PRODUCT_VERSION_SMEL);

        Authentication authentication = createDummyAuthentication(UserRoles.ROLE_INFODIR_OBA_PDM_SME_MAKER);

        // call method under test
        ID id = productWorkflowService.copy(product, authentication);

        // assert
        Product<ID> actual = productRepository.findOne(productFactory.createId(id.toString(), product.getProductType()));
        Assert.assertEquals(true, actual.getProductName().startsWith("some product name - copy from "));
        Assert.assertEquals(product.getProductType(), actual.getProductTypeInternalEnum());
        Assert.assertEquals(DRAFT, actual.getStatusEnum());
        Assert.assertEquals("dummy-user", actual.getCreatedBy());
        Assert.assertNotNull(actual.getCreatedAt());
        Assert.assertNotNull(actual.getVariations());
        Assert.assertEquals(1, actual.getVariations().size());
        Assert.assertEquals(true, getProductName(ProductTypeEnum.SMEL, PRODUCT_VERSION_PCA_HSBC, actual.getVariations().get(0)).startsWith("some product name - copy from "));
        Assert.assertEquals(0, actual.getApprovedVariations().size());
    }

    @Test
    public void create_new_product_should_have_version_1() {
        com.hsbc.pdm.productservice.model.Product product = getBrandNew(PRODUCT_ID, ProductTypeEnum.SMEL, PRODUCT_VERSION_SMEL);
        product.setVersion(123);

        Authentication authentication = createDummyAuthentication(UserRoles.ROLE_INFODIR_OBA_PDM_SME_MAKER);

        // call method under test
        ID id = productWorkflowService.create(product, authentication);

        // assert
        Product actual = productRepository.findOne(productFactory.createId(id.toString(), product.getProductType()));
        Assert.assertEquals(true, actual.getVersion() == 0 || actual.getVersion() == 1); // 0 for Mongo, 1 - for Dynamo
    }

    @Test
    public void update_existing_product_should_update() {
        Product<ID> product = productEntitySamples.getExisting();
        process(product);
        productRepository.insert(product);

        Authentication authentication = createDummyAuthentication(UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);

        product.getVariations().get(0).getDetails().put("property234", "some value");

        // call method under test
        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        productWorkflowService.update(id, productVariationConverter.convertEntities(product.getVariations()), authentication);

        // assert
        Product<ID> actual = productRepository.findOne(id);
        Assert.assertEquals(product.getVersion() + 1, actual.getVersion().intValue()); // new version
        Assert.assertEquals(1, product.getVariations().size());
        ProductAssert.assertProductDetailsEquals(product.getVariations().get(0).getDetails(), actual.getVariations().get(0).getDetails());
        Assert.assertNotNull(actual.getVariations().get(0).getDetails().get("property234"));
        Assert.assertEquals("some value", actual.getVariations().get(0).getDetails().get("property234"));
        Assert.assertEquals(0, product.getApprovedVariations().size());
    }

    @Test
    public void update_APPROVED_product_should_save_status_as_DRAFT() {
        Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(APPROVED);
        process(product);
        productRepository.insert(product);

        Authentication authentication = createDummyAuthentication(UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);

        // call method under test
        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        productWorkflowService.update(id, productVariationConverter.convertEntities(product.getVariations()), authentication);

        // assert
        product = productRepository.findOne(id);
        Assert.assertEquals(DRAFT, product.getStatusEnum());
    }

    @Test
    public void update_APPROVED_product_should_change_into_DRAFT_and_update_working_copy_variations() {
        Product<ID> product = productEntitySamples.getExisting();
        product.setVariations(Collections.emptyList());
        product.setApprovedVariations(asList(productEntitySamples.buildVariation(), productEntitySamples.buildVariation())); // 2 APPROVED variations
        product.setStatusEnum(APPROVED);
        process(product);
        productRepository.insert(product);

        Authentication authentication = createDummyAuthentication(UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);

        // call method under test
        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        productWorkflowService.update(id, asList(buildVariation()), authentication); // update with 1 variation

        // assert
        product = productRepository.findOne(id);
        Assert.assertEquals(DRAFT, product.getStatusEnum());
        Assert.assertEquals(2, product.getApprovedVariations().size());
        Assert.assertEquals(1, product.getVariations().size());
    }

    @Test
    public void approveChange() throws PreconditionFailedException {
        Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(SUBMITTED_FOR_APPROVAL);
        product.setUpdatedBy("some-user");
        product.setUpdatedAt(YESTERDAY_DATE);
        product.setApprovedAt(null);
        product.setApprovedBy(null);
        product.setVersion(1);
        process(product);
        productRepository.insert(product);

        Authentication authentication = createAuthentication("dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);

        // call method under test
        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        productWorkflowService.approveChange(id, authentication);

        // assert
        Product<ID> actual = productRepository.findOne(id);
        Assert.assertEquals(true, actual.getUpdatedAt().after(product.getUpdatedAt())); // updated
        Assert.assertEquals("dummy-user", actual.getUpdatedBy()); // updated
        Assert.assertEquals(APPROVED, actual.getStatusEnum()); // updated
        Assert.assertNotNull(actual.getApprovedAt()); // updated
        Assert.assertNotNull(actual.getApprovedBy()); // updated
        Assert.assertEquals(product.getVersion() + 1, actual.getVersion().intValue()); // updated
    }

    @Test
    public void approveDelete() throws PreconditionFailedException {
        Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(SUBMITTED_FOR_DELETION);
        product.setUpdatedBy("some-user");
        product.setUpdatedAt(YESTERDAY_DATE);
        product.setVersion(1);
        process(product);
        productRepository.insert(product).getId();

        Authentication authentication = createAuthentication("dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);

        // call method under test
        ID id = productFactory.createId(product.getId().toString(), ProductTypeEnum.valueOf(product.getProductTypeInternal()));
        productWorkflowService.approveDelete(id, authentication);

        // assert
        Product<ID> actual = productRepository.findOne(id);
        Assert.assertEquals(true, actual.getUpdatedAt().after(product.getUpdatedAt())); // updated
        Assert.assertEquals("dummy-user", actual.getUpdatedBy()); // updated
        Assert.assertEquals(DELETED, actual.getStatusEnum()); // updated
        Assert.assertEquals(product.getVersion() + 1, actual.getVersion().intValue()); // updated
    }

    @Test
    public void rejectChange() throws PreconditionFailedException {
        Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(SUBMITTED_FOR_APPROVAL);
        product.setUpdatedBy("some-user");
        product.setUpdatedAt(YESTERDAY_DATE);
        product.setVersion(1);
        process(product);
        productRepository.insert(product).getId();

        Authentication authentication = createAuthentication("dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);

        // call method under test
        ID id = productFactory.createId(product.getId().toString(), ProductTypeEnum.valueOf(product.getProductTypeInternal()));
        productWorkflowService.rejectChange(id, authentication);

        // assert
        Product<ID> actual = productRepository.findOne(id);
        Assert.assertEquals(true, actual.getUpdatedAt().after(product.getUpdatedAt())); // updated
        Assert.assertEquals("dummy-user", actual.getUpdatedBy()); // updated
        Assert.assertEquals(DRAFT, actual.getStatusEnum()); // updated
        Assert.assertEquals(product.getVersion() + 1, actual.getVersion().intValue()); // updated
    }

    @Test
    public void rejectDelete() throws PreconditionFailedException {
        Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(SUBMITTED_FOR_DELETION);
        product.setUpdatedBy("some-user");
        product.setUpdatedAt(YESTERDAY_DATE);
        product.setVersion(1);
        process(product);
        productRepository.insert(product).getId();

        Authentication authentication = createAuthentication("dummy-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);

        // call method under test
        ID id = productFactory.createId(product.getId().toString(), ProductTypeEnum.valueOf(product.getProductTypeInternal()));
        productWorkflowService.rejectDelete(id, authentication);

        // assert
        Product<ID> actual = productRepository.findOne(id);
        Assert.assertEquals(true, actual.getUpdatedAt().after(product.getUpdatedAt())); // updated
        Assert.assertEquals("dummy-user", actual.getUpdatedBy()); // updated
        Assert.assertEquals(APPROVED, actual.getStatusEnum()); // updated
        Assert.assertEquals(product.getVersion() + 1, actual.getVersion().intValue()); // updated
    }

    @Test
    public void hardDelete_DRAFT_product_should_hard_delete() {
        hardDelete_with_Status_should_hard_delete(DRAFT);
    }

    private void hardDelete_with_Status_should_hard_delete(StatusEnum productStatus) {
        Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(productStatus);
        process(product);
        productRepository.insert(product);

        Authentication authentication = createDummyAuthentication(UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);

        // call method under test
        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        productWorkflowService.hardDelete(id, authentication);

        // assert
        product = productRepository.findOne(id);
        Assert.assertNull(product);
    }

    @Test
    public void requestDelete_APPROVED_product() {
        Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(APPROVED);
        product.setUpdatedBy("some-user");
        product.setUpdatedAt(YESTERDAY_DATE);
        process(product);
        productRepository.insert(product);

        Authentication authentication = createDummyAuthentication(UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);

        // call method under test
        ID id = productFactory.createId(product.getId().toString(), ProductTypeEnum.valueOf(product.getProductTypeInternal()));
        productWorkflowService.requestDelete(id, authentication);

        // assert
        Product<ID> actual = productRepository.findOne(id);
        Assert.assertEquals(SUBMITTED_FOR_DELETION, actual.getStatusEnum());
        Assert.assertEquals(true, actual.getUpdatedAt().after(product.getUpdatedAt())); // updated
        Assert.assertEquals("dummy-user", actual.getUpdatedBy()); // updated
        Assert.assertEquals(product.getVersion() + 1, actual.getVersion().intValue()); // updated
    }

    @Test
    public void requestApprove() {
        Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(DRAFT);
        product.setUpdatedBy("some-user");
        product.setUpdatedAt(YESTERDAY_DATE);
        product.setVersion(1);
        process(product);
        productRepository.insert(product);

        Authentication authentication = createDummyAuthentication(UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);

        // call method under test
        ID id = productFactory.createId(product.getId().toString(), ProductTypeEnum.valueOf(product.getProductTypeInternal()));
        productWorkflowService.requestApprove(id, authentication);

        // assert
        Product<ID> actual = productRepository.findOne(id);
        Assert.assertEquals(SUBMITTED_FOR_APPROVAL, actual.getStatusEnum());
        Assert.assertEquals(true, actual.getUpdatedAt().after(product.getUpdatedAt())); // updated
        Assert.assertEquals("dummy-user", actual.getUpdatedBy()); // updated
        Assert.assertEquals(product.getVersion() + 1, actual.getVersion().intValue()); // updated
    }

    /**
     * Besides testing isProductAccessible(..) this test
     * also tests the relation between ProductType and allowed Roles on it.
     */
    @Test
    public void isProductAccessible_when_Status_is_BCA_and_User_is_BCA_Maker_should_return_true() {
        isProductAccessible_should_return_true(ProductTypeEnum.BCA, ROLE_INFODIR_OBA_PDM_CMB_MAKER);
        isProductAccessible_should_return_true(ProductTypeEnum.BCA, ROLE_INFODIR_OBA_PDM_CMB_CHECKER);

        isProductAccessible_should_return_true(ProductTypeEnum.SMEL, ROLE_INFODIR_OBA_PDM_SME_MAKER);
        isProductAccessible_should_return_true(ProductTypeEnum.SMEL, ROLE_INFODIR_OBA_PDM_SME_CHECKER);

        isProductAccessible_should_return_true(ProductTypeEnum.CCC, ROLE_INFODIR_OBA_PDM_CMB_CCC_MAKER);
        isProductAccessible_should_return_true(ProductTypeEnum.CCC, ROLE_INFODIR_OBA_PDM_CMB_CCC_CHECKER);

        isProductAccessible_should_return_true(ProductTypeEnum.PCAHSBC, ROLE_INFODIR_OBA_PDM_RWMB_MAKER);
        isProductAccessible_should_return_true(ProductTypeEnum.PCAHSBC, ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);

        isProductAccessible_should_return_true(ProductTypeEnum.PCAFD, ROLE_INFODIR_OBA_PDM_FD_MAKER);
        isProductAccessible_should_return_true(ProductTypeEnum.PCAFD, ROLE_INFODIR_OBA_PDM_FD_CHECKER);

        isProductAccessible_should_return_true(ProductTypeEnum.PCAMNS, ROLE_INFODIR_OBA_PDM_MANDS_MAKER);
        isProductAccessible_should_return_true(ProductTypeEnum.PCAMNS, ROLE_INFODIR_OBA_PDM_MANDS_CHECKER);
    }

    private void isProductAccessible_should_return_true(ProductTypeEnum productType, String... roles) {
        Authentication authentication = createDummyAuthentication(roles);

        // call method under test
        boolean accessible = productWorkflowService.isProductAccessible(productType, authentication);

        // assert
        Assert.assertEquals(true, accessible);
    }

    @Test
    public void isProductAccessible_when_Status_is_SMEL_and_User_is_CCC_Maker_should_return_false() {
        Authentication authentication = createDummyAuthentication(ROLE_INFODIR_OBA_PDM_CMB_CCC_MAKER);

        // call method under test
        boolean accessible = productWorkflowService.isProductAccessible(ProductTypeEnum.SMEL, authentication);

        // assert
        Assert.assertEquals(false, accessible);
    }

    @Test
    public void getUserActions_when_Status_is_DRAFT_and_User_is_MAKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.DRAFT,
                RoleType.MAKER_ROLES,
                ACTION_EDIT, ACTION_COPY, ACTION_REQUEST_APPROVE, ACTION_HARD_DELETE);
    }

    @Test
    public void getUserActions_when_Status_is_SUBMITTED_FOR_APPROVAL_and_User_is_MAKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.SUBMITTED_FOR_APPROVAL,
                RoleType.MAKER_ROLES,
                ACTION_COPY);
    }

    @Test
    public void getUserActions_when_Status_is_SUBMITTED_FOR_DELETION_and_User_is_MAKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.SUBMITTED_FOR_DELETION,
                RoleType.MAKER_ROLES,
                ACTION_COPY);
    }

    @Test
    public void getUserActions_when_Status_is_APPROVED_and_User_is_MAKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.APPROVED,
                RoleType.MAKER_ROLES,
                ACTION_EDIT, ACTION_COPY, ACTION_REQUEST_DELETE);
    }

    @Test
    public void getUserActions_when_Status_is_PUBLISHED_and_User_is_MAKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.PUBLISHED,
                RoleType.MAKER_ROLES,
                ACTION_EDIT, ACTION_COPY, ACTION_REQUEST_DELETE);
    }

    @Test
    public void getUserActions_when_Status_is_SUSPENDED_and_User_is_MAKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.SUSPENDED,
                RoleType.MAKER_ROLES,
                ACTION_EDIT, ACTION_COPY, ACTION_REQUEST_APPROVE, ACTION_REQUEST_DELETE);
    }

    @Test
    public void getUserActions_when_Status_is_DELETED_and_User_is_MAKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.DELETED,
                RoleType.MAKER_ROLES,
                ACTION_COPY);
    }

    @Test
    public void getUserActions_when_Status_is_DRAFT_and_User_is_CHECKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.DRAFT,
                RoleType.CHECKER_ROLES,
                NO_EXPECTED_ACTIONS);
    }

    @Test
    public void getUserActions_when_Status_is_SUBMITTED_FOR_APPROVAL_and_User_is_CHECKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.SUBMITTED_FOR_APPROVAL,
                RoleType.CHECKER_ROLES,
                ACTION_APPROVE_CHANGE_REQUEST, ACTION_REJECT_CHANGE_REQUEST);
    }

    @Test
    public void getUserActions_when_Status_is_SUBMITTED_FOR_DELETION_and_User_is_CHECKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.SUBMITTED_FOR_DELETION,
                RoleType.CHECKER_ROLES,
                ACTION_APPROVE_DELETE_REQUEST, ACTION_REJECT_DELETE_REQUEST);
    }

    @Test
    public void getUserActions_when_Status_is_APPROVED_and_User_is_CHECKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.APPROVED,
                RoleType.CHECKER_ROLES,
                NO_EXPECTED_ACTIONS);
    }

    @Test
    public void getUserActions_when_Status_is_PUBLISHED_and_User_is_CHECKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.PUBLISHED,
                RoleType.CHECKER_ROLES,
                ACTION_SUSPEND);
    }

    @Test
    public void getUserActions_when_Status_is_SUSPENDED_and_User_is_CHECKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.SUSPENDED,
                RoleType.CHECKER_ROLES,
                ACTION_APPROVE_CHANGE_REQUEST);
    }

    @Test
    public void getUserActions_when_Status_is_DELETED_and_User_is_CHECKER_should_return_actions() {
        getUserActions_for_Product_Status_and_User_Role_should_return_actions(
                StatusEnum.DELETED,
                RoleType.CHECKER_ROLES,
                NO_EXPECTED_ACTIONS);
    }

    private void getUserActions_for_Product_Status_and_User_Role_should_return_actions(StatusEnum productStatus, RoleType roleType, String... expectedActions) {
        for (String role : roleType.getRoles()) {
            Authentication authentication = createDummyAuthentication(role);

            // call method under test
            Set<String> actions = productWorkflowService.getUserActions(productStatus, authentication);

            // assert
            Assert.assertEquals(expectedActions.length, actions.size());
            for (String action : expectedActions) {
                Assert.assertEquals(true, actions.contains(action));
            }
        }
    }

    @Test
    public void getUserActions_when_Product_is_DRAFT_and_User_is_MAKER_should_return_actions() {
        Product<ID> product = productEntitySamples.getExisting();
        product.setStatusEnum(DRAFT);
        product.setProductTypeInternalEnum(ProductTypeEnum.CCC);
        process(product);
        productRepository.insert(product);

        Authentication authentication = createDummyAuthentication(UserRoles.ROLE_INFODIR_OBA_PDM_CMB_CCC_MAKER);

        // call method under test
        ID id = productFactory.createId(product.getId().toString(), product.getProductTypeInternalEnum());
        Set<String> actions = productWorkflowService.getUserActions(id, DRAFT, authentication);

        // assert
        Assert.assertEquals(4, actions.size());
    }

    @Test
    public void validateActions_for_Product_Status_when_User_is_MAKER() {
        // validate EDIT action when Product is DRAFT and User is MAKER
        validateAction_for_Product_Status_when_User_is_MAKER(WorkflowActions.ACTION_EDIT, DRAFT);
        // validate EDIT action when Product is APPROVED and User is MAKER
        validateAction_for_Product_Status_when_User_is_MAKER(WorkflowActions.ACTION_EDIT, APPROVED);
        // TODO : test more positive scenarios
    }

    private void validateAction_for_Product_Status_when_User_is_MAKER(String action, StatusEnum productStatus) {
        Authentication authentication = createDummyAuthentication(UserRoles.ROLE_INFODIR_OBA_PDM_CMB_CCC_MAKER);

        // call method under test
        productWorkflowService.validateAction(action, ProductTypeEnum.CCC, productStatus, authentication);
    }

    // TODO : test more negative scenarios
    @Test(expected = WorkflowActionNotAllowedException.class)
    public void validateAction_EDIT_when_Product_is_CCC_and_DRAFT_and_User_is_CHECKER() {
        Authentication authentication = createDummyAuthentication(UserRoles.ROLE_INFODIR_OBA_PDM_CMB_CCC_CHECKER);

        // call method under test
        productWorkflowService.validateAction(WorkflowActions.ACTION_EDIT, ProductTypeEnum.CCC, DRAFT, authentication);
    }

    @Test
    public void getALC_when_user_has_access_to_all_product_types_should_return_full_ACL() {
        Authentication authentication = createDummyAuthentication(ALL_ROLES);

        // call method under test
        Map<UserRoles.RoleType, Set<ProductTypeEnum>> acl = productWorkflowService.getProductTypeACL(authentication);

        // assert
        Assert.assertEquals(RoleType.values().length, acl.size());

        for (RoleType roleType : RoleType.values()) {
            Set<ProductTypeEnum> productTypes = acl.get(roleType);
            Assert.assertEquals(ProductTypeEnum.values().length, productTypes.size());
        }
    }

    @Test
    public void getALC_when_user_is_CCC_MAKER_should_return_partial_ACL() {
        getALC_when_user_has_RoleType_and_can_access_ProductType_should_return_partial_ACL(
                RoleType.MAKER_ROLES,
                ProductTypeEnum.CCC,
                UserRoles.ROLE_INFODIR_OBA_PDM_CMB_CCC_MAKER);

        getALC_when_user_has_RoleType_and_can_access_ProductType_should_return_partial_ACL(
                RoleType.CHECKER_ROLES,
                ProductTypeEnum.CCC,
                UserRoles.ROLE_INFODIR_OBA_PDM_CMB_CCC_CHECKER);
    }

    @Test
    public void isApprovalAllowed_when_user_is_not_checker() {
        Authentication maker = createAuthentication("maker-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);
        try {
            // call method under test
            productWorkflowService.isApprovalAllowed((ID) PRODUCT_ID_DOES_NOT_MATTER, maker);
            Assert.fail("Exception is expected, but none was thrown");
        } catch (Exception e) {
            // all good here
            Assert.assertEquals("The user 'maker-user' is not a checker role", e.getMessage());
        }
    }

    @Test
    public void isApprovalAllowed_when_product_has_never_been_approved_yet_then_approval_should_be_allowed() {
        Authentication maker = createAuthentication("maker-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);
        com.hsbc.pdm.productservice.model.Product product = getBrandNew(PRODUCT_ID, ProductTypeEnum.PCAHSBC, PRODUCT_VERSION_PCA_HSBC);
        ID id = productWorkflowService.create(product, maker);

        ID productId = productFactory.createId(id.toString(), product.getProductType());
        datastore.auditCreate(maker.getName(), productId);

        productWorkflowService.requestApprove(productId, maker);
        datastore.auditUpdate(maker.getName(), productId,
                new DynamoProductAudit.ProductDifference("Version", 1, 2)
        );

        // call method under test
        Authentication checker = createAuthentication("checker-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);
        boolean allowed = productWorkflowService.isApprovalAllowed(productId, checker);

        // assert
        Assert.assertEquals(true, allowed);
    }

    @Test
    public void approveChange_when_product_has_never_been_approved_yet_then_approval_should_be_allowed() {
        Authentication maker = createAuthentication("maker-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);
        com.hsbc.pdm.productservice.model.Product product = getBrandNew(PRODUCT_ID, ProductTypeEnum.PCAHSBC, PRODUCT_VERSION_PCA_HSBC);
        ID id = productWorkflowService.create(product, maker);

        ID productId = productFactory.createId(id.toString(), product.getProductType());
        datastore.auditCreate(maker.getName(), productId);

        productWorkflowService.requestApprove(productId, maker);
        datastore.auditUpdate(maker.getName(), productId,
                new DynamoProductAudit.ProductDifference("Version", 1, 2)
        );

        // call method under test
        Authentication checker = createAuthentication("checker-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);
        productWorkflowService.approveChange(productId, checker);

        // assert
        Product<ID> actual = productRepository.findOne(productId);
        Assert.assertEquals(APPROVED, actual.getStatusEnum());
    }

    @Test
    public void approveChange_when_product_is_created_and_approved_by_same_user_then_approval_should_not_be_allowed() {
        Authentication makerChecker = createAuthentication("maker-checker-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER, UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);
        com.hsbc.pdm.productservice.model.Product product = getBrandNew(PRODUCT_ID, ProductTypeEnum.PCAHSBC, PRODUCT_VERSION_PCA_HSBC);
        ID id = productWorkflowService.create(product, makerChecker);

        ID productId = productFactory.createId(id.toString(), product.getProductType());
        datastore.auditCreate(makerChecker.getName(), productId);

        productWorkflowService.requestApprove(productId, makerChecker);
        datastore.auditUpdate(makerChecker.getName(), productId,
                new DynamoProductAudit.ProductDifference("Version", 1, 2)
        );

        // call method under test
        assertApproveChangeNotAllowed(productId, makerChecker);
    }

    @Test
    public void approveChange_when_maker_checker_user_has_not_done_changes_since_last_approved_state_then_approval_should_be_allowed() {
        Authentication maker = createAuthentication("maker-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);
        com.hsbc.pdm.productservice.model.Product product = getBrandNew(PRODUCT_ID, ProductTypeEnum.PCAHSBC, PRODUCT_VERSION_PCA_HSBC);
        ID id = productWorkflowService.create(product, maker);

        ID productId = productFactory.createId(id.toString(), product.getProductType());
        datastore.auditCreate(maker.getName(), productId);

        productWorkflowService.requestApprove(productId, maker);
        datastore.auditUpdate(maker.getName(), productId,
                new DynamoProductAudit.ProductDifference("Version", 1, 2)
        );

        Authentication makerChecker = createAuthentication("maker-checker-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER, UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);
        productWorkflowService.approveChange(productId, makerChecker);
        datastore.auditUpdate(makerChecker.getName(), productId,
                new DynamoProductAudit.ProductDifference("Version", 2, 3),
                new DynamoProductAudit.ProductDifference("ApprovedAt", null, product.getApprovedAt()),
                new DynamoProductAudit.ProductDifference("ApprovedBy", null, product.getApprovedBy())
        );

        productWorkflowService.update(productId, product.getVariations(), maker); // maker updates the product
        datastore.auditUpdate(maker.getName(), productId,
                new DynamoProductAudit.ProductDifference("Version", 3, 4)
        );

        productWorkflowService.requestApprove(productId, maker); // maker submits for approval
        datastore.auditUpdate(maker.getName(), productId,
                new DynamoProductAudit.ProductDifference("Version", 4, 5)
        );

        // call method under test
        productWorkflowService.approveChange(productId, makerChecker);

        // assert
        Product<ID> actual = productRepository.findOne(productId);
        Assert.assertEquals(APPROVED, actual.getStatusEnum());
    }

    @Test
    public void isApprovalAllowed_when_user_has_done_some_changes_since_last_approved_state_then_approval_should_not_be_allowed() {
        Authentication maker = createAuthentication("maker-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER);
        com.hsbc.pdm.productservice.model.Product product = getBrandNew(PRODUCT_ID, ProductTypeEnum.PCAHSBC, PRODUCT_VERSION_PCA_HSBC);
        ID id = productWorkflowService.create(product, maker);

        ID productId = productFactory.createId(id.toString(), product.getProductType());
        datastore.auditCreate(maker.getName(), productId);

        productWorkflowService.requestApprove(productId, maker);
        datastore.auditUpdate(maker.getName(), productId,
                new DynamoProductAudit.ProductDifference("Version", 1, 2)
        );

        Authentication makerChecker = createAuthentication("maker-checker-user", UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_MAKER, UserRoles.ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);
        productWorkflowService.approveChange(productId, makerChecker);
        datastore.auditUpdate(makerChecker.getName(), productId,
                new DynamoProductAudit.ProductDifference("Version", 2, 3),
                new DynamoProductAudit.ProductDifference("ApprovedAt", null, product.getApprovedAt()),
                new DynamoProductAudit.ProductDifference("ApprovedBy", null, product.getApprovedBy())
        );

        productWorkflowService.update(productId, product.getVariations(), makerChecker); // maker-checker updates the product
        datastore.auditUpdate(makerChecker.getName(), productId,
                new DynamoProductAudit.ProductDifference("Version", 3, 4)
        );

        productWorkflowService.requestApprove(productId, maker); // maker submits for approval
        datastore.auditUpdate(maker.getName(), productId,
                new DynamoProductAudit.ProductDifference("Version", 4, 5)
        );

        // call method under test
        assertApproveChangeNotAllowed(productId, makerChecker);
    }

    private void assertApproveChangeNotAllowed(ID productId, Authentication authentication) {
        try {
            // call method under test
            productWorkflowService.approveChange(productId, authentication);
            Assert.fail("Exception is expected, but none was thrown");
        } catch (Exception e) {
            Assert.assertEquals(UserFriendlyException.class, e.getClass());
            Assert.assertEquals("The user '" + authentication.getName() + "' is not allowed to approve the product as the document has changes owned by this user since last time approved", e.getMessage());
        }
    }

    private void getALC_when_user_has_RoleType_and_can_access_ProductType_should_return_partial_ACL(RoleType roleType, ProductTypeEnum productType, String... roles) {
        Authentication authentication = createDummyAuthentication(roles);

        // call method under test
        Map<UserRoles.RoleType, Set<ProductTypeEnum>> acl = productWorkflowService.getProductTypeACL(authentication);

        // assert
        Assert.assertEquals(RoleType.values().length, acl.size());

        for (RoleType type : RoleType.values()) {
            Set<ProductTypeEnum> productTypes = acl.get(type);
            if (type == roleType) {
                Assert.assertEquals(1, productTypes.size());
                Assert.assertEquals(true, productTypes.contains(productType));
                continue;
            }
            Assert.assertEquals(0, productTypes.size());
        }
    }
}
