package com.hsbc.pdm.repository.dynamo;

import com.hsbc.pdm.entities.dynamo.DynamoProduct;
import com.hsbc.pdm.entities.dynamo.DynamoProductAudit;
import com.hsbc.pdm.repository.AbstractRepositoryTest;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;

import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static com.hsbc.pdm.common.model.StatusEnum.APPROVED;
import static com.hsbc.pdm.common.model.StatusEnum.DRAFT;

@Ignore
@ActiveProfiles(value = { "default", "dynamo" })
public class DynamoProductAuditRepositoryTest extends AbstractRepositoryTest<String> {

    private static final String MAKER_USER = "maker-user";

    private static final String CHECKER_USER = "checker-user";

    private static final String MAKER_CHECKER_USER = "maker-checker-user";

    @Autowired
    private DynamoProductRepository productRepository;

    @Autowired
    private DynamoProductAuditRepository productAuditRepository;

    @Test
    public void getUserAudits_of_checker_user_when_product_has_never_been_approved_yet() {
        // create a DRAFT product
        DynamoProduct product = (DynamoProduct) productEntitySamples.getBrandNew();
        product.setVariations(Collections.emptyList()); // not used, just make the payload lighter
        product.setApprovedVariations(Collections.emptyList()); // not used, just make the payload lighter
        product.setCreatedBy(MAKER_USER);
        product.setUpdatedBy(null);
        product.setApprovedBy(null);
        product.setApprovedAt(null);
        product.setStatusEnum(DRAFT);
        product.setVersion(1);
        process(product);
        productRepository.insert(product);
        datastore.auditCreate(MAKER_USER, product);

        DynamoProduct.Id productId = new DynamoProduct.Id(product.getProductTypeInternal(), product.getId());
        Date since = new Date(Instant.now().minus(Duration.ofDays(1)).toEpochMilli()); // past date

        // call method under test
        List<DynamoProductAudit> audits = productAuditRepository.getUserAudits(CHECKER_USER, productId, since);

        // assert
        Assert.assertEquals(0, audits.size());
    }

    @Test
    public void getUserAudits_of_checker_user_when_product_is_in_approved_state() {
        // create an APPROVED product
        DynamoProduct product = (DynamoProduct) productEntitySamples.getBrandNew();
        product.setVariations(Collections.emptyList()); // not used, just make the payload lighter
        product.setApprovedVariations(Collections.emptyList()); // not used, just make the payload lighter
        product.setCreatedBy(MAKER_USER);
        product.setUpdatedBy(MAKER_USER);
        product.setApprovedBy(CHECKER_USER);
        product.setApprovedAt(new Date());
        product.setStatusEnum(APPROVED);
        product.setVersion(100);
        process(product);
        productRepository.insert(product);
        datastore.auditUpdate(CHECKER_USER, product,
                new DynamoProductAudit.ProductDifference("Version", product.getVersion() - 1, product.getVersion()),
                new DynamoProductAudit.ProductDifference("ApprovedAt", null, product.getApprovedAt()),
                new DynamoProductAudit.ProductDifference("ApprovedBy", null, product.getApprovedBy())
        );

        DynamoProduct.Id productId = new DynamoProduct.Id(product.getProductTypeInternal(), product.getId());
        Date since = product.getApprovedAt(); // approval date

        // call method under test
        List<DynamoProductAudit> audits = productAuditRepository.getUserAudits(CHECKER_USER, productId, since);

        // assert
        Assert.assertEquals(1, audits.size());

        DynamoProductAudit audit = audits.get(0);
        Assert.assertEquals(CHECKER_USER, audit.getUsername());
        Assert.assertEquals(true, audit.getTimestamp().after(since));

        assertApprovedAtIsPresent(audits);
    }

    @Test
    public void getUserAudits_of_maker_and_checker_user_when_approved_product_is_modified_by_same_maker_and_checker_user() {
        // create an APPROVED product
        DynamoProduct product = (DynamoProduct) productEntitySamples.getBrandNew();
        product.setVariations(Collections.emptyList()); // not used, just make the payload lighter
        product.setApprovedVariations(Collections.emptyList()); // not used, just make the payload lighter
        product.setCreatedBy(MAKER_USER);
        product.setUpdatedBy(MAKER_USER);
        product.setApprovedBy(CHECKER_USER);
        product.setApprovedAt(new Date());
        product.setStatusEnum(APPROVED);
        product.setVersion(100);
        process(product);
        productRepository.insert(product);
        datastore.auditUpdate(CHECKER_USER, product,
                new DynamoProductAudit.ProductDifference("Version", product.getVersion() - 1, product.getVersion()),
                new DynamoProductAudit.ProductDifference("ApprovedAt", null, product.getApprovedAt()),
                new DynamoProductAudit.ProductDifference("ApprovedBy", null, product.getApprovedBy())
        );

        // EDIT
        int prevVersion = product.getVersion();
        Date prevUpdatedAt = product.getUpdatedAt();
        String prevUpdatedBy = product.getUpdatedBy();

        product.setUpdatedAt(new Date());
        product.setUpdatedBy(MAKER_CHECKER_USER);
        product.setStatusEnum(DRAFT);
        productRepository.save(product);
        datastore.auditUpdate(MAKER_CHECKER_USER, product,
                new DynamoProductAudit.ProductDifference("Version", prevVersion, product.getVersion()),
                new DynamoProductAudit.ProductDifference("UpdatedAt", prevUpdatedAt, product.getUpdatedAt()),
                new DynamoProductAudit.ProductDifference("UpdatedBy", prevUpdatedBy, product.getUpdatedBy())
        );

        DynamoProduct.Id productId = new DynamoProduct.Id(product.getProductTypeInternal(), product.getId());
        Date since = product.getApprovedAt(); // approval date

        // call method under test
        List<DynamoProductAudit> audits = productAuditRepository.getUserAudits(MAKER_CHECKER_USER, productId, since);

        // assert
        Assert.assertEquals(1, audits.size());

        DynamoProductAudit audit = audits.get(0);
        Assert.assertEquals(MAKER_CHECKER_USER, audit.getUsername());
        Assert.assertEquals(true, audit.getTimestamp().after(since));

        assertApprovedAtIsNotPresent(audits); // ApprovedAt is not present because the approve was done by CHECKER_USER user
    }

    private void assertApprovedAtIsPresent(List<DynamoProductAudit> audits) {
        int counter = 0;
        for (DynamoProductAudit audit : audits) {
            for (DynamoProductAudit.ProductDifference difference : audit.getProductDifferences()) {
                if (difference.getPropertyPath().equals("ApprovedAt")) {
                    counter++;
                }
            }
        }
        if (counter == 0) {
            Assert.fail("Expected an Audit item with ApprovedAt present, but none was found");
        }
        // assert ApprovedAt is only present once
        Assert.assertEquals(1, counter);
    }

    private void assertApprovedAtIsNotPresent(List<DynamoProductAudit> audits) {
        int counter = 0;
        for (DynamoProductAudit audit : audits) {
            for (DynamoProductAudit.ProductDifference difference : audit.getProductDifferences()) {
                if (difference.getPropertyPath().equals("ApprovedAt")) {
                    counter++;
                }
            }
        }
        if (counter != 0) {
            Assert.fail("Expected an Audit item with ApprovedAt present, but none was found");
        }
    }
}
