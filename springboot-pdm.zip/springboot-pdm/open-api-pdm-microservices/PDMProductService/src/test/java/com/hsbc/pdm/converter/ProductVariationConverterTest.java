package com.hsbc.pdm.converter;

import com.hsbc.pdm.ProductAssert;
import com.hsbc.pdm.ProductModelSamples;
import com.hsbc.pdm.productservice.model.ProductVariation;
import com.hsbc.pdm.service.AbstractServiceTest;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class ProductVariationConverterTest<ID> extends AbstractServiceTest<ID> {

    @Autowired
    private ProductVariationConverter productVariationConverter;

    @Test
    public void convert_from_entity_to_model() {
        com.hsbc.pdm.entities.ProductVariation entity = productEntitySamples.buildVariation();

        // call method under test
        ProductVariation model = productVariationConverter.convert(entity);

        // assert
        Assert.assertEquals(entity.getId().toString(), model.getId());
        Assert.assertEquals(entity.getVariationName(), model.getVariationName());
        Assert.assertEquals(entity.getStartDate(), model.getStartDate());
        Assert.assertEquals(entity.getExpiryDate(), model.getExpiryDate());
        ProductAssert.assertProductDetailsEquals(entity.getDetails(), model.getDetails());
    }

    @Test
    public void convert_from_model_to_entity() {
        ProductVariation model = ProductModelSamples.buildVariation();

        // call method under test
        com.hsbc.pdm.entities.ProductVariation entity = productVariationConverter.convert(model);

        // assert
        Assert.assertEquals(model.getId(), entity.getId().toString());
        Assert.assertEquals(model.getVariationName(), entity.getVariationName());
        Assert.assertEquals(model.getStartDate(), entity.getStartDate());
        Assert.assertEquals(model.getExpiryDate(), entity.getExpiryDate());
        ProductAssert.assertProductDetailsEquals(model.getDetails(), entity.getDetails());
    }
}
