package com.hsbc.pdm;

import com.hsbc.pdm.entities.ProductTemplate;
import org.junit.Assert;

import java.util.Map;

public class ProductTemplateAssert {

    private ProductTemplateAssert() {}

    public static void assertEquals(ProductTemplate expected, ProductTemplate actual) {
        Assert.assertNotNull(expected);
        Assert.assertNotNull(actual);
        Assert.assertEquals(expected.getId(), actual.getId());
        Assert.assertEquals(expected.getTypeEnum(), actual.getTypeEnum());
        Assert.assertEquals(expected.getTitle(), actual.getTitle());
        Assert.assertEquals(expected.getCreatedAt(), actual.getCreatedAt());
        Assert.assertEquals(expected.getCreatedBy(), actual.getCreatedBy());
        Assert.assertEquals(expected.getStatusEnum(), actual.getStatusEnum());
        Assert.assertEquals(expected.getVersion(), actual.getVersion());
        Assert.assertNotNull(actual.getSchema());
        Assert.assertEquals(expected.getSchema().get("documentVersion"), actual.getSchema().get("documentVersion"));
    }

    public static void assertEquals(ProductTemplate expected, com.hsbc.pdm.productservice.model.ProductTemplate actual) {
        Assert.assertNotNull(expected);
        Assert.assertNotNull(actual);
        Assert.assertEquals(expected.getId().toString(), actual.getId());
        Assert.assertEquals(expected.getTypeEnum().name(), actual.getProductType());
        Assert.assertEquals(expected.getTitle(), actual.getTitle());
        Assert.assertNotNull(actual.getSchema());
        Assert.assertEquals(expected.getSchema().get("documentVersion"), ((Map) actual.getSchema()).get("documentVersion"));
    }
}
