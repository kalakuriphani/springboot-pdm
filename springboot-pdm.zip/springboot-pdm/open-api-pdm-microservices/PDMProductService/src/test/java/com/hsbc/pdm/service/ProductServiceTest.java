package com.hsbc.pdm.service;

import com.hsbc.pdm.common.ProductFactory;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.productservice.model.Product;
import com.hsbc.pdm.repository.ProductRepository;
import org.bson.types.ObjectId;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

/**
 * Created by 44023148 on 21/02/2017.
 */
public class ProductServiceTest<ID> extends AbstractServiceTest<ID> {

    @Autowired
    private ProductService<ID> productService;

    @Autowired
    private ProductFactory<ID> productFactory;

    @Autowired
    private ProductRepository<com.hsbc.pdm.entities.Product<ID>, ID> productRepository;

    @Test
    public void getProduct_should_return_product() {
        com.hsbc.pdm.entities.Product<ID> expected = productEntitySamples.getExisting();
        process(expected);
        productRepository.insert(expected);
        ID productId = productFactory.createId(expected.getId().toString(), expected.getProductTypeInternalEnum());

        // call method under test
        Optional<Product> product = productService.getProduct(productId, expected.getProductTypeVersion(), expected.getStatusEnum());

        // assert
        Assert.assertEquals(true, product.isPresent());
        Assert.assertEquals(expected.getStatusEnum(), product.get().getStatus());
        Assert.assertEquals(expected.getProductTypeVersion(), product.get().getProductTypeVersion());
        Assert.assertEquals(expected.getStatusEnum(), product.get().getStatus());
    }

    @Test
    public void getProduct_when_product_ID_does_not_exist_should_return_nothing() {
        com.hsbc.pdm.entities.Product<ID> expected = productEntitySamples.getExisting();
        process(expected);
        productRepository.insert(expected);
        ID productId = productFactory.createId(ObjectId.get().toString(), ProductTypeEnum.SMEL); // ID does not exist

        // call method under test
        Optional<Product> product = productService.getProduct(productId, expected.getProductTypeVersion(), expected.getStatusEnum());

        // assert
        Assert.assertEquals(false, product.isPresent());
    }

    @Test
    public void getProduct_when_product_type_version_does_not_exist_should_return_nothing() {
        com.hsbc.pdm.entities.Product<ID> expected = productEntitySamples.getExisting();
        process(expected);
        productRepository.insert(expected);
        ID productId = productFactory.createId(expected.getId().toString(), expected.getProductTypeInternalEnum());

        // call method under test
        Optional<Product> product = productService.getProduct(productId, "product-type-version-does-not-exist", expected.getStatusEnum());

        // assert
        Assert.assertEquals(false, product.isPresent());
    }

    @Test
    public void getProducts_should_return_products() {
        com.hsbc.pdm.entities.Product<ID> expected = productEntitySamples.getExisting();
        expected.setProductTypeInternalEnum(ProductTypeEnum.BCA);
        process(expected);
        productRepository.insert(expected);
        expected = productEntitySamples.getExisting();
        expected.setProductTypeInternalEnum(ProductTypeEnum.SMEL);
        process(expected);
        productRepository.insert(expected);

        // call method under test
        List<Product> products = productService.getProducts();

        // assert
        Assert.assertEquals(2, products.size());
    }

    @Test
    public void getProducts_should_return_no_products() {
        // call method under test
        List<Product> products = productService.getProducts();

        // assert
        Assert.assertEquals(0, products.size());
    }

    @Test
    public void getProducts_by_ProductType_should_return_products() {
        com.hsbc.pdm.entities.Product<ID> expected = productEntitySamples.getExisting();
        expected.setProductTypeInternalEnum(ProductTypeEnum.SMEL);
        process(expected);
        productRepository.insert(expected);
        expected = productEntitySamples.getExisting();
        expected.setProductTypeInternalEnum(ProductTypeEnum.CCC);
        process(expected);
        productRepository.insert(expected);

        // call method under test
        List<Product> products = productService.getProducts(ProductTypeEnum.SMEL);

        // assert
        Assert.assertEquals(1, products.size());
    }

    @Test
    public void getProducts_by_ProductStatus_should_return_products() {
        com.hsbc.pdm.entities.Product<ID> expected = productEntitySamples.getExisting();
        expected.setProductTypeInternalEnum(ProductTypeEnum.SMEL);
        expected.setStatusEnum(StatusEnum.DRAFT);
        process(expected);
        productRepository.insert(expected);
        expected = productEntitySamples.getExisting();
        expected.setProductTypeInternalEnum(ProductTypeEnum.CCC);
        expected.setStatusEnum(StatusEnum.APPROVED);
        process(expected);
        productRepository.insert(expected);

        // call method under test
        List<Product> products = productService.getProducts(StatusEnum.DRAFT);

        // assert
        Assert.assertEquals(1, products.size());
    }
}
