package com.hsbc.pdm.repository.dynamo;

import com.hsbc.pdm.ProductAssert;
import com.hsbc.pdm.entities.dynamo.DynamoProduct;
import com.hsbc.pdm.repository.AbstractRepositoryTest;
import org.bson.types.ObjectId;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

@ActiveProfiles(value = { "default", "dynamo" })
public class DynamoProductRepositoryTest extends AbstractRepositoryTest<String> {

    @Autowired
    private DynamoProductRepository productRepository;

    @Test
    public void insert() {
        DynamoProduct product = (DynamoProduct) productEntitySamples.getBrandNew();
        process(product);

        // call method under test
        product = productRepository.insert(product);

        // assert
        DynamoProduct actual = productRepository.findOne(new DynamoProduct.Id(product.getProductTypeInternal(), product.getId()));
        ProductAssert.assertEquals(product, actual);
    }

    @Test
    public void save() {
        DynamoProduct product = (DynamoProduct) productEntitySamples.getBrandNew();
        process(product);
        productRepository.insert(product);

        product.setProductName(product.getProductName() + "-UPDATED");

        // call method under test
        productRepository.save(product);

        // assert
        DynamoProduct actual = productRepository.findOne(new DynamoProduct.Id(product.getProductTypeInternal(), product.getId()));
        ProductAssert.assertEquals(product, actual);
    }

    @Test
    public void findOne() {
        DynamoProduct product = (DynamoProduct) productEntitySamples.getBrandNew();
        process(product);
        productRepository.insert(product);

        // call method under test
        DynamoProduct actual = productRepository.findOne(new DynamoProduct.Id(product.getProductTypeInternal(), product.getId()));

        // assert
        ProductAssert.assertEquals(product, actual);
    }

    @Test
    public void findAll() {
        DynamoProduct product = (DynamoProduct) productEntitySamples.getBrandNew();
        process(product);
        productRepository.insert(product);

        product.setId(ObjectId.get().toHexString()); // must be new range key
        productRepository.insert(product);

        // call method under test
        List<DynamoProduct> products = productRepository.findAll();

        // assert
        Assert.assertEquals(2, products.size());
    }

    @Test
    public void delete() {
        DynamoProduct product = (DynamoProduct) productEntitySamples.getBrandNew();
        process(product);
        productRepository.insert(product);

        product.setId(ObjectId.get().toHexString()); // must be new range key
        productRepository.insert(product);

        Assert.assertEquals(2, productRepository.findAll().size()); // make sure the datastore is not empty before deleting all records

        // call method under test
        productRepository.delete(new DynamoProduct.Id(product.getProductTypeInternal(), product.getId()));

        // assert
        Assert.assertEquals(1, productRepository.findAll().size());
    }

    @Test
    public void deleteAll() {
        DynamoProduct product = (DynamoProduct) productEntitySamples.getBrandNew();
        process(product);
        productRepository.insert(product);

        product.setId(ObjectId.get().toHexString()); // must be new range key
        productRepository.insert(product);
        Assert.assertEquals(2, productRepository.findAll().size()); // make sure the datastore is not empty before deleting all records

        // call method under test
        productRepository.deleteAll();

        // assert
        Assert.assertEquals(0, productRepository.findAll().size());
    }

    @Test
    public void getByProductType() {
        // prepare data in db
        DynamoProduct product = (DynamoProduct) productEntitySamples.getBrandNew();
        process(product);
        productRepository.insert(product);

        // call method under test
        List<DynamoProduct> products = productRepository.getByProductType(product.getProductTypeInternalEnum());

        // assert
        Assert.assertEquals(true, products.size() > 0);
        for (DynamoProduct actual : products) {
            Assert.assertEquals(product.getProductTypeInternalEnum(), actual.getProductTypeInternalEnum());
        }
    }

    @Test
    public void getByStatus() {
        // prepare data in db
        DynamoProduct product = (DynamoProduct) productEntitySamples.getBrandNew();
        process(product);
        productRepository.insert(product);

        // call method under test
        List<DynamoProduct> products = productRepository.getByStatus(product.getStatus());

        // assert
        Assert.assertEquals(true, products.size() > 0);
        for (DynamoProduct actual : products) {
            Assert.assertEquals(product.getStatusEnum(), actual.getStatusEnum());
        }
    }
}
