package com.hsbc.pdm;

import com.hsbc.openbanking.jsonschema.JsonSchemaType;
import com.hsbc.openbanking.jsonschema.wrapper.ProductWrapper;
import com.hsbc.openbanking.jsonschema.wrapper.ProductWrapperFactory;
import com.hsbc.pdm.common.JsonSchemaUtils;
import com.hsbc.pdm.common.StringUtils;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.productservice.model.Product;
import com.hsbc.pdm.productservice.model.ProductVariation;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class ProductModelSamples {

    public static final String PRODUCT_ID = ObjectId.get().toHexString();
    public static final ProductTypeEnum PRODUCT_TYPE_PCA_HSBC = ProductTypeEnum.PCAHSBC;
    public static final String PRODUCT_VERSION_PCA_HSBC = JsonSchemaType.PCA_HSBC_PRODUCT_1_2_4.getVersion();
    public static final String PRODUCT_VERSION_SMEL = JsonSchemaType.SMELENDING_PRODUCT_1_2_4.getVersion();


    private static final ProductWrapperFactory PRODUCT_WRAPPER_FACTORY = new ProductWrapperFactory();

    private ProductModelSamples() {}

    private static String getExternalProductType(ProductTypeEnum productType) {
        switch (productType) {
            case PCAHSBC:
            case PCAFD:
            case PCAMNS:
                return "PCA";
            case SMEL:
                return "SME";
            case CCC:
                return "CCC";
            default:
                throw new RuntimeException("Unexpected product type = " + productType);
        }
    }

    public static Product get(String id, ProductTypeEnum productType, String productVersion) {
        Product product = new Product();
        product.setId(id);
        product.setProductType(productType);
        product.setProductTypeVersion(productVersion);
        product.setProductName("some product name");
        product.setCreatedAt(new Date());
        product.setCreatedBy("test-user");
        product.setUpdatedAt(new Date());
        product.setUpdatedBy("test-user");
        product.setStatus(StatusEnum.DRAFT);
        product.setCountry(StringUtils.PRODUCT_COUNTRY);
        product.setVersion(1);

        product.setVariations(new ArrayList<>());
        product.getVariations().add(buildVariation());

        JsonSchemaType schemaType = JsonSchemaUtils.getJsonSchemaType(product.getProductType(), product.getProductTypeVersion());
        for (ProductVariation variation : product.getVariations()) {
            ProductWrapper wrapper = PRODUCT_WRAPPER_FACTORY.build(schemaType, variation.getDetails());
            wrapper.setProductName(product.getProductName());
            wrapper.setProductType(getExternalProductType(productType));
        }

        return product;
    }

    public static Product get(String id) {
        return get(id, ProductTypeEnum.PCAHSBC, PRODUCT_VERSION_PCA_HSBC);
    }

    public static Product get(com.hsbc.pdm.entities.Product<?> entity) {
        Product model = new Product();
        model.setId(entity.getId().toString());
        model.setProductType(entity.getProductTypeInternalEnum());
        model.setProductTypeVersion(entity.getProductTypeVersion());
        model.setProductName(entity.getVariations().get(0).getVariationName());

        JsonSchemaType schemaType = JsonSchemaUtils.getJsonSchemaType(entity.getProductTypeInternalEnum(), entity.getProductTypeVersion());
        ProductWrapper productWrapper = PRODUCT_WRAPPER_FACTORY.build(schemaType, entity.getVariations().get(0).getDetails());
        model.setProductSegment(productWrapper.getProductSegments());

        model.setVariations(buildVariations((List)entity.getVariations()));
        model.setStatus(entity.getStatusEnum());
        model.setCreatedAt(entity.getCreatedAt());
        model.setCreatedBy(entity.getCreatedBy());
        model.setUpdatedAt(entity.getUpdatedAt());
        model.setUpdatedBy(entity.getUpdatedBy());
        model.setCountry(entity.getCountry());
        model.setVersion(entity.getVersion());

        schemaType = JsonSchemaUtils.getJsonSchemaType(model.getProductType(), model.getProductTypeVersion());
        for (ProductVariation variation : model.getVariations()) {
            ProductWrapper wrapper = PRODUCT_WRAPPER_FACTORY.build(schemaType, variation.getDetails());
            wrapper.setProductName(model.getProductName());
            wrapper.setProductType(getExternalProductType(model.getProductType()));
        }

        return model;
    }


    public static Product getExisting() {
        return get(PRODUCT_ID);
    }

    public static Product getBrandNew(String id, ProductTypeEnum productType, String productVersion) {
        return get(id, productType, productVersion);
    }

    public static Product getBrandNew() {
        return get((String) null);
    }

    public static ProductVariation buildVariation(String productName, ProductTypeEnum productType, String productVersion) {
        ProductVariation variation = new ProductVariation();
        variation.setId(ObjectId.get().toHexString());
        variation.setStartDate(new Date());
        variation.setExpiryDate(new Date());
        variation.setVariationName("some variation name");
        variation.setDetails(ProductDetailsSamples.buildProductDetails(productName, productType, productVersion));
        return variation;
    }

    public static ProductVariation buildVariation() {
        return buildVariation("some product name", PRODUCT_TYPE_PCA_HSBC, PRODUCT_VERSION_PCA_HSBC);
    }

    public static ProductVariation buildVariation(com.hsbc.pdm.entities.ProductVariation entity) {
        ProductVariation variation = new ProductVariation();
        variation.setId(entity.getId().toString());
        variation.setVariationName(entity.getVariationName());
        variation.setStartDate(entity.getStartDate());
        variation.setExpiryDate(entity.getExpiryDate());
        variation.setDetails(entity.getDetails());
        return variation;
    }

    public static List<ProductVariation> buildVariations() {
        List<ProductVariation> variations = new ArrayList<>();
        variations.add(buildVariation());
        return variations;
    }

    public static List<ProductVariation> buildVariations(List<com.hsbc.pdm.entities.ProductVariation> entities) {
        return entities.stream().map(ProductModelSamples::buildVariation).collect(Collectors.toList());
    }

    public static List<ProductVariation> buildVariations(com.hsbc.pdm.entities.ProductVariation... entities) {
        return buildVariations(Arrays.asList(entities));
    }
}
