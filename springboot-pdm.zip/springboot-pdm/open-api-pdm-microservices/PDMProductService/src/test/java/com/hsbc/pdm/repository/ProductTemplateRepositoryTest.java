package com.hsbc.pdm.repository;

import com.hsbc.pdm.common.model.ProductTypeEnum;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by 44023148 on 16/01/2017.
 */
@Ignore
public class ProductTemplateRepositoryTest extends AbstractRepositoryTest {

    @Autowired
    private ProductTemplateRepository productTemplateRepository;

    @Test
    public void getProductTypeACLs() {
        Assert.assertEquals(true, productTemplateRepository.getProductTypeACLs(ProductTypeEnum.BCA).size() > 0);
        Assert.assertEquals(true, productTemplateRepository.getProductTypeACLs(ProductTypeEnum.PCAHSBC).size() > 0);
        Assert.assertEquals(true, productTemplateRepository.getProductTypeACLs(ProductTypeEnum.SMEL).size() > 0);
        Assert.assertEquals(true, productTemplateRepository.getProductTypeACLs(ProductTypeEnum.CCC).size() > 0);
    }
}
