package com.hsbc.pdm;

import com.hsbc.openbanking.jsonschema.JsonSchemaType;
import com.hsbc.pdm.common.ProductFactory;
import com.hsbc.pdm.common.StringUtils;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.entities.Product;
import com.hsbc.pdm.entities.ProductVariation;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class ProductEntitySamples<ID> {

    public static final ProductTypeEnum PRODUCT_TYPE_PCA_HSBC = ProductTypeEnum.PCAHSBC;
    public static final String PRODUCT_VERSION_PCA_HSBC = JsonSchemaType.PCA_HSBC_PRODUCT_1_2_4.getVersion();

    @Autowired
    private ProductFactory<ID> productFactory;


    public Product<ID> get(String productName, ProductTypeEnum productType, String productVersion) {
        Product<ID> product = productFactory.create();
        product.setId(productFactory.createId());
        product.setProductType(productType.getExternalName());
        product.setProductTypeVersion(productVersion);
        product.setProductTypeInternalEnum(productType);
        product.setCreatedAt(new Date());
        product.setCreatedBy("test-user");
        product.setUpdatedAt(new Date());
        product.setUpdatedBy("test-user");
        product.setStatusEnum(StatusEnum.DRAFT);
        product.setCountry(StringUtils.PRODUCT_COUNTRY);
        product.setVersion(1);

        product.setVariations(new ArrayList<>());
        product.getVariations().add(buildVariation(productName, productType, productVersion));
        product.setApprovedVariations(Collections.emptyList());
        product.setProductName(productName);

        return product;
    }

    public Product<ID> getApproved(String productName) {
        return getApproved(productName, PRODUCT_TYPE_PCA_HSBC, PRODUCT_VERSION_PCA_HSBC);
    }

    public Product<ID> getApproved(String productName, ProductTypeEnum productType, String productVersion) {
        Product<ID> product = get(productName, productType, productVersion);
        product.setApprovedVariations(product.getVariations());
        product.setVariations(Collections.emptyList());
        product.setStatusEnum(StatusEnum.APPROVED);
        product.setApprovedAt(new Date());
        product.setApprovedBy("checker-user");
        return product;
    }

    public Product<ID> getExisting() {
        return get("some product name", PRODUCT_TYPE_PCA_HSBC, PRODUCT_VERSION_PCA_HSBC);
    }

    public Product<ID> getBrandNew() {
        return get("some product name", PRODUCT_TYPE_PCA_HSBC, PRODUCT_VERSION_PCA_HSBC);
    }

    public ProductVariation buildVariation(String productName, ProductTypeEnum productType, String productVersion) {
        ProductVariation variation = new ProductVariation();
        variation.setId(ObjectId.get().toHexString());
        variation.setVariationName("some variation name");
        variation.setStartDate(new Date());
        variation.setExpiryDate(new Date());
        variation.setDetails(ProductDetailsSamples.buildProductDetails(productName, productType, productVersion));
        return variation;
    }

    public ProductVariation buildVariation() {
        return buildVariation(ObjectId.get().toHexString(), PRODUCT_TYPE_PCA_HSBC, PRODUCT_VERSION_PCA_HSBC);
    }

    public List<ProductVariation> buildVariations() {
        List<ProductVariation> variations = new ArrayList<>();
        variations.add(buildVariation());
        return variations;
    }
}
