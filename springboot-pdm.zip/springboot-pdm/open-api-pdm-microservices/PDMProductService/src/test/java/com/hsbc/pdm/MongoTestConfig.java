package com.hsbc.pdm;

import com.hsbc.pdm.config.mongo.MongoBeansConfig;
import org.bson.types.ObjectId;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.ActiveProfiles;

/**
 * Created by 44023148 on 03/02/2017.
 */
@Configuration
@Profile("mongo")
@ActiveProfiles("mongo")
public class MongoTestConfig extends MongoBeansConfig {

    @Bean
    public ProductEntitySamples productEntitySamples() {
        return new ProductEntitySamples<ObjectId>();
    }

}
