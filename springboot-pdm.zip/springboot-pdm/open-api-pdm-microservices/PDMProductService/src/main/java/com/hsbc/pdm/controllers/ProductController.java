/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.pdm.controllers;

import com.hsbc.pdm.common.ProductFactory;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.converter.ProductConverter;
import com.hsbc.pdm.productservice.model.Product;
import com.hsbc.pdm.service.AuthenticationService;
import com.hsbc.pdm.service.ProductService;
import com.hsbc.pdm.service.ProductWorkflowService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("product")
@EnableDiscoveryClient
@EnableAutoConfiguration
public class ProductController<ID> {

    private static final Logger LOG = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private ProductService<ID> productService;

    @Autowired
    private ProductConverter<ID> productConverter;

    @Autowired
    private ProductWorkflowService<ID> productWorkflowService;

    @Autowired
    private AuthenticationService authenticationService;

    @Autowired
    private ProductFactory<ID> productFactory;


    @RequestMapping(method = RequestMethod.GET, path = "{product-type}/{product-version}/{product-status}/{product-id}", produces = "application/json")
    public ResponseEntity<Product> getProduct(@PathVariable(name = "product-type") String productType,
                                              @PathVariable(name = "product-version") String productVersion,
                                              @PathVariable(name = "product-status") String productStatus,
                                              @PathVariable(name = "product-id") String productId) {
        ID id = productFactory.createId(productId, ProductTypeEnum.valueOf(productType.toUpperCase()));

        Optional<Product> product = productService.getProduct(id, productVersion, StatusEnum.valueOf(productStatus.toUpperCase()));
        if (!product.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        Authentication authentication = authenticationService.getCurrentAuthentication();
        if (!productWorkflowService.isProductAccessible(product.get().getProductType(), authentication)) {
            throw new AccessDeniedException(String.format("User %s is not authorised to see product %s", authentication.getName(), product.get().getId()));
        }

        Set<String> actions = productWorkflowService.getUserActions(id, StatusEnum.valueOf(productStatus.toUpperCase()), authentication);
        product.get().setWorkflowActions(actions);

        return ResponseEntity.ok().body(product.get());
    }

    @RequestMapping(method = RequestMethod.GET, produces = "application/json")
    public List<Product> getProducts() {
        List<Product> products = productService.getProducts();
        return getAuthorisedProducts(products);
    }

    @RequestMapping(method = RequestMethod.GET, path = "status/{status}", produces = "application/json")
    public List<Product> getProductsByStatus(@PathVariable("status") String status) {
        return productService.getProducts(StatusEnum.valueOf(status.toUpperCase()));
    }

    @RequestMapping(method = RequestMethod.GET, path = "{product-type}/collection", produces = "application/json")
    public List<Product> getProducts(@PathVariable("product-type") String productType) {
        List<Product> products = productService.getProducts(ProductTypeEnum.valueOf(productType.toUpperCase()));
        return getAuthorisedProducts(products);
    }

    private List<Product> getAuthorisedProducts(List<Product> products) {
        // filter products that should not be visible to current user
        Authentication authentication = authenticationService.getCurrentAuthentication();
        return productWorkflowService.getAuthorisedProducts(products, authentication);
    }


    /**
     * Added method not allowed for the http non implemented methods
     *     1.1	Unnecessary HTTP Methods are allowed Concise title describing the most important fact(s) &/or impact of the finding
     *     X-References: 	Comet Issue ID: 56540
     *         The following HTTP Methods are allowed:
     *         OPTIONS, HEAD, GET, PUT, POST, DELETE, PATCH
     */

    @RequestMapping(method = RequestMethod.PUT , produces = "application/json", value={
            "",
            "/",
            "{product-type}/{product-version}/{product-status}/{product-id}",
            "status/{status}",
            "{product-type}/collection"
    })
    public ResponseEntity noPutMethod(){
         return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.POST , produces = "application/json", value={
            "",
            "/",
            "{product-type}/{product-version}/{product-status}/{product-id}",
            "status/{status}",
            "{product-type}/collection"
    })
    public ResponseEntity noPostMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.DELETE , produces = "application/json", value={
            "",
            "/",
            "{product-type}/{product-version}/{product-status}/{product-id}",
            "status/{status}",
            "{product-type}/collection"
    })
    public ResponseEntity noDeleteMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.HEAD , produces = "application/json", value={
            "",
            "/",
            "{product-type}/{product-version}/{product-status}/{product-id}",
            "status/{status}",
            "{product-type}/collection"
    })
    public ResponseEntity noHeadMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.TRACE , produces = "application/json", value={
            "",
            "/",
            "{product-type}/{product-version}/{product-status}/{product-id}",
            "status/{status}",
            "{product-type}/collection"
    })
    public ResponseEntity noTraceMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.PATCH , produces = "application/json", value={
            "",
            "/",
            "{product-type}/{product-version}/{product-status}/{product-id}",
            "status/{status}",
            "{product-type}/collection"
    })
    public ResponseEntity noPatchMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);
    }
}
