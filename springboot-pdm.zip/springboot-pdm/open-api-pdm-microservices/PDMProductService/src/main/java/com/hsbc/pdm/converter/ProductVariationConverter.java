package com.hsbc.pdm.converter;

import com.hsbc.pdm.common.StringUtils;
import com.hsbc.pdm.productservice.model.ProductVariation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.stream.Collectors;

public class ProductVariationConverter {

    private static final Logger LOG = LoggerFactory.getLogger(ProductVariationConverter.class);


    public ProductVariation convert(com.hsbc.pdm.entities.ProductVariation entity) {
        ProductVariation model = new ProductVariation();
        model.setId(entity.getId());
        model.setVariationName(entity.getVariationName());
        model.setStartDate(entity.getStartDate());
        model.setExpiryDate(entity.getExpiryDate());
        model.setDetails(entity.getDetails());
        return model;
    }

    public com.hsbc.pdm.entities.ProductVariation convert(ProductVariation model) {
        com.hsbc.pdm.entities.ProductVariation entity = new com.hsbc.pdm.entities.ProductVariation();
        if (!StringUtils.isBlank(model.getId())) {
            entity.setId(model.getId());
        }
        entity.setVariationName(model.getVariationName());
        entity.setStartDate(model.getStartDate());
        entity.setExpiryDate(model.getExpiryDate());
        entity.setDetails(model.getDetails());
        return entity;
    }

    public List<com.hsbc.pdm.entities.ProductVariation> convertModels(List<ProductVariation> models) {
        return models.stream().map(this::convert).collect(Collectors.toList());
    }

    public List<ProductVariation> convertEntities(List<com.hsbc.pdm.entities.ProductVariation> entities) {
        return entities.stream().map(this::convert).collect(Collectors.toList());
    }
}
