package com.hsbc.pdm.common;

import com.hsbc.openbanking.jsonschema.JsonSchemaType;
import com.hsbc.pdm.common.model.ProductTypeEnum;

import java.util.Arrays;
import java.util.List;

import static com.hsbc.openbanking.jsonschema.JsonSchemaType.*;


/**
 * Created by 44023148 on 29/01/2017.
 */
public class JsonSchemaUtils {

    private JsonSchemaUtils() {}

    public static JsonSchemaType getLatestJsonSchemaType(ProductTypeEnum productType) {
        switch (productType) {
            case PCAHSBC:
                return PCA_HSBC_PRODUCT_1_2_4;
            case BCA:
                return BCA_PRODUCT_1_2_4;
            case SMEL:
                return SMELENDING_PRODUCT_1_2_4;

            case CCC:
                return CCC_PRODUCT_1_2_4;

            case PCAMNS:
                return PCA_MNS_PRODUCT_1_2_4;

            case PCAFD:
                return PCA_FD_PRODUCT_1_2_4;


            default:
                throw new RuntimeException("Unexpected value = " + productType);
        }
    }

    public static List<JsonSchemaType> getJsonSchemaTypes(ProductTypeEnum productType) {
        switch (productType) {
            case PCAHSBC:
                return Arrays.asList(PCA_HSBC_PRODUCT_1_2_4);
            case PCAMNS:
                return Arrays.asList(PCA_MNS_PRODUCT_1_2_4);
            case PCAFD:
                return Arrays.asList(PCA_FD_PRODUCT_1_2_4);
            case BCA:
                return Arrays.asList(BCA_PRODUCT_1_2_4);
            case SMEL:
                return Arrays.asList(SMELENDING_PRODUCT_1_2_4);
            case CCC:
                return Arrays.asList(CCC_PRODUCT_1_2_4);
            default:
                throw new RuntimeException("Unexpected value = " + productType);
        }
    }

    public static JsonSchemaType getJsonSchemaType(ProductTypeEnum productType, String version) {
        List<JsonSchemaType> schemaTypes = getJsonSchemaTypes(productType);
        for (JsonSchemaType schemaType : schemaTypes) {
            if (schemaType.getVersion().equals(version)) {
                return schemaType;
            }
        }
        throw new RuntimeException("JsonSchemaType version " + version + " not found");
    }
}
