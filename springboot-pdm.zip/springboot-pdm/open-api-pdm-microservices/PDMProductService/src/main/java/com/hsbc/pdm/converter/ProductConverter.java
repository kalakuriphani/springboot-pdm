package com.hsbc.pdm.converter;

import com.hsbc.openbanking.jsonschema.JsonSchemaType;
import com.hsbc.openbanking.jsonschema.wrapper.ProductWrapper;
import com.hsbc.openbanking.jsonschema.wrapper.ProductWrapperFactory;
import com.hsbc.pdm.common.JsonSchemaUtils;
import com.hsbc.pdm.common.ProductFactory;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.entities.ProductVariation;
import com.hsbc.pdm.productservice.model.Product;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

public class ProductConverter<ID> {

    private static final Logger LOG = LoggerFactory.getLogger(ProductConverter.class);

    @Autowired
    private ProductVariationConverter productVariationConverter;

    @Autowired
    private ProductWrapperFactory productWrapperFactory;

    @Autowired
    private ProductFactory<ID> productFactory;


    public List<Product> convert(com.hsbc.pdm.entities.Product<ID> entity) {
        Assert.notNull(entity, "Entity cannot be null");

        Product product;
        List<Product> products = new ArrayList<>(2);

        switch (entity.getStatusEnum()) {
            case DRAFT:
            case SUBMITTED_FOR_APPROVAL:
                product = convert(entity, entity.getVariations());
                product.setStatus(entity.getStatusEnum());
                products.add(product);
                if (CollectionUtils.isNotEmpty(entity.getApprovedVariations())) {
                    product = convert(entity, entity.getApprovedVariations());
                    product.setStatus(StatusEnum.APPROVED);
                    products.add(product);
                }
                break;
            case APPROVED:
                // TODO : temporarily commented until data in UAT is re-saved
//                if (CollectionUtils.isNotEmpty(entity.getVariations())) {
//                    ID id = productFactory.createId(entity.getId().toString(), entity.getProductTypeInternalEnum());
//                    throw new IllegalStateException("Product cannot have working variations ( id = " + id + ")");
//                }
                product = convert(entity, entity.getApprovedVariations());
                product.setStatus(entity.getStatusEnum());
                products.add(product);
                break;
            case SUBMITTED_FOR_DELETION:
                // TODO : temporarily commented until data in UAT is re-saved
//                if (CollectionUtils.isNotEmpty(entity.getVariations())) {
//                    ID id = productFactory.createId(entity.getId().toString(), entity.getProductTypeInternalEnum());
//                    throw new IllegalStateException("Product cannot have working variations ( id = " + id + ")");
//                }
                product = convert(entity, entity.getApprovedVariations());
                product.setStatus(entity.getStatusEnum());
                products.add(product);
                product = convert(entity, entity.getApprovedVariations());
                product.setStatus(StatusEnum.APPROVED);
                products.add(product);
                break;
            case DELETED:
                // TODO : temporarily commented until data in UAT is re-saved
//                if (CollectionUtils.isNotEmpty(entity.getVariations())) {
//                    ID id = productFactory.createId(entity.getId().toString(), entity.getProductTypeInternalEnum());
//                    throw new IllegalStateException("Product cannot have working variations ( id = " + id + ")");
//                }
                product = convert(entity, entity.getApprovedVariations());
                product.setStatus(entity.getStatusEnum());
                products.add(product);
                break;
            default:
                throw new IllegalStateException("Unexpected product status = " + entity.getStatusEnum());
        }

        return products;
    }

    public Product convert(com.hsbc.pdm.entities.Product<ID> entity, List<ProductVariation> variations) {
        Assert.notNull(entity, "Entity cannot be null");

        Product product = new Product();
        product.setId(entity.getId().toString());
        product.setProductType(entity.getProductTypeInternalEnum());
        product.setProductTypeVersion(entity.getProductTypeVersion());

        /**
         * A product must always have at least 1 variation.
         */
        Assert.notEmpty(variations, "Product variations cannot be empty");

        JsonSchemaType schemaType = JsonSchemaUtils.getJsonSchemaType(entity.getProductTypeInternalEnum(), entity.getProductTypeVersion());
        ProductWrapper productWrapper = productWrapperFactory.build(schemaType, variations.get(0).getDetails());
        product.setProductName(productWrapper.getProductName());
        product.setProductSegment(productWrapper.getProductSegments());

        product.setVariations(productVariationConverter.convertEntities(variations));

        product.setStatus(entity.getStatusEnum());
        product.setCreatedAt(entity.getCreatedAt());
        product.setUpdatedAt(entity.getUpdatedAt());
        product.setApprovedAt(entity.getApprovedAt());
        product.setCreatedBy(entity.getCreatedBy());
        product.setUpdatedBy(entity.getUpdatedBy());
        product.setApprovedBy(entity.getApprovedBy());
        product.setCountry(entity.getCountry());
        product.setVersion(entity.getVersion());

        return product;
    }
}
