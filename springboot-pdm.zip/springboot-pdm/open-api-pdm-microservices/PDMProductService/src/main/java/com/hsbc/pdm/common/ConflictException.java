package com.hsbc.pdm.common;

public class ConflictException extends PDMException {

    public ConflictException(String message) {
        super(message);
    }
}
