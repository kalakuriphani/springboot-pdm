package com.hsbc.pdm.common.dynamo;

import com.hsbc.pdm.common.ProductFactory;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.entities.Product;
import com.hsbc.pdm.entities.dynamo.DynamoProduct;
import org.bson.types.ObjectId;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

/**
 * Created by 44023148 on 03/02/2017.
 */
@Component
@Profile(value = { "dynamo", "!mongo" })
public class DynamoProductFactory implements ProductFactory<String> {

    @Override
    public Product<String> create() {
        return new DynamoProduct();
    }

    @Override
    public DynamoProduct.Id createId(String id, ProductTypeEnum productType) {
        return new DynamoProduct.Id(productType.name(), id);
    }

    @Override
    public String createId(String id) {
        return id;
    }

    @Override
    public String createId() {
        return ObjectId.get().toHexString();
    }

    @Override
    public String getLocation(ProductTypeEnum productType, String productVersion, StatusEnum productStatus, String id) {
        return String.format("/%s/%s/%s/%s", productType.name(), productVersion, productStatus.name(), id);
    }
}
