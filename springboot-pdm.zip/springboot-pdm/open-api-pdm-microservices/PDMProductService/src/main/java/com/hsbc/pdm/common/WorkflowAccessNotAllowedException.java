package com.hsbc.pdm.common;

import com.hsbc.pdm.auth.PDMAuthenticationToken;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import org.springframework.security.core.Authentication;

import java.util.Arrays;

/**
 * Created by 44023148 on 27/01/2017.
 */
public class WorkflowAccessNotAllowedException extends RuntimeException {

    public WorkflowAccessNotAllowedException(ProductTypeEnum productType, Authentication authentication) {
        super(String.format("Workflow access not allowed ( product-type = %s , username = %s , roles = %s )",
                productType,
                authentication.getName(),
                Arrays.toString(((PDMAuthenticationToken) authentication).getRoles())));
    }
}
