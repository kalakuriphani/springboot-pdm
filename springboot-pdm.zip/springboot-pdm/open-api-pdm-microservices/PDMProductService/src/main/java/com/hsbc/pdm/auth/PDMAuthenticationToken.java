package com.hsbc.pdm.auth;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.List;

/**
 * Created by 44023148 on 23/01/2017.
 */
public class PDMAuthenticationToken extends AbstractAuthenticationToken {

    private Object principal;
    private Object credentials;
    private final String pdmToken;
    private final String authToken;

    public PDMAuthenticationToken(String pdmToken, String authToken) {
        super(null);
        this.pdmToken = pdmToken;
        this.authToken = authToken;
    }

    public PDMAuthenticationToken(String pdmToken, String authToken, Object principal, Object credentials, List<GrantedAuthority> authorities) {
        super(authorities);
        this.pdmToken = pdmToken;
        this.authToken = authToken;
        this.principal = principal;
        this.credentials = credentials;
    }

    @Override
    public Object getCredentials() {
        return credentials;
    }

    @Override
    public Object getPrincipal() {
        return principal;
    }

    public String getPdmToken() {
        return pdmToken;
    }

    public String getAuthToken() {
        return authToken;
    }

    public String[] getRoles() {
        String[] array = new String[getAuthorities().size()];
        int index = 0;
        for (GrantedAuthority authority : getAuthorities()) {
            array[index] = authority.getAuthority();
            index++;
        }
        return array;
    }
}
