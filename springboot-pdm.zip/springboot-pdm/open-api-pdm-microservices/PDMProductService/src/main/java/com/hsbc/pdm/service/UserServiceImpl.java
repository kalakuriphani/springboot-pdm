package com.hsbc.pdm.service;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.util.Assert;

import java.util.Collections;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.hsbc.pdm.common.UserRoles.*;

/**
 * Created by 44023148 on 26/01/2017.
 */
public class UserServiceImpl implements UserService {

    /**
     * Check if the role has been assigned to user.
     * @param role the role to be checked (case insensitive).
     * @return true if the user belongs has the role, otherwise false.
     */
    @Override
    public boolean isInRole(Authentication authentication, String role) {
        Assert.notNull(authentication, "Authentication cannot be null");
        Assert.notNull(role, "Role cannot be null");
        Assert.hasText(role, "Role cannot be empty");
        return getRoles(authentication).contains(role.toUpperCase());
    }

    /**
     * Get user roles (always in UPPER case).
     * @return available roles or empty set.
     */
    @Override
    public Set<String> getRoles(Authentication authentication) {
        Assert.notNull(authentication, "Authentication cannot be null");
        if (authentication.getAuthorities() == null || authentication.getAuthorities().isEmpty()) {
            return Collections.emptySet();
        }
        return authentication.getAuthorities().stream()
                .map((Function<GrantedAuthority, String>) grantedAuthority -> grantedAuthority.getAuthority().toUpperCase())
                .collect(Collectors.toSet());
    }

    @Override
    public boolean isMaker(Authentication authentication) {
        Assert.notNull(authentication, "Authentication cannot be null");
        Set<String> roles = getRoles(authentication);
        return RoleType.MAKER_ROLES.containsAnyOf(roles);
    }

    @Override
    public boolean isChecker(Authentication authentication) {
        Assert.notNull(authentication, "Authentication cannot be null");
        Set<String> roles = getRoles(authentication);
        return RoleType.CHECKER_ROLES.containsAnyOf(roles);
    }
}
