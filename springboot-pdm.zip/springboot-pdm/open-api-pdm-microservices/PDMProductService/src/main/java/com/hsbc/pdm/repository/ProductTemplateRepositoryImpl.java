/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.pdm.repository;

import com.hsbc.pdm.common.model.ProductTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static com.hsbc.pdm.common.UserRoles.*;

@Component
public class ProductTemplateRepositoryImpl implements ProductTemplateRepository {

    private static final Logger LOG = LoggerFactory.getLogger(ProductTemplateRepositoryImpl.class);

    private static final Map<ProductTypeEnum, Set<String>> ROLES_DATASTORE = new HashMap<>();

//    @Autowired
//    private MongoTemplate mongoTemplate;

    // @Autowired
    // @Qualifier("ProductTem")
    // MongoCollection<Document> collection;

    static {
        addProductTypeRoleMapping(ProductTypeEnum.PCAHSBC, ROLE_INFODIR_OBA_PDM_RWMB_MAKER);
        addProductTypeRoleMapping(ProductTypeEnum.PCAHSBC, ROLE_INFODIR_OBA_PDM_RWMB_CHECKER);
        addProductTypeRoleMapping(ProductTypeEnum.PCAFD, ROLE_INFODIR_OBA_PDM_FD_MAKER);
        addProductTypeRoleMapping(ProductTypeEnum.PCAFD, ROLE_INFODIR_OBA_PDM_FD_CHECKER);

        addProductTypeRoleMapping(ProductTypeEnum.PCAMNS, ROLE_INFODIR_OBA_PDM_MANDS_MAKER);
        addProductTypeRoleMapping(ProductTypeEnum.PCAMNS, ROLE_INFODIR_OBA_PDM_MANDS_CHECKER);

        addProductTypeRoleMapping(ProductTypeEnum.BCA, ROLE_INFODIR_OBA_PDM_CMB_MAKER);
        addProductTypeRoleMapping(ProductTypeEnum.BCA, ROLE_INFODIR_OBA_PDM_CMB_CHECKER);

        addProductTypeRoleMapping(ProductTypeEnum.SMEL, ROLE_INFODIR_OBA_PDM_SME_MAKER);
        addProductTypeRoleMapping(ProductTypeEnum.SMEL, ROLE_INFODIR_OBA_PDM_SME_CHECKER);

        addProductTypeRoleMapping(ProductTypeEnum.CCC, ROLE_INFODIR_OBA_PDM_CMB_CCC_MAKER);
        addProductTypeRoleMapping(ProductTypeEnum.CCC, ROLE_INFODIR_OBA_PDM_CMB_CCC_CHECKER);
    }

    private static void addProductTypeRoleMapping(ProductTypeEnum productType, String role) {
        Set<String> roles = ROLES_DATASTORE.get(productType);
        if (roles == null) {
            roles = new HashSet<>();
            ROLES_DATASTORE.put(productType, roles);
        }
        roles.add(role);
    }

    @Override
    public Set<String> getProductTypeACLs(ProductTypeEnum productType) {
        return new HashSet<>(ROLES_DATASTORE.get(productType));
    }
}
