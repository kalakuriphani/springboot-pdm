package com.hsbc.pdm.config.mongo;

import com.hsbc.pdm.common.ProductFactory;
import com.hsbc.pdm.common.mongo.MongoProductFactory;
import com.hsbc.pdm.config.AbstractBeansConfig;
import com.hsbc.pdm.converter.ProductConverter;
import com.hsbc.pdm.repository.ProductRepository;
import com.hsbc.pdm.repository.mongo.MongoProductRepository;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile(value = { "mongo" })
public class MongoBeansConfig extends AbstractBeansConfig {

    private static final Logger LOG = LoggerFactory.getLogger(MongoBeansConfig.class);

    public MongoBeansConfig() {
        LOG.info("guragats: Initialize MongoBeansConfig for MongoDB");
    }

    @Bean
    public ProductConverter productConverter() {
        return new ProductConverter<ObjectId>();
    }

    @Bean
    public ProductRepository productRepository() {
        return new MongoProductRepository();
    }

    @Bean
    public ProductFactory productFactory() {
        return new MongoProductFactory();
    }
}
