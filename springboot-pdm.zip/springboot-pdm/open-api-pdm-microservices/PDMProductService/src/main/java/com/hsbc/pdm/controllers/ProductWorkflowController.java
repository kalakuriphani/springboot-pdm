/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.pdm.controllers;

import com.hsbc.pdm.common.ProductFactory;
import com.hsbc.pdm.common.UserRoles;
import com.hsbc.pdm.common.WorkflowActions;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.converter.ProductConverter;
import com.hsbc.pdm.productservice.model.Product;
import com.hsbc.pdm.repository.ProductRepository;
import com.hsbc.pdm.service.AuthenticationService;
import com.hsbc.pdm.service.ProductWorkflowService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("workflow")
@EnableDiscoveryClient
@EnableAutoConfiguration
public class ProductWorkflowController<ID> {

    private static final Logger LOG = LoggerFactory.getLogger(ProductWorkflowController.class);


    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductWorkflowService<ID> productWorkflowService;

    @Autowired
    private ProductConverter productConverter;

    @Autowired
    private AuthenticationService authenticationService;

    @Autowired
    private ProductFactory<ID> productFactory;


    @RequestMapping(method = RequestMethod.POST, path = "product", consumes = "application/json")
    public void createProduct(@RequestHeader("x-pdm-workflow-action") String action, @RequestBody Product product, HttpServletResponse response) {
        Authentication authentication = authenticationService.getCurrentAuthentication();
        ID productId;
        switch (action.toUpperCase()) {
            case WorkflowActions.ACTION_EDIT:
                productId = productWorkflowService.create(product, authentication);
                break;
            case WorkflowActions.ACTION_COPY:
                productId = productWorkflowService.copy(product, authentication);
                break;
            default:
                throw new RuntimeException("Unexpected workflow action = " + action);
        }
        response.addHeader("Location", "/product" + productFactory.getLocation(product.getProductType(), product.getProductTypeVersion(), StatusEnum.DRAFT, productId));
        response.setStatus(HttpStatus.CREATED.value());
    }

    @RequestMapping(method = RequestMethod.PUT, path = "product/{product-type}/{product-id}", consumes = "application/json")
    public void updateProduct(@PathVariable(name = "product-type") ProductTypeEnum productType, @PathVariable(name = "product-id") String sProductId, @RequestHeader("x-pdm-workflow-action") String action, @RequestBody(required = false) Product product) {
        Authentication authentication = authenticationService.getCurrentAuthentication();
        ID id = productFactory.createId(sProductId, productType);
        switch (action.toUpperCase()) {
            case WorkflowActions.ACTION_EDIT:
                productWorkflowService.update(id, product.getVariations(), authentication);
                break;
            case WorkflowActions.ACTION_REQUEST_APPROVE:
                productWorkflowService.requestApprove(id, authentication);
                break;
            case WorkflowActions.ACTION_REQUEST_DELETE:
                productWorkflowService.requestDelete(id, authentication);
                break;
            case WorkflowActions.ACTION_APPROVE_CHANGE_REQUEST:
                productWorkflowService.approveChange(id, authentication);
                break;
            case WorkflowActions.ACTION_APPROVE_DELETE_REQUEST:
                productWorkflowService.approveDelete(id, authentication);
                break;
            case WorkflowActions.ACTION_REJECT_CHANGE_REQUEST:
                productWorkflowService.rejectChange(id, authentication);
                break;
            case WorkflowActions.ACTION_REJECT_DELETE_REQUEST:
                productWorkflowService.rejectDelete(id, authentication);
                break;
//            case WorkflowActions.ACTION_PUBLISH: // TODO : uncomment when implemented
//                productWorkflowService.publish(productId, authentication);
//                break;
//            case WorkflowActions.ACTION_SUSPEND: // TODO : uncomment when implemented
//                productWorkflowService.suspend(productId, authentication);
//                break;
            default:
                throw new RuntimeException("Unexpected workflow action = " + action);
        }
    }

    @RequestMapping(method = RequestMethod.DELETE, path = "product/{product-type}/{product-id}", produces = "application/json")
    public void deleteProduct(@PathVariable(name = "product-type") ProductTypeEnum productType,
                              @PathVariable(name = "product-id") String sProductId,
                              @RequestParam(name = "version") int version) {
        Authentication authentication = authenticationService.getCurrentAuthentication();
        ID id = productFactory.createId(sProductId, productType);
        productWorkflowService.hardDelete(id, authentication);
    }

    @RequestMapping(method = RequestMethod.GET, path = "product/{product-type}/{product-status}/{product-id}/action", produces = "application/json")
    public Set<String> getProductActions(@PathVariable(name = "product-type") String productType,
                                         @PathVariable(name = "product-status") String productStatus,
                                         @PathVariable(name = "product-id") String sProductId) {
        Authentication authentication = authenticationService.getCurrentAuthentication();
        if (sProductId.equalsIgnoreCase("new")) {
            Set<String> actions = productWorkflowService.getUserActions(StatusEnum.DRAFT, authentication);
            /**
             * New DRAFT products cannot be:
             * - submitted for approval
             * - copied
             * - hard deleted
             */
            actions.remove(WorkflowActions.ACTION_REQUEST_APPROVE); //
            actions.remove(WorkflowActions.ACTION_COPY); // a product that has not been saved yet cannot be submitted for approval
            actions.remove(WorkflowActions.ACTION_HARD_DELETE); // a product that has not been saved yet cannot be deleted
            return actions;
        }
        ID id = productFactory.createId(sProductId, ProductTypeEnum.valueOf(productType.toUpperCase()));
        return productWorkflowService.getUserActions(id, StatusEnum.valueOf(productStatus.toUpperCase()), authentication);
    }

    @RequestMapping(method = RequestMethod.GET, path = "acl/product-type", produces = "application/json")
    public Map<String, Set<ProductTypeEnum>> getProductTypeACL() {
        Authentication authentication = authenticationService.getCurrentAuthentication();
        Map<UserRoles.RoleType, Set<ProductTypeEnum>> acl = productWorkflowService.getProductTypeACL(authentication);
        Map<String, Set<ProductTypeEnum>> result = new HashMap<>();
        result.put("makerOf", acl.get(UserRoles.RoleType.MAKER_ROLES));
        result.put("checkerOf", acl.get(UserRoles.RoleType.CHECKER_ROLES));
        return result;
    }

    /**
     * Added method not allowed for the http non implemented methods
     *     1.1	Unnecessary HTTP Methods are allowed Concise title describing the most important fact(s) &/or impact of the finding
     *     X-References: 	Comet Issue ID: 56540
     *         The following HTTP Methods are allowed:
     *         OPTIONS, HEAD, GET, PUT, POST, DELETE, PATCH
     */

    @RequestMapping(method = RequestMethod.GET , produces = "application/json", value={
            "",
            "/",
            "product",
            "product/{product-type}/{product-id}"
    })
    public ResponseEntity noGetMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.PUT , produces = "application/json", value={
            "",
            "/",
            "product",
            "product/{product-type}/{product-status}/{product-id}/action",
            "acl/product-type"
    })
    public ResponseEntity noPutMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.POST , produces = "application/json", value={
            "",
            "/",
            "product/{product-type}/{product-id}",
            "product/{product-type}/{product-status}/{product-id}/action",
            "acl/product-type"
    })
    public ResponseEntity noPostMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.DELETE , produces = "application/json", value={
            "",
            "/",
            "product",
            "product/{product-type}/{product-status}/{product-id}/action",
            "acl/product-type"
    })
    public ResponseEntity noDeleteMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.HEAD , produces = "application/json", value={
            "",
            "/",
            "product",
            "product/{product-type}/{product-id}",
            "product/{product-type}/{product-status}/{product-id}/action",
            "acl/product-type"
    })
    public ResponseEntity noHeadMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.TRACE , produces = "application/json", value={
            "",
            "/",
            "product",
            "product/{product-type}/{product-id}",
            "product/{product-type}/{product-status}/{product-id}/action",
            "acl/product-type"
    })
    public ResponseEntity noTraceMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.PATCH , produces = "application/json", value={
            "",
            "/",
            "product",
            "product/{product-type}/{product-id}",
            "product/{product-type}/{product-status}/{product-id}/action",
            "acl/product-type"
    })
    public ResponseEntity noPatchMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);
    }
}
