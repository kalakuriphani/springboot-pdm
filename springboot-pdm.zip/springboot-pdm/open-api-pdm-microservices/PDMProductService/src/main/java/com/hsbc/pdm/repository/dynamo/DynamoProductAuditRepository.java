package com.hsbc.pdm.repository.dynamo;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedScanList;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.hsbc.pdm.common.UTCDateUtils;
import com.hsbc.pdm.entities.dynamo.DynamoProduct;
import com.hsbc.pdm.entities.dynamo.DynamoProductAudit;
import com.hsbc.pdm.repository.ProductAuditRepository;
import org.springframework.util.Assert;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.hsbc.pdm.entities.dynamo.DynamoProductAudit.*;
import static com.hsbc.pdm.entities.dynamo.marshaller.DateToAttributeConverter.DATETIME_FORMATTER;

/**
 * Created by 44023148 on 28/02/2017.
 */
public class DynamoProductAuditRepository extends AbstractDynamoRepository implements ProductAuditRepository {

    @Override
    public void save(DynamoProductAudit o) {
        super.saveObject(o);
    }

    @Override
    public void deleteAll() {
        Map<String, String> attributeNames = new HashMap<>();
        attributeNames.put(getAttributeName(USERNAME_FIELD), USERNAME_FIELD);
        attributeNames.put(getAttributeName(TIMESTAMP_FIELD), TIMESTAMP_FIELD);

        DynamoDBMapper mapper = getDynamoDBMapper();
        String projection = String.format("%s, %s", getAttributeName(USERNAME_FIELD), getAttributeName(TIMESTAMP_FIELD));
        PaginatedScanList<DynamoProductAudit> pages = mapper.scan(DynamoProductAudit.class, new DynamoDBScanExpression()
                .withExpressionAttributeNames(attributeNames)
                .withProjectionExpression(projection));
        pages.forEach(mapper::delete);
    }

    /**
     * Search product changes dine by a user starting with specific date in the past.
     * Any change done by the user before 'since timestamp' is not returned.
     */
    @Override
    public List<DynamoProductAudit> getUserAudits(String username, DynamoProduct.Id productId, Date sinceTimestamp) {
        Assert.hasText(username, "User name cannot be blank");
        Assert.notNull(productId, "Product id cannot be blank");
        Assert.hasText(productId.getHashKey(), "Hash key cannot be blank");
        Assert.hasText(productId.getRangeKey(), "Range key cannot be blank");
        Assert.notNull(sinceTimestamp, "Since timestamp cannot be null");

        String conditionExpression = getAttributeName(USERNAME_FIELD) + " = :USER_NAME and " + getAttributeName(TIMESTAMP_FIELD) + " >= :SINCE_TIMESTAMP";
        String filterExpression = getAttributeName(KEYS_FIELD, PRODUCT_TYPE_INTERNAL_FIELD) + " = :PRODUCT_TYPE_INTERNAL"
                + " and " + getAttributeName(KEYS_FIELD, PRODUCT_ID_FIELD) + " = :PRODUCT_ID";

        Map<String, String> attributesNames= new HashMap<>();
        attributesNames.put(getAttributeName(KEYS_FIELD), KEYS_FIELD);
        attributesNames.put(getAttributeName(PRODUCT_TYPE_INTERNAL_FIELD), PRODUCT_TYPE_INTERNAL_FIELD);
        attributesNames.put(getAttributeName(USERNAME_FIELD), USERNAME_FIELD);
        attributesNames.put(getAttributeName(TIMESTAMP_FIELD), TIMESTAMP_FIELD);

        Map<String, AttributeValue> expressionValues = new HashMap<>();
        expressionValues.put(":PRODUCT_TYPE_INTERNAL", new AttributeValue().withS(productId.getHashKey()));
        expressionValues.put(":PRODUCT_ID", new AttributeValue().withS(productId.getRangeKey()));
        expressionValues.put(":USER_NAME", new AttributeValue().withS(username));
        expressionValues.put(":SINCE_TIMESTAMP", new AttributeValue().withS(UTCDateUtils.format(sinceTimestamp, DATETIME_FORMATTER)));

        DynamoDBQueryExpression<DynamoProductAudit> expression = new DynamoDBQueryExpression<DynamoProductAudit>()
                .withKeyConditionExpression(conditionExpression)
                .withFilterExpression(filterExpression)
                .withExpressionAttributeNames(attributesNames)
                .withExpressionAttributeValues(expressionValues);

        DynamoDBMapper mapper = getDynamoDBMapper();
        return mapper.query(DynamoProductAudit.class, expression);
    }

    protected String getAttributeName(String... properties) {
        Assert.notEmpty(properties, "Properties cannot be empty");
        /**
         * Avoid unnecessary creation of StringBuilder if there is only one property
         */
        if (properties.length == 1) {
            return "#" + properties[0];
        }
        StringBuilder sb = new StringBuilder();
        for (String property : properties) {
            if (sb.length() > 0) {
                sb.append(".");
            }
            sb.append("#" + property);
        }
        return sb.toString();
    }
}
