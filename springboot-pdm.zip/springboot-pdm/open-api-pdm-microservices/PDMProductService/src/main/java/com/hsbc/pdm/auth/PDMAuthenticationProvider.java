package com.hsbc.pdm.auth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

/**
 * Created by 44023148 on 23/01/2017.
 */
@Component
public class PDMAuthenticationProvider implements AuthenticationProvider {

    private static final Logger LOG = LoggerFactory.getLogger(PDMAuthenticationProvider.class);

    private static final Object NO_CREDENTIAL = null;

    @Autowired
    private AuthorityProvider authorityProvider;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        // TODO : unit test
        /**
         * Normally authentication.isAuthenticated() must always return false here, as the authenticate(..) method
         * must be called only for authenticated users. Nevertheless, if it happens we just return same instance.
         */
        if (authentication.isAuthenticated()) {
            LOG.debug("User already authenticated as {}", authentication.getName(), authentication.getPrincipal());
            return authentication;
        }

        PDMAuthenticationToken token = (PDMAuthenticationToken) authentication;
        LOG.info("Authenticate user {} against Authority Provider", authentication.getName());
        PDMUser user = authorityProvider.getPDMUser(token.getPdmToken());
        LOG.info("User authenticated by Authority Provider : {}", user.toString());
        PDMAuthenticationToken successToken = new PDMAuthenticationToken(token.getPdmToken(), token.getAuthToken(), user, NO_CREDENTIAL, new ArrayList<>(user.getAuthorities()));
        successToken.setDetails(user);
        successToken.setAuthenticated(true);

        return successToken;
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return PDMAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
