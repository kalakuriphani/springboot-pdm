package com.hsbc.pdm.service;

import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.converter.ProductConverter;
import com.hsbc.pdm.productservice.model.Product;
import com.hsbc.pdm.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Created by 44023148 on 20/02/2017.
 */
public class ProductServiceImpl<ID> implements ProductService<ID> {

    @Autowired
    private ProductRepository<com.hsbc.pdm.entities.Product<ID>, ID> productRepository;

    @Autowired
    private ProductConverter<ID> productConverter;

    @Override
    public Optional<Product> getProduct(ID productId, String productVersion, StatusEnum expectedProductStatus) {
        Assert.notNull(productId, "Product id cannot be null");
        com.hsbc.pdm.entities.Product<ID> entity = productRepository.findOne(productId);
        if (entity == null) {
            return Optional.empty();
        }

        /**
         * Product's type version is different that the one looked up, so return nothing.
         */
        Assert.notNull(productVersion, "Product version cannot be null");
        if (!entity.getProductTypeVersion().equals(productVersion)) {
            return Optional.empty();
        }

        /**
         * Verify if expected status is compatible with the current hard or soft status.
         */
        Product product;
        switch (entity.getStatusEnum()) {
            case DRAFT:
                if (expectedProductStatus == StatusEnum.DRAFT) {
                    product = productConverter.convert(entity, entity.getVariations());
                } else if (expectedProductStatus == StatusEnum.APPROVED) {
                    product = productConverter.convert(entity, entity.getApprovedVariations());
                } else {
                    throw new IllegalStateException("Invalid expected product status " + expectedProductStatus);
                }
                product.setStatus(expectedProductStatus);
                break;
            case SUBMITTED_FOR_APPROVAL:
                if (expectedProductStatus == StatusEnum.SUBMITTED_FOR_APPROVAL) {
                    product = productConverter.convert(entity, entity.getVariations());
                } else if (expectedProductStatus == StatusEnum.APPROVED) {
                    product = productConverter.convert(entity, entity.getApprovedVariations());
                } else {
                    throw new IllegalStateException("Invalid expected product status " + expectedProductStatus);
                }
                product.setStatus(expectedProductStatus);
                break;
            case APPROVED:
                if (expectedProductStatus != StatusEnum.APPROVED) {
                    throw new IllegalStateException("Invalid expected product status " + expectedProductStatus);
                }
                product = productConverter.convert(entity, entity.getApprovedVariations());
                product.setStatus(entity.getStatusEnum());
                break;
            case SUBMITTED_FOR_DELETION:
                if (expectedProductStatus != StatusEnum.SUBMITTED_FOR_DELETION
                        && expectedProductStatus != StatusEnum.APPROVED) {
                    throw new IllegalStateException("Invalid expected product status " + expectedProductStatus);
                }
                product = productConverter.convert(entity, entity.getApprovedVariations());
                product.setStatus(expectedProductStatus);
                break;
            case DELETED:
                if (expectedProductStatus != StatusEnum.DELETED) {
                    throw new IllegalStateException("Invalid expected product status " + expectedProductStatus);
                }
                product = productConverter.convert(entity, entity.getApprovedVariations());
                product.setStatus(StatusEnum.DELETED);
                break;
            default:
                throw new RuntimeException("Invalid expected product status " + expectedProductStatus);
        }
        return Optional.ofNullable(product);
    }

    @Override
    public List<Product> getProducts() {
        List<Product> products = new ArrayList<>();
        productRepository.findAll()
                .forEach(product -> products.addAll(productConverter.convert(product)));
        return products;
    }

    @Override
    public List<Product> getProducts(ProductTypeEnum productType) {
        Assert.notNull(productType, "Product type cannot be null");
        List<Product> products = new ArrayList<>();
        productRepository.getByProductType(productType)
                .forEach(product -> products.addAll(productConverter.convert(product)));
        return products;
    }

    @Override
    public List<Product> getProducts(StatusEnum productStatus) {
        Assert.notNull(productStatus, "Product status cannot be null");
        List<Product> products = new ArrayList<>();
        productRepository.getByStatus(productStatus.name())
                .forEach(product -> products.addAll(productConverter.convert(product)));
        return products;
    }
}
