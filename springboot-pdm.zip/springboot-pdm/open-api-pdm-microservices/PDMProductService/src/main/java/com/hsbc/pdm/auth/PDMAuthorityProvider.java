package com.hsbc.pdm.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by 44023148 on 24/01/2017.
 */
public class PDMAuthorityProvider implements AuthorityProvider {

    @Autowired
    private RestTemplate template;

    @Value("${authorityProvider.baseUrl}")
    private String baseUrl;

    @Override
    public PDMUser getPDMUser(String sessionId) {
        // TODO : unit test
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(baseUrl + "/authority/session/{session-id}");
        UriComponents uriComponents = uriBuilder.build();
        uriComponents = uriComponents.expand(sessionId);
        URI uri = uriComponents.toUri();
        RequestEntity<Void> request = RequestEntity.get(uri)
                .accept(MediaType.APPLICATION_JSON)
                .header("Cookie", "SESSION=" + sessionId)
                .build();
        ResponseEntity<Map> response = template.exchange(request, Map.class);

        switch (response.getStatusCode()) {
            case NOT_FOUND:
                throw new InvalidPDMTokenException(String.format("Session %s not found in PDM Authority Provider", sessionId));
            case OK:
                // we are good here so just carry on
                break;
            default:
                throw new RuntimeException(String.format("PDM Authority Provider returned %s %s for session %s", response.getStatusCode().value(), response.getStatusCode(), sessionId));

        }

        Map<String, Object> session = response.getBody();
        // PDM token must always be same as returned session-id
        if (!sessionId.equals(getSessionId(session))) {
            throw new RuntimeException(String.format("PDM session %s is different than PDM session %s", getSessionId(session), sessionId));
        }

        return new PDMUser(getUsername(session), "N/A", getGrantedAuthorities(session));
    }

    private List<GrantedAuthority> getGrantedAuthorities(Map<String, Object> session) {
        List<String> roles = getAuthorities(session);
        if (roles == null || roles.isEmpty()) {
            return Collections.emptyList();
        }
        return roles.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
    }

    private String getSessionId(Map<String, Object> session) {
        return (String) session.get("sessionId");
    }

    private String getUsername(Map<String, Object> session) {
        return (String) session.get("username");
    }

    private List<String> getAuthorities(Map<String, Object> session) {
        return (List<String>) session.get("authorities");
    }
}
