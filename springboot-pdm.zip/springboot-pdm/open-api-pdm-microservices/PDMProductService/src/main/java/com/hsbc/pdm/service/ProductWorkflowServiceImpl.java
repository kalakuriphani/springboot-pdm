package com.hsbc.pdm.service;

import com.hsbc.openbanking.jsonschema.JsonSchemaProvider;
import com.hsbc.openbanking.jsonschema.JsonSchemaType;
import com.hsbc.openbanking.jsonschema.ProductDetailsProcessor;
import com.hsbc.openbanking.jsonschema.ProductDetailsValidationException;
import com.hsbc.openbanking.jsonschema.wrapper.ProductWrapper;
import com.hsbc.openbanking.jsonschema.wrapper.ProductWrapperFactory;
import com.hsbc.pdm.common.*;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.converter.ProductVariationConverter;
import com.hsbc.pdm.entities.dynamo.DynamoProduct;
import com.hsbc.pdm.entities.dynamo.DynamoProductAudit;
import com.hsbc.pdm.productservice.model.Product;
import com.hsbc.pdm.productservice.model.ProductVariation;
import com.hsbc.pdm.repository.ProductAuditRepository;
import com.hsbc.pdm.repository.ProductRepository;
import com.hsbc.pdm.repository.ProductTemplateRepository;
import org.apache.commons.collections.CollectionUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.util.Assert;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.hsbc.pdm.common.JsonSchemaUtils.getLatestJsonSchemaType;
import static com.hsbc.pdm.common.WorkflowActions.*;
import static com.hsbc.pdm.common.model.StatusEnum.*;

public class ProductWorkflowServiceImpl<ID> implements ProductWorkflowService<ID> {

    private static final Logger LOG = LoggerFactory.getLogger(ProductWorkflowServiceImpl.class);

    private static final String ORGANISATION_BIC = "MIDLGB22";
    private static final String ORGANISATION_LEGAL_NAME = "HSBCG";
    private static final String ORGANISATION_TRADEMARK_IPO_CODE = "UK";
    private static final String ORGANISATION_TRADEMARK_ID = "HSBC UK";
    private static final String ORGANISATION_TRADEMARK_ID_FIRST_DIRECT = "first direct";
    private static final String ORGANISATION_TRADEMARK_ID_MARKS_SPENCER = "M&S Bank";


    public static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private static final boolean VALIDATE_PRODUCT_DETAILS = true;

    private static final boolean SKIP_PRODUCT_DETAILS_VALIDATION = false;

    @Autowired
    private ProductRepository<com.hsbc.pdm.entities.Product<ID>, ID> productRepository;

    @Autowired
    private ProductTemplateRepository productTemplateRepository;

    @Autowired
    private ProductVariationConverter productVariationConverter;

    @Autowired
    private UserService userService;

    @Autowired
    private JsonSchemaProvider jsonSchemaProvider;

    @Autowired
    private ProductDetailsProcessor productDetailsProcessor;

    @Autowired
    private ProductWrapperFactory productWrapperFactory;

    @Autowired
    private ProductFactory<ID> productFactory;

    @Autowired
    private ProductAuditRepository productAuditRepository;

    @Override
    public List<Product> getAuthorisedProducts(List<Product> products, Authentication authentication) {
        return products.stream()
                .filter(product -> isProductAccessible(product.getProductType(), authentication))
                .collect(Collectors.toList());
    }

    @Override
    public ID create(Product product, Authentication authentication) {
        Assert.notNull(product, "Product cannot be null");
        Assert.notNull(product.getProductType(), "Product type cannot be null");
        Assert.notNull(product.getProductTypeVersion(), "Product type version cannot be null");
        Assert.notNull(product.getVariations(), "Product variations cannot be null");
        Assert.notEmpty(product.getVariations(), "Product variations cannot be empty");
        Assert.notNull(authentication, "Authentication cannot be null");

        validateAction(WorkflowActions.ACTION_EDIT, product.getProductType(), DRAFT, authentication);

        // product name from 1st variation takes precedence
        JsonSchemaType schemaType = JsonSchemaUtils.getJsonSchemaType(product.getProductType(), product.getProductTypeVersion());
        ProductWrapper productWrapper = productWrapperFactory.build(schemaType, product.getVariations().get(0).getDetails());
        String productName = productWrapper.getProductName();
        validateProductName(productName);
        validateOrganisation(productWrapper, product.getProductType());

        String externalProductType = productWrapper.getProductType();
        validateProductType(externalProductType);

        com.hsbc.pdm.entities.Product<ID> entity = buildDraftProduct(productName, product.getProductType(), externalProductType, product.getVariations(), authentication);
        applyJsonSchema(entity, SKIP_PRODUCT_DETAILS_VALIDATION);
        productRepository.insert(entity);

        product.setId(entity.getId().toString()); // update id in the model upstream
        return entity.getId();
    }

    @Override
    public ID copy(Product product, Authentication authentication) {
        Assert.notNull(product, "Product cannot be null");
        Assert.notNull(product.getProductType(), "Product type cannot be null");
        Assert.notNull(product.getProductTypeVersion(), "Product type version cannot be null");
        Assert.notNull(product.getVariations(), "Product variations cannot be null");
        Assert.notEmpty(product.getVariations(), "Product variations cannot be empty");
        Assert.notNull(authentication, "Authentication cannot be null");

        validateAction(WorkflowActions.ACTION_EDIT, product.getProductType(), DRAFT, authentication);

        // product name from 1st variation takes precedence
        JsonSchemaType schemaType = JsonSchemaUtils.getJsonSchemaType(product.getProductType(), product.getProductTypeVersion());
        ProductWrapper productWrapper = productWrapperFactory.build(schemaType, product.getVariations().get(0).getDetails());
        String productName = productWrapper.getProductName();
        validateProductName(productName);
        validateOrganisation(productWrapper, product.getProductType());

        String externalProductType = productWrapper.getProductType();
        validateProductType(externalProductType);

        /**
         * Make sure product name is unique.
         */
        productName = String.format("%s - copy from %s", productName, UTCDateUtils.format(UTCDateUtils.now(), DATETIME_FORMATTER));
        com.hsbc.pdm.entities.Product<ID> entity = buildDraftProduct(productName, product.getProductType(), externalProductType, product.getVariations(), authentication);
        applyJsonSchema(entity, SKIP_PRODUCT_DETAILS_VALIDATION);
        productRepository.insert(entity);

        product.setId(entity.getId().toString()); // update id in the model upstream
        return entity.getId();
    }

    private void validateVariations(List<com.hsbc.pdm.entities.ProductVariation> variations) {
        variations.forEach(variation -> {
            if (variation.getId() == null) {
                throw new RuntimeException("Variation id cannot be null");
            }
            if (StringUtils.isBlank(variation.getVariationName())) {
                throw new UserFriendlyException("Variation name cannot be blank");
            }
        });
    }

    private void validateProductName(String productName) {
        if (StringUtils.isBlank(productName)) {
            throw new UserFriendlyException("Product Name cannot be blank");
        }
    }

    private void validateProductType(String productType) {
        if (StringUtils.isBlank(productType)) {
            throw new UserFriendlyException("Product Type cannot be blank");
        }
    }

    private void validateOrganisation(ProductWrapper productWrapper, ProductTypeEnum productType) {
        if (StringUtils.isNotBlank(productWrapper.getLEI()))  {
            throw new UserFriendlyException("Legal Entity Identifier (LEI) must be blank");
        }
        if (StringUtils.isBlank(productWrapper.getBIC())
                || !productWrapper.getBIC().equals(ORGANISATION_BIC)) {
            throw new UserFriendlyException("Business Identification Code (BIC) must be '" + ORGANISATION_BIC + "'");
        }
        if (StringUtils.isBlank(productWrapper.getLegalName())
                || !productWrapper.getLegalName().equals(ORGANISATION_LEGAL_NAME)) {
            throw new UserFriendlyException("Legal Name must be '" + ORGANISATION_LEGAL_NAME + "'");
        }
        if (StringUtils.isBlank(productWrapper.getTrademarkIPOCode())
                || !productWrapper.getTrademarkIPOCode().equals(ORGANISATION_TRADEMARK_IPO_CODE)) {
            throw new UserFriendlyException("Trademark IPO Code must be '" + ORGANISATION_TRADEMARK_IPO_CODE + "'");
        }
        Assert.hasText(productWrapper.getProductType(), "Product type cannot be blank");
        switch (productType) {
            case PCAFD:
                if (StringUtils.isBlank(productWrapper.getTradeMarkId())
                        || !productWrapper.getTradeMarkId().equals(ORGANISATION_TRADEMARK_ID_FIRST_DIRECT)) {
                    throw new UserFriendlyException("Trademark ID must be '" + ORGANISATION_TRADEMARK_ID_FIRST_DIRECT + "'");
                }
                break;
            case PCAMNS:
                if (StringUtils.isBlank(productWrapper.getTradeMarkId())
                        || !productWrapper.getTradeMarkId().equals(ORGANISATION_TRADEMARK_ID_MARKS_SPENCER)) {
                    throw new UserFriendlyException("Trademark ID must be '" + ORGANISATION_TRADEMARK_ID_MARKS_SPENCER + "'");
                }
                break;
            default:
                if (StringUtils.isBlank(productWrapper.getTradeMarkId())
                        || !productWrapper.getTradeMarkId().equals(ORGANISATION_TRADEMARK_ID)) {
                    throw new UserFriendlyException("Trademark ID must be '" + ORGANISATION_TRADEMARK_ID + "'");
                }
                break;
        }
    }

    private void ensureUniqueId(List<com.hsbc.pdm.entities.ProductVariation> variations) {
        // ensure all variations have unique id
        variations.forEach(variation -> variation.setId(ObjectId.get().toHexString()));
    }

    private void ensureProductName(String productName, ProductTypeEnum productType, String productVersion, List<com.hsbc.pdm.entities.ProductVariation> variations) {
        // ensure all variations have same product name
        JsonSchemaType schemaType = JsonSchemaUtils.getJsonSchemaType(productType, productVersion);
        variations.forEach(variation -> {
            ProductWrapper productWrapper = productWrapperFactory.build(schemaType, variation.getDetails());
            productWrapper.setProductName(productName);
            variation.setVariationName(productName); // TODO : This is only temporary here. Once variations are implemented in the UI this must be removed from here.
        });
    }

    private com.hsbc.pdm.entities.Product<ID> buildDraftProduct(String productName, ProductTypeEnum internalProductType, String externalProductType, List<ProductVariation> variations, Authentication authentication) {
        com.hsbc.pdm.entities.Product<ID> product = productFactory.create();
        product.setId(productFactory.createId());
        product.setCreatedAt(UTCDateUtils.now());
        product.setCreatedBy(authentication.getName());

        product.setVariations(productVariationConverter.convertModels(variations));
        ensureUniqueId(product.getVariations());

        JsonSchemaType schemaType = getLatestJsonSchemaType(internalProductType);
        ensureProductName(productName, internalProductType, schemaType.getVersion(), product.getVariations());
        validateVariations(product.getVariations());

        product.setApprovedVariations(Collections.emptyList());
        product.setStatusEnum(DRAFT);
        product.setProductName(productName);
        product.setProductType(externalProductType);
        product.setProductTypeVersion(schemaType.getVersion());
        product.setProductTypeInternalEnum(internalProductType);
        product.setCountry(StringUtils.PRODUCT_COUNTRY); // TODO : use proper country when multiple countries are supported
        return product;
    }

    @Override
    public void update(ID productId, List<ProductVariation> productVariations, Authentication authentication) {
        Assert.notNull(productId, "Product id cannot be null");
        Assert.notNull(productVariations, "Product variations cannot be null");
        Assert.notEmpty(productVariations, "Product variations cannot be empty");
        Assert.notNull(authentication, "Authentication cannot be null");

        com.hsbc.pdm.entities.Product<ID> product = productRepository.findOne(productId);
        validateAction(WorkflowActions.ACTION_EDIT, product.getProductTypeInternalEnum(), product.getStatusEnum(), authentication);

        // product name from 1st variation takes precedence
        JsonSchemaType schemaType = JsonSchemaUtils.getJsonSchemaType(product.getProductTypeInternalEnum(), product.getProductTypeVersion());
        ProductWrapper productWrapper = productWrapperFactory.build(schemaType, productVariations.get(0).getDetails());
        String productName = productWrapper.getProductName();
        validateProductName(productName);
        validateOrganisation(productWrapper, product.getProductTypeInternalEnum());

        product.setVariations(productVariationConverter.convertModels(productVariations));
        validateVariations(product.getVariations());
        ensureProductName(productName, product.getProductTypeInternalEnum(), product.getProductTypeVersion(), product.getVariations());
        product.setProductName(productName);

        product.setProductTypeVersion(getLatestJsonSchemaType(product.getProductTypeInternalEnum()).getVersion()); // TODO : use proper version when multiple schema version is supported

        applyJsonSchema(product, SKIP_PRODUCT_DETAILS_VALIDATION);

        saveToDatastore(product, DRAFT, authentication);
    }

    private void saveToDatastore(com.hsbc.pdm.entities.Product product, StatusEnum statusEnum, Authentication authentication) {
        product.setStatusEnum(statusEnum);
        product.setUpdatedAt(UTCDateUtils.now());
        product.setUpdatedBy(authentication.getName());

        // TODO : validate model instance as per business rules
        // TODO : use id & version when updating a product (to resolve concurrent save operation)

        productRepository.save(product);

        // TODO : save audit trails
    }

    @Override
    public void requestDelete(ID productId, Authentication authentication) {
        Assert.notNull(productId, "Product id cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");

        com.hsbc.pdm.entities.Product product = productRepository.findOne(productId);

        StatusEnum status = product.getStatusEnum();
        switch (status) {
            case DRAFT:
            case SUBMITTED_FOR_APPROVAL:
                /**
                 * If a product has APPROVED variations and also is in DRAFT or SUBMITTED_FOR_APPROVAL status
                 * we impersonate status as APPROVED to allow the action to complete.
                 */
                if (CollectionUtils.isNotEmpty(product.getApprovedVariations())) {
                    status = APPROVED;
                    product.setVariations(Collections.emptyList()); // the working state is also cleared
                }
                break;
            case SUBMITTED_FOR_DELETION:
                throw new UserFriendlyException("This product has already been submitted for deletion");
        }
        validateAction(WorkflowActions.ACTION_REQUEST_DELETE, product.getProductTypeInternalEnum(), status, authentication);

        saveToDatastore(product, SUBMITTED_FOR_DELETION, authentication);
    }

    @Override
    public void publish(ID productId, Authentication authentication) {
        Assert.notNull(productId, "Product id cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");
        throw new UnsupportedOperationException("Not implemented yet");
    }

    @Override
    public boolean isApprovalAllowed(ID productId, Authentication authentication) {
        if (!userService.isChecker(authentication)) {
            // normally should never happen, fail fast
            throw new IllegalStateException(String.format("The user '%s' is not a checker role", authentication.getName()));
        }
        com.hsbc.pdm.entities.Product product = productRepository.findOne(productId);
        if (product.getStatusEnum() != SUBMITTED_FOR_APPROVAL) {
            // normally should never happen, fail fast
            throw new IllegalStateException(String.format("The product %s is not in SUBMITTED_FOR_APPROVAL state", productId));
        }
        if (CollectionUtils.isEmpty(product.getVariations())) {
            // normally should never happen, fail fast
            throw new IllegalStateException(String.format("The product %s has no variations to be approved", productId));
        }
        Date lastApprovedAt = product.getApprovedAt();
        /**
         * If it's a product that has never been approved before then 'last approved date' will be null. In that case
         * just use product's create date, i.e. since the beginning of the product.
         */
        if (lastApprovedAt == null) {
            lastApprovedAt = product.getCreatedAt();
        }
        List<DynamoProductAudit> audits = productAuditRepository.getUserAudits(authentication.getName(), (DynamoProduct.Id) productId, lastApprovedAt);
        if (audits.size() == 0) {
            // this user has never done anything with this product since last approved action, so the user can approve it
            return true;
        }

        return isOnlyApproveActionsPresent(audits);
    }

    private boolean isOnlyApproveActionsPresent(List<DynamoProductAudit> audits) {
        Assert.notEmpty(audits, "Audits cannot be empty");
        int counter = 0; // counter for approval actions
        for (DynamoProductAudit audit : audits) {
            // when products are created first time the difference property can either be null or empty, so check it here
            if (CollectionUtils.isEmpty(audit.getProductDifferences())) {
                continue;
            }
            for (DynamoProductAudit.ProductDifference difference : audit.getProductDifferences()) {
                if (difference.getPropertyPath().equals(DynamoProduct.APPROVED_AT_FIELD)) {
                    // the change was APPROVE product, so it's ok
                    counter++;
                }
            }
        }
        /**
         * If the counter is equal with audits count (ideally 1) that means
         * that the user performed only APPROVE actions on that product which is fine.
         */
        if (counter == audits.size()) {
            return true;
        }
        // other workflow actions performed by this user are also present in the log
        return false;
    }

    @Override
    public void approveChange(ID productId, Authentication authentication) {
        Assert.notNull(productId, "Product id cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");

        com.hsbc.pdm.entities.Product<ID> product = productRepository.findOne(productId);
        validateAction(WorkflowActions.ACTION_APPROVE_CHANGE_REQUEST, product.getProductTypeInternalEnum(), product.getStatusEnum(), authentication);

        if (!isApprovalAllowed(productId, authentication)) {
            throw new UserFriendlyException(String.format("The user '%s' is not allowed to approve the product as the document has changes owned by this user since last time approved",
                    authentication.getName()));
        }

        Assert.notNull(product.getVariations(), "Variations cannot be null");
        Assert.notNull(product.getVariations(), "Variations cannot be empty");

        applyJsonSchema(product, VALIDATE_PRODUCT_DETAILS);

        product.setApprovedAt(new Date());
        product.setApprovedBy(authentication.getName());
        product.setApprovedVariations(product.getVariations()); // working copy becomes current now
        product.setVariations(Collections.emptyList()); // clear the working copy

        saveToDatastore(product, APPROVED, authentication);
    }

    @Override
    public void requestApprove(ID productId, Authentication authentication) {
        Assert.notNull(productId, "Product id cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");

        com.hsbc.pdm.entities.Product<ID> product = productRepository.findOne(productId);
        validateAction(WorkflowActions.ACTION_REQUEST_APPROVE, product.getProductTypeInternalEnum(), product.getStatusEnum(), authentication);

        applyJsonSchema(product, VALIDATE_PRODUCT_DETAILS);

        saveToDatastore(product, SUBMITTED_FOR_APPROVAL, authentication);
    }

    @Override
    public void approveDelete(ID productId, Authentication authentication) {
        Assert.notNull(productId, "Product id cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");

        com.hsbc.pdm.entities.Product product = productRepository.findOne(productId);
        validateAction(WorkflowActions.ACTION_APPROVE_DELETE_REQUEST, product.getProductTypeInternalEnum(), product.getStatusEnum(), authentication);

        /**
         * Clear the working copy as it's no longer available.
         */
        product.setVariations(Collections.emptyList());

        saveToDatastore(product, DELETED, authentication);
    }

    @Override
    public void rejectChange(ID productId, Authentication authentication) {
        Assert.notNull(productId, "Product id cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");

        com.hsbc.pdm.entities.Product product = productRepository.findOne(productId);
        validateAction(WorkflowActions.ACTION_REJECT_CHANGE_REQUEST, product.getProductTypeInternalEnum(), product.getStatusEnum(), authentication);

        saveToDatastore(product, DRAFT, authentication);
    }

    @Override
    public void rejectDelete(ID productId, Authentication authentication) {
        Assert.notNull(productId, "Product id cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");

        com.hsbc.pdm.entities.Product product = productRepository.findOne(productId);
        validateAction(WorkflowActions.ACTION_REJECT_DELETE_REQUEST, product.getProductTypeInternalEnum(), product.getStatusEnum(), authentication);

        saveToDatastore(product, APPROVED, authentication);
    }

    @Override
    public void hardDelete(ID productId, Authentication authentication) {
        Assert.notNull(productId, "Product id cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");

        com.hsbc.pdm.entities.Product<ID> product = productRepository.findOne(productId);
        validateAction(WorkflowActions.ACTION_HARD_DELETE, product.getProductTypeInternalEnum(), product.getStatusEnum(), authentication);

        /**
         * The product has APPROVED data? Then DELETE the working copy only and restore APPROVED state.
         */
        if (!CollectionUtils.isEmpty(product.getApprovedVariations())) {
            product.setVariations(Collections.emptyList());
            saveToDatastore(product, APPROVED, authentication);
            return;
        }

        /**
         * The product has NO APPROVED data, so delete for good.
         */
        productRepository.delete(productId);
        // TODO : delete audit trails if any
    }

    @Override
    public void suspend(ID productId, Authentication authentication) {
        Assert.notNull(productId, "Product id cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");
        throw new UnsupportedOperationException("Not implemented yet");
    }

    @Override
    public Map<UserRoles.RoleType, Set<ProductTypeEnum>> getProductTypeACL(Authentication authentication) {
        Assert.notNull(authentication, "Authentication cannot be null");

        Map<UserRoles.RoleType, Set<ProductTypeEnum>> acl = new HashMap<>();
        for (UserRoles.RoleType roleType : UserRoles.RoleType.values()) {
            acl.put(roleType, new HashSet<>());
        }

        for (ProductTypeEnum productType : ProductTypeEnum.values()) {
            if (!isProductAccessible(productType, authentication)) {
                continue; // product type is not accessible, continue to next product type
            }
            Set<String> productTypeACL = productTemplateRepository.getProductTypeACLs(productType);
            if (productTypeACL.size() == 0) { // normally should never happen
                throw new RuntimeException("Product type " + productType + " has no ACL assigned");
            }

            // check if user's groups are within product's groups
            Set<String> userRoles = userService.getRoles(authentication);
            for (UserRoles.RoleType roleType : UserRoles.RoleType.values()) {
                if (roleType.containsAnyOf(userRoles)) {
                    Set<ProductTypeEnum> productTypes = acl.get(roleType);
                    productTypes.add(productType);
                }
            }
        }
        return acl;
    }


    @Override
    public boolean isProductAccessible(ProductTypeEnum productType, Authentication authentication) {
        Assert.notNull(productType, "Product type cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");

        // Get the groups that are allowed to access the product.
        Set<String> productTypeACL = productTemplateRepository.getProductTypeACLs(productType);
        if (productTypeACL.size() == 0) { // normally should never happen
            throw new RuntimeException("Product type " + productType + " has no ACL assigned");
        }

        // check if user's groups are within product's groups
        Set<String> userRoles = userService.getRoles(authentication);
        return userRoles.stream().anyMatch(userRole -> productTypeACL.contains(userRole));
    }

    @Override
    public Set<String> getUserActions(StatusEnum productStatus, Authentication authentication) {
        Assert.notNull(productStatus, "Product status cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");

        Set<String> actions = new HashSet<>();
        if (userService.isMaker(authentication)) {
            actions.addAll(getMakerActions(productStatus));
        }
        if (userService.isChecker(authentication)) {
            actions.addAll(getCheckerActions(productStatus));
        }

        return actions;
    }

    @Override
    public Set<String> getUserActions(ID productId, StatusEnum expectedProductStatus, Authentication authentication) {
        Assert.notNull(productId, "Product id cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");

        com.hsbc.pdm.entities.Product product = productRepository.findOne(productId);
        if (product == null) {
            /**
             * If product does not exist then no actions are returned. Works well for the scenario
             * when a product is hard deleted the user is gracefully sent from Product to Products page.
             */
            return Collections.emptySet();
        }

        // user does not have access to this product type
        if (!isProductAccessible(product.getProductTypeInternalEnum(), authentication)) {
            return Collections.emptySet();
        }

        /**
         * Verify if expected status is compatible with the current status.
         */
        if (product.getStatusEnum() == expectedProductStatus
                || (CollectionUtils.isNotEmpty(product.getApprovedVariations()) && expectedProductStatus == APPROVED)) {
            return getUserActions(expectedProductStatus, authentication);
        }

        /**
         * Normally must never happen, but if it does then gracefully return NO actions.
         */
        return Collections.emptySet();
    }

    @Override
    public Set<String> getMakerActions(StatusEnum productStatus) {
        Set<String> actions = new HashSet<>();
        switch (productStatus) {
            case DRAFT:
                actions.add(ACTION_EDIT);
                actions.add(ACTION_REQUEST_APPROVE);
                actions.add(ACTION_HARD_DELETE);
                actions.add(ACTION_COPY);
                break;
            case SUBMITTED_FOR_APPROVAL:
                actions.add(ACTION_COPY);
                break;
            case SUBMITTED_FOR_DELETION:
                actions.add(ACTION_COPY);
                break;
            case APPROVED:
                actions.add(ACTION_REQUEST_DELETE);
                actions.add(ACTION_COPY);
                actions.add(ACTION_EDIT);
                break;
            case DELETED:
                actions.add(ACTION_COPY);
                break;
            case PUBLISHED:
                actions.add(ACTION_REQUEST_DELETE);
                actions.add(ACTION_COPY);
                actions.add(ACTION_EDIT);
                break;
            case SUSPENDED:
                actions.add(ACTION_REQUEST_DELETE);
                actions.add(ACTION_COPY);
                actions.add(ACTION_EDIT);
                actions.add(ACTION_REQUEST_APPROVE);
                break;
            default:
                throw new RuntimeException("Unexpected product-status = " + productStatus);
        }
        return actions;
    }

    @Override
    public Set<String> getCheckerActions(StatusEnum productStatus) {
        Set<String> actions = new HashSet<>();
        switch (productStatus) {
            case DRAFT:
                // can do nothing
                break;
            case SUBMITTED_FOR_APPROVAL:
                actions.add(ACTION_APPROVE_CHANGE_REQUEST);
                actions.add(ACTION_REJECT_CHANGE_REQUEST);
                break;
            case SUBMITTED_FOR_DELETION:
                actions.add(ACTION_APPROVE_DELETE_REQUEST);
                actions.add(ACTION_REJECT_DELETE_REQUEST);
                break;
            case APPROVED:
                /**
                 * As this is the state when the System kicks in to publish the product (on schedule basis)
                 * it's advisable not to perform any change on the product (like suspend before it has been published)
                 * until the product has been published, otherwise there is a risk to end-up with a wrong/desynchronized workflow status.
                 */
                break;
            case DELETED:
                // can do nothing
                break;
            case PUBLISHED:
                actions.add(ACTION_SUSPEND);
                break;
            case SUSPENDED:
                actions.add(ACTION_APPROVE_CHANGE_REQUEST);
                break;
            default:
                throw new RuntimeException("Unexpected product-status = " + productStatus);
        }
        return actions;
    }

    @Override
    public boolean isActionAllowed(String action, StatusEnum productStatus, Authentication authentication) {
        Set<String> actions = getUserActions(productStatus, authentication);
        return actions.contains(action.toUpperCase());
    }

    @Override
    public void validateAction(String action, ProductTypeEnum productType, StatusEnum productStatus, Authentication authentication) {
        Assert.notNull(action, "Action cannot be null");
        Assert.notNull(productType, "Product type cannot be null");
        Assert.notNull(productStatus, "Product status cannot be null");
        Assert.notNull(authentication, "Authentication cannot be null");

        if (!isProductAccessible(productType, authentication)) {
            throw new WorkflowAccessNotAllowedException(productType, authentication);
        }

        if (!isActionAllowed(action, productStatus, authentication)) {
            throw new WorkflowActionNotAllowedException(action, productStatus, authentication);
        }
    }

    @Override
    public void applyJsonSchema(List<com.hsbc.pdm.entities.ProductVariation> variations, JsonSchemaType schemaType, boolean validate) {
        if (variations.size() > 1) {
            throw new RuntimeException("Multiple variations not supported yet");
        }
        try {
            Map<String, Object> productDetails = productDetailsProcessor.process(variations.get(0).getDetails(), schemaType);
            if (validate) {
                productDetailsProcessor.validate(productDetails, schemaType);
            }
            variations.get(0).setDetails(productDetails);
        } catch (ProductDetailsValidationException e) {
            /**
             * We are interested in this exception very much, so re-throw it so that clients are properly notified.
             */
            throw e;
        } catch (IOException e) {
            /**
             * Normally should never happen, just wrap IOException exception
             */
            throw new RuntimeException(e);
        }
    }

    private void applyJsonSchema(com.hsbc.pdm.entities.Product<ID> product, boolean validate) {
        JsonSchemaType jsonSchema = JsonSchemaUtils.getJsonSchemaType(product.getProductTypeInternalEnum(), product.getProductTypeVersion());
        applyJsonSchema(product.getVariations(), jsonSchema, validate);
    }
}
