package com.hsbc.pdm.controllers;

import com.hsbc.openbanking.jsonschema.ProductDetailsValidationException;
import com.hsbc.pdm.common.ResourceNotFoundException;
import com.hsbc.pdm.common.UserFriendlyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.util.Collection;

/**
 * Created by 44023148 on 29/01/2017.
 */
@RestControllerAdvice
public class RestExceptionHandler {

    private static final Logger LOG = LoggerFactory.getLogger(RestExceptionHandler.class);

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @org.springframework.web.bind.annotation.ExceptionHandler
    public @ResponseBody ErrorModel handleGenericException(UserFriendlyException e) {
        LOG.error(e.getMessage(), e);
        return new ErrorModel(e.getMessage(), e);
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @org.springframework.web.bind.annotation.ExceptionHandler
    public @ResponseBody ErrorModel handleGenericException(ResourceNotFoundException e) {
        LOG.error(e.getMessage(), e);
        return new ErrorModel(e.getMessage(), e);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @org.springframework.web.bind.annotation.ExceptionHandler
    public @ResponseBody ErrorModel handleGenericException(ProductDetailsValidationException e) {
        LOG.error(e.getMessage(), e);
        ErrorModel model = new ErrorModel(e.getMessage(), e);
        model.setSchemaValidationErrors(e.getValidationErrors());
        return model;
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @org.springframework.web.bind.annotation.ExceptionHandler
    public @ResponseBody ErrorModel handleGenericException(Exception e) {
        LOG.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
        return new ErrorModel(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
    }


    public static class ErrorModel implements Serializable {

        private String friendlyMessage;

        private Collection<ProductDetailsValidationException.ValidationError> schemaValidationErrors;

        private String stackTrace;

        public ErrorModel() {}

        public ErrorModel(String friendlyMessage, Exception cause) {
            this.friendlyMessage = friendlyMessage;
            this.stackTrace = getStackTrace(cause);
        }

        public String getFriendlyMessage() {
            return friendlyMessage;
        }

        public String getStackTrace() {
            return stackTrace;
        }

        private String getStackTrace(Exception e) {
            StringWriter sw = new StringWriter();
            try (PrintWriter pw = new PrintWriter(sw)) {
                e.printStackTrace(pw);
                return sw.toString();
            }
        }

        public Collection<ProductDetailsValidationException.ValidationError> getSchemaValidationErrors() {
            return schemaValidationErrors;
        }

        public void setSchemaValidationErrors(Collection<ProductDetailsValidationException.ValidationError> schemaValidationErrors) {
            this.schemaValidationErrors = schemaValidationErrors;
        }
    }
}
