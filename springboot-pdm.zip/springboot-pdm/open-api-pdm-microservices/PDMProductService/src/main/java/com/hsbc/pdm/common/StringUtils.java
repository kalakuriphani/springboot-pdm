package com.hsbc.pdm.common;

public class StringUtils {

    public static final String PRODUCT_COUNTRY = "GB";

    private StringUtils() {}

    public static boolean isBlank(String s) {
        return org.apache.commons.lang.StringUtils.isBlank(s);
    }

    public static boolean isNotBlank(String s) {
        return org.apache.commons.lang.StringUtils.isNotBlank(s);
    }
}
