package com.hsbc.pdm.common;

/**
 * Created by 44023148 on 26/01/2017.
 */
public interface WorkflowActions {

    String ACTION_EDIT = "EDIT";
    String ACTION_REQUEST_APPROVE = "REQUEST-APPROVE"; // ask for approval
    String ACTION_REQUEST_DELETE = "REQUEST-DELETE"; // ask to delete
    String ACTION_COPY = "COPY";
    String ACTION_APPROVE_CHANGE_REQUEST = "APPROVE-CHANGE-REQUEST"; // approve changes
    String ACTION_APPROVE_DELETE_REQUEST = "APPROVE-DELETE-REQUEST"; // approve deletion
    String ACTION_REJECT_CHANGE_REQUEST = "REJECT-CHANGE-REQUEST";
    String ACTION_REJECT_DELETE_REQUEST = "REJECT-DELETE-REQUEST";
    String ACTION_PUBLISH = "PUBLISH";
    String ACTION_SUSPEND = "SUSPEND";
    String ACTION_HARD_DELETE = "HARD-DELETE"; // delete only DRAFT or CHANGE_REJECTED ones

}
