package com.hsbc.pdm.common;

import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.entities.Product;

/**
 * Created by 44023148 on 03/02/2017.
 */
public interface ProductFactory<ID> {

    Product<ID> create();

    <E> E createId(String id, ProductTypeEnum productType);

    ID createId(String id);

    ID createId();

    String getLocation(ProductTypeEnum productType, String productVersion, StatusEnum productStatus, ID id);
}
