package com.hsbc.pdm.common;

/**
 * Created by 44023148 on 29/01/2017.
 */
public class UserFriendlyException extends RuntimeException {

    public UserFriendlyException(String message) {
        super(message);
    }

    public UserFriendlyException(String message, Exception cause) {
        super(message, cause);
    }
}
