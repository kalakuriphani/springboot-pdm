package com.hsbc.pdm.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by 44023148 on 15/02/2017.
 */
@Component
public class ProxyConfig {

    @Value("${proxy.hostname}")
    public String proxyHost;

    @Value("${proxy.port}")
    private int proxyPort;

    @Value("${proxy.type}")
    private String proxyType;

    @Value("${proxy.enabled}")
    private boolean proxyEnabled;

    @Value("${proxy.username}")
    private String userName;

    @Value("${proxy.password}")
    private String password;

    public boolean isProxyEnabled() {
        return proxyEnabled;
    }

    public String getProxyHost() {
        return proxyHost;
    }

    public int getProxyPort() {
        return proxyPort;
    }

    public String getProxyType() {
        return proxyType;
    }

    public String getUserName() { return userName;}

    public String getPassword() { return  password;}
}
