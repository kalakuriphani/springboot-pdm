package com.hsbc.pdm.service;

import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.productservice.model.Product;

import java.util.List;
import java.util.Optional;

/**
 * Created by 44023148 on 20/02/2017.
 */
public interface ProductService<ID> {

    Optional<Product> getProduct(ID productId, String productVersion, StatusEnum expectedProductStatus);

    List<Product> getProducts();

    List<Product> getProducts(ProductTypeEnum productType);

    List<Product> getProducts(StatusEnum productStatus);
}
