/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.pdm.controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.openbanking.jsonschema.JsonSchemaProvider;
import com.hsbc.openbanking.jsonschema.JsonSchemaType;
import com.hsbc.pdm.common.JsonSchemaUtils;
import com.hsbc.pdm.common.ResourceNotFoundException;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.productservice.model.ProductTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */

@RestController
@RequestMapping("product-template")
@EnableDiscoveryClient
@EnableAutoConfiguration
public class ProductTemplateController {

    private static final Logger LOG = LoggerFactory.getLogger(ProductTemplateController.class);

    @Autowired
    JsonSchemaProvider schemaProvider;

    @Autowired
    ObjectMapper objectMapper;


    @RequestMapping(method = RequestMethod.GET, path = "{type}", produces = "application/json")
    public @ResponseBody ProductTemplate getProductTemplate(@PathVariable(value = "type") final String sProductType) throws IOException {
        ProductTypeEnum productType;
        try {
            productType = ProductTypeEnum.valueOf(sProductType.toUpperCase());
        } catch (Exception e) {
            throw new ResourceNotFoundException(String.format("Product type %s does not exist", sProductType), e);
        }
        return getProductTemplate(productType);
    }

    private JsonNode getJsonSchema(JsonSchemaType schemaType) {
        try {
            return schemaProvider.getMangledSchema(schemaType);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @RequestMapping(method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<ProductTemplate> getProductTemplates() throws IOException {
        LOG.debug("Fetch all product templates..");
        List<ProductTemplate> productTemplates = new ArrayList<>();
        for (ProductTypeEnum productType : ProductTypeEnum.values()) {
            productTemplates.add(getProductTemplate(productType));
        }
        LOG.debug("Found product templates : " + productTemplates.size());
        return productTemplates;
    }

    private ProductTemplate getProductTemplate(ProductTypeEnum productType) throws IOException {
        ProductTemplate productTemplate = new ProductTemplate();
        productTemplate.setProductType(productType.name());

        JsonSchemaType schemaType = JsonSchemaUtils.getLatestJsonSchemaType(productType);
        Object schema = schemaProvider.getMangledSchema(schemaType);
        productTemplate.setSchema(schema);

        switch (ProductTypeEnum.valueOf(productTemplate.getProductType())) {
            case PCAHSBC:
                productTemplate.setTitle("Personal Current Account (HSBC)");
                break;
            case BCA:
                productTemplate.setTitle("Business Current Account");
                break;
            case SMEL:
                productTemplate.setTitle("SME Lending");
                break;
            case CCC:
                productTemplate.setTitle("Commercial Credit Cards");
                break;
            case PCAMNS:
                productTemplate.setTitle("Personal Current Account (M&S Bank)");
                break;
            case PCAFD:
                productTemplate.setTitle("Personal Current Account (first direct)");
                break;
            default:
                throw new RuntimeException("Unexpected product type ( value = " + ProductTypeEnum.valueOf(productTemplate.getProductType()) + ")");
        }

        return productTemplate;
    }

    /**
     * Added method not allowed for the http non implemented methods
     *     1.1	Unnecessary HTTP Methods are allowed Concise title describing the most important fact(s) &/or impact of the finding
     *     X-References: 	Comet Issue ID: 56540
     *         The following HTTP Methods are allowed:
     *         OPTIONS, HEAD, GET, PUT, POST, DELETE, PATCH
     */

    @RequestMapping(method = RequestMethod.PUT , produces = "application/json", value={
            "",
            "/",
            "{type}"
    })
    public ResponseEntity noPutMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.POST , produces = "application/json", value={
            "",
            "/",
            "{type}"
    })
    public ResponseEntity noPostMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.DELETE , produces = "application/json", value={
            "",
            "/",
            "{type}"
    })
    public ResponseEntity noDeleteMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.HEAD , produces = "application/json", value={
            "",
            "/",
            "{type}"
    })
    public ResponseEntity noHeadMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.TRACE , produces = "application/json", value={
            "",
            "/",
            "{type}"
    })
    public ResponseEntity noTraceMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);

    }

    @RequestMapping(method = RequestMethod.PATCH , produces = "application/json", value={
            "",
            "/",
            "{type}"
    })
    public ResponseEntity noPatchMethod(){
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(null);
    }
}
