package com.hsbc.pdm.common;

import com.hsbc.pdm.auth.PDMAuthenticationToken;
import com.hsbc.pdm.common.model.StatusEnum;
import org.bson.types.ObjectId;
import org.springframework.security.core.Authentication;

import java.util.Arrays;

/**
 * Created by 44023148 on 27/01/2017.
 */
public class WorkflowActionNotAllowedException extends RuntimeException {

    public WorkflowActionNotAllowedException(String action, StatusEnum productStatus, Authentication authentication) {
        super(String.format("Workflow action '%s' not allowed ( product-status = %s , username = %s , roles = %s )",
                action,
                productStatus,
                authentication.getName(),
                Arrays.toString(((PDMAuthenticationToken)authentication).getRoles()))
        );
    }

    public WorkflowActionNotAllowedException(String action, ObjectId productId, StatusEnum productStatus, Authentication authentication) {
        super(String.format("Workflow action '%s' not allowed ( product-id = %s , product-status = %s , username = %s , roles = %s )",
                action,
                productId,
                productStatus,
                authentication.getName(),
                Arrays.toString(((PDMAuthenticationToken)authentication).getRoles()))
        );
    }
}
