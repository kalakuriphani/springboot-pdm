/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.pdm.repository.dynamo;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedScanList;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.entities.dynamo.DynamoProduct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.hsbc.pdm.entities.dynamo.DynamoProduct.*;

public class DynamoProductRepository extends AbstractDynamoRepository implements com.hsbc.pdm.repository.ProductRepository<DynamoProduct, DynamoProduct.Id> {

    private static final Logger LOG = LoggerFactory.getLogger(DynamoProductRepository.class);


    public DynamoProductRepository() {
        LOG.info("guragats: Initialize ProductRepository for DynamoDB");
    }


    @Override
    public List<DynamoProduct> getByProductType(ProductTypeEnum productType) {
        String queryExpression = buildEqualExpression(PRODUCT_TYPE_INTERNAL_FIELD);
        Map<String, AttributeValue> expressionValues = addExpressionValue(new HashMap<>(), PRODUCT_TYPE_INTERNAL_FIELD, productType.name());

        DynamoDBQueryExpression<DynamoProduct> expression = new DynamoDBQueryExpression<DynamoProduct>()
                .withKeyConditionExpression(queryExpression)
                .withExpressionAttributeValues(expressionValues);

        DynamoDBMapper mapper = getDynamoDBMapper();
        return mapper.query(DynamoProduct.class, expression);
    }

    @Override
    public List<DynamoProduct> getByStatus(String status) {
        String filterExpression = buildEqualExpression(STATUS_FIELD);
        Map<String, AttributeValue> expressionValues = addExpressionValue(new HashMap<>(), STATUS_FIELD, status);

        DynamoDBScanExpression expression = new DynamoDBScanExpression()
                .withFilterExpression(filterExpression)
                .withExpressionAttributeValues(expressionValues);

        DynamoDBMapper mapper = getDynamoDBMapper();
        return mapper.scan(DynamoProduct.class, expression);
    }

    @Override
    public DynamoProduct findOne(DynamoProduct.Id id) {
        DynamoDBMapper mapper = getDynamoDBMapper();
        return mapper.load(DynamoProduct.class, id.getHashKey(), id.getRangeKey());
    }

    @Override
    public List<DynamoProduct> findAll() {
        DynamoDBMapper mapper = getDynamoDBMapper();
        PaginatedScanList<DynamoProduct> pages = mapper.scan(DynamoProduct.class, new DynamoDBScanExpression());
        pages.loadAllResults();
        return pages;
    }

    @Override
    public DynamoProduct insert(DynamoProduct o) {
        assertBeforeSave(o);

        /**
         * Set version value to NULL explicitly here for 2 reasons:
         * - avoid ConditionalCheckFailedException, caused by optimistic locking version number check;
         * - because we create the object for the first time it makes sense to let DynamoDB take care of setting this value.
         */
        o.setVersion(null);

        DynamoDBMapper mapper = getDynamoDBMapper();
        mapper.save(o);

        return o;
    }

    @Override
    public void save(DynamoProduct o) {
        assertBeforeSave(o);
        Assert.notNull(o.getVersion(), "Version cannot be null");
        super.saveObject(o);
    }

    private void assertBeforeSave(DynamoProduct o) {
        Assert.notNull(o.getProductName(), "Product Name cannot be null");
        Assert.hasText(o.getProductName(), "Product Name cannot be empty");
        Assert.notNull(o.getProductTypeInternalEnum(), "Product Type cannot be null");
        Assert.notNull(o.getProductTypeVersion(), "Product Type Version cannot be null");
        Assert.hasText(o.getProductTypeVersion(), "Product Type Version cannot be empty");
        Assert.notNull(o.getCreatedAt(), "Created At cannot be null");
        Assert.notNull(o.getCreatedBy(), "Created By cannot be null");
        Assert.notNull(o.getCountry(), "Country cannot be null");
        Assert.hasText(o.getCountry(), "Country cannot be empty");
        Assert.notNull(o.getStatusEnum(), "Status cannot be null");
    }

    @Override
    public void delete(DynamoProduct.Id id) {
        DynamoDBMapper mapper = getDynamoDBMapper();
        DynamoProduct product = mapper.load(DynamoProduct.class, id.getHashKey(), id.getRangeKey());

        if (product != null) {
            mapper.delete(product);
        }
    }

    @Override
    public void deleteAll() {
        DynamoDBMapper mapper = getDynamoDBMapper();
        String projection = String.format("%s, %s, %s", ID_FIELD, PRODUCT_TYPE_INTERNAL_FIELD, VERSION_FIELD);
        PaginatedScanList<DynamoProduct> pages = mapper.scan(DynamoProduct.class, new DynamoDBScanExpression().withProjectionExpression(projection));
        pages.forEach(mapper::delete);
    }
}
