package com.hsbc.pdm.common;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class UTCDateUtils {

    public static final ZoneId UTC_ZONE = ZoneId.of("UTC");

    private UTCDateUtils() {}

    public static Date today() {
        return Date.from(LocalDate.now().atStartOfDay(UTC_ZONE).toInstant());
    }

    public static Date now() {
        return Date.from(LocalDateTime.now().atZone(UTC_ZONE).toInstant());
    }

    public static String format(Date date, DateTimeFormatter formatter) {
        return date.toInstant().atZone(UTC_ZONE).format(formatter);
    }

    public static Date parse(String date, DateTimeFormatter formatter) {
        return new Date(LocalDateTime.parse(date, formatter).atZone(UTC_ZONE).toInstant().toEpochMilli());
    }
}
