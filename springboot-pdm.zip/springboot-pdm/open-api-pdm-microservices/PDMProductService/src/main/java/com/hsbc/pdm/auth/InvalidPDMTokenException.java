package com.hsbc.pdm.auth;

import org.springframework.security.core.AuthenticationException;

/**
 * Created by 44023148 on 23/01/2017.
 */
public class InvalidPDMTokenException extends AuthenticationException {

    public InvalidPDMTokenException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidPDMTokenException(String message) {
        super(message);
    }
}
