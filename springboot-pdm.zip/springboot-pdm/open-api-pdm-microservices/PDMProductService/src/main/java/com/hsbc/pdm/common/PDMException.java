package com.hsbc.pdm.common;

public class PDMException extends Exception {

    public PDMException(String message) {
        super(message);
    }
}
