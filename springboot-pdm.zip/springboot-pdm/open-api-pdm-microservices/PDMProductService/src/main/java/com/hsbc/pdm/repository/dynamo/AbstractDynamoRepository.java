package com.hsbc.pdm.repository.dynamo;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverterFactory;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.hsbc.pdm.config.ProxyConfig;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.Map;

/**
 * Created by 44023148 on 28/02/2017.
 */
public abstract class AbstractDynamoRepository {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractDynamoRepository.class);

    @Value("${aws.dynamo.signingRegion}")
    private String signingRegion;

    @Value("${aws.dynamo.accessKeyId}")
    private String accessKeyId;

    @Value("${aws.dynamo.secretAccessKey}")
    private String secretAccessKey;

    @Value("${aws.dynamo.useLiveInstance}")
    private boolean useLiveInstance;

    @Autowired
    private Environment environment;

    @Autowired
    private ProxyConfig proxyConfig;

    protected AmazonDynamoDB dynamoClient;

    private DynamoDBMapperConfig dynamoMapperConfig;

    private AWSCredentials awsCredentials;

    @PostConstruct
    public void doPostConstruct() {

        AmazonDynamoDBClientBuilder clientBuilder = AmazonDynamoDBClientBuilder.standard();


        if (useLiveInstance) {
            clientBuilder.withRegion(signingRegion);

            if (proxyConfig.isProxyEnabled()) {
                ClientConfiguration clientConfiguration = new ClientConfiguration().withMaxErrorRetry(3);
                clientConfiguration.setProtocol(Protocol.valueOf(proxyConfig.getProxyType()));
                clientConfiguration.getApacheHttpClientConfig().setSslSocketFactory(new SSLConnectionSocketFactory(configureEmptyTrustStoreSslContext()));

                clientConfiguration.setProxyHost(proxyConfig.getProxyHost());
                clientConfiguration.setProxyPort(proxyConfig.getProxyPort());
                clientConfiguration.setProxyUsername(proxyConfig.getUserName());
                clientConfiguration.setProxyPassword(proxyConfig.getPassword());

                clientBuilder.withClientConfiguration(clientConfiguration);
            }

        } else {
            clientBuilder.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(getLocalServiceEndpoint(), signingRegion));
        }
        dynamoClient = clientBuilder
                .withCredentials(getAWSCredentialsProvider())
                .build();

        dynamoMapperConfig = DynamoDBMapperConfig.builder()
                .withTypeConverterFactory(DynamoDBTypeConverterFactory.standard().override()
//                        .with(AttributeValue.class, ProductVariation.class, new ProductVariationToAttributeConverter())
                        .build())
                .build();

        awsCredentials = new BasicAWSCredentials(accessKeyId, secretAccessKey);
    }

    protected void saveObject(Object o) {
        DynamoDBMapper mapper = getDynamoDBMapper();
        mapper.save(o);
    }

    protected DynamoDBMapper getDynamoDBMapper() {
        return new DynamoDBMapper(dynamoClient, dynamoMapperConfig);
    }

    protected String buildEqualExpression(String attributeName) {
        return String.format("%s = :%s", attributeName, attributeName);
    }

    protected Map<String, AttributeValue> addExpressionValue(Map<String, AttributeValue> expressions, String attributeName, String attributeValue) {
        expressions.put(":" + attributeName, new AttributeValue().withS(attributeValue));
        return expressions;
    }

    /**
     * TODO : check the certificate for validity
     * Because we are talking to AWS services using a VPN we decided
     * to accept all certificates for time being.
     */
    private SSLContext configureEmptyTrustStoreSslContext() {
        SSLContext sslContext = null;
        try {
            sslContext = SSLContext.getInstance("TLSv1.2");
            // Create a trust manager that does not validate certificate chains
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    X509Certificate[] x509Certificates = new X509Certificate[0];
                    return x509Certificates;
                }

                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    //Suppressing SSL check
                }

                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    //Suppressing SSL check
                }
            }};

            // Install the all-trusting trust manager
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
        } catch (KeyManagementException | NoSuchAlgorithmException e) {
            LOG.error("Unable to create SSL Context", e);
        }
        return sslContext;
    }

    private AWSCredentialsProvider getAWSCredentialsProvider() {
        return new AWSCredentialsProvider() {
            @Override
            public AWSCredentials getCredentials() {
                return awsCredentials;
            }

            @Override
            public void refresh() {
                // do nothing here
            }
        };
    }

    private String getLocalServiceEndpoint() {
        return environment.getProperty("aws.dynamo.localServiceEndpoint");
    }
}
