package com.hsbc.pdm.auth;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Created by 44023148 on 23/01/2017.
 */
public class AuthenticatePDMTokenFilter extends OncePerRequestFilter {

    private static final Logger LOG = LoggerFactory.getLogger(AuthenticatePDMTokenFilter.class);

    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String PDM_TOKEN_AUTHORIZATION = "PDM-Token";
    private static final String X_AUTH_TOKEN_HEADER = "X-Auth-Token";
    private static final String X_PDM_TOKEN_HEADER = "X-PDM-Token";

    private AuthenticationManager authenticationManager;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String authorization = request.getHeader(AUTHORIZATION_HEADER);
        LOG.debug("Received request header [ {} = {} ]", AUTHORIZATION_HEADER, authorization);
        if (authorization != null && authorization.equalsIgnoreCase(PDM_TOKEN_AUTHORIZATION)) {
            try {
                String pdmToken = request.getHeader(X_PDM_TOKEN_HEADER);
                LOG.debug("Received request header [ {} = {} ]", X_PDM_TOKEN_HEADER, pdmToken);
                if (StringUtils.isBlank(pdmToken)) {
                    throw new InvalidPDMTokenException(String.format("Request header %s not provided or invalid ( value = %s )", X_PDM_TOKEN_HEADER, pdmToken));
                }

                String authToken = request.getHeader(X_AUTH_TOKEN_HEADER);
                LOG.debug("Received request header [ {} = {} ]", X_AUTH_TOKEN_HEADER, authToken);

                HttpSession session = request.getSession(false);
                if (session != null) {
                    LOG.debug("Session already exists (won't create new), continue to next filter chain");
                    filterChain.doFilter(request, response);
                    return;
                }

                LOG.debug("Session does not exist, authenticate request");
                PDMAuthenticationToken token = new PDMAuthenticationToken(pdmToken, authToken);
                Authentication authentication = authenticationManager.authenticate(token);
                SecurityContextHolder.getContext().setAuthentication(authentication);

                LOG.debug("Request successfully authenticated, continue to next filter chain");
                filterChain.doFilter(request, response);

            } catch (AuthenticationException e) {
                LOG.debug("Request authentication failed : {}", e);
                LOG.warn("Request authentication failed : {}", e.getMessage());
                SecurityContextHolder.clearContext();
                response.setStatus(401);
                response.sendError(401, e.getMessage());
                response.flushBuffer();
            }
        } else {
            filterChain.doFilter(request, response);
        }
    }

    public void setAuthenticationManager(AuthenticationManager authenticationManager) {
        this.authenticationManager = authenticationManager;
    }
}
