package com.hsbc.pdm.auth;

public interface AuthorityProvider {

    PDMUser getPDMUser(String sessionId);

}
