/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.pdm.repository.mongo;

import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.entities.mongo.MongoProduct;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;

import java.util.List;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */

public class MongoProductRepository implements com.hsbc.pdm.repository.ProductRepository<MongoProduct, ObjectId> {

    private static final Logger LOG = LoggerFactory.getLogger(MongoProductRepository.class);

    @Autowired
    private MongoTemplate mongoTemplate;

    public MongoProductRepository() {
        LOG.info("guragats: Initialize ProductRepository for MongoDB");
    }

    @Override
    public List<MongoProduct> getByProductType(ProductTypeEnum productType) {
        BasicQuery query = new BasicQuery("{ productTypeInternal : '" + productType.name() + "'}");
        return mongoTemplate.find(query, MongoProduct.class);
    }

    @Override
    public List<MongoProduct> getByStatus(String status) {
        BasicQuery query = new BasicQuery("{ status : '" + status.toUpperCase() + "'}");
        return mongoTemplate.find(query, MongoProduct.class);
    }

    @Override
    public MongoProduct findOne(ObjectId id) {
        BasicQuery query = new BasicQuery("{ _id : '" + id.toHexString() + "'}");
        return mongoTemplate.findOne(query, MongoProduct.class);
    }

    @Override
    public List<MongoProduct> findAll() {
        return mongoTemplate.findAll(MongoProduct.class);
    }

    @Override
    public MongoProduct insert(MongoProduct o) {
        mongoTemplate.insert(o);
        return o;
    }

    @Override
    public void save(MongoProduct o) {
        mongoTemplate.save(o);
    }

    @Override
    public void delete(ObjectId id) {
        BasicQuery query = new BasicQuery("{ _id : '" + id.toHexString() + "'}");
        mongoTemplate.remove(query, MongoProduct.class);
    }

    @Override
    public void deleteAll() {
        mongoTemplate.dropCollection(MongoProduct.class);
    }
}
