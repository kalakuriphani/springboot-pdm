package com.hsbc.pdm.service;

import com.hsbc.openbanking.jsonschema.JsonSchemaType;
import com.hsbc.pdm.common.UserRoles;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.productservice.model.Product;
import com.hsbc.pdm.productservice.model.ProductVariation;
import org.springframework.security.core.Authentication;

import java.util.List;
import java.util.Map;
import java.util.Set;


public interface ProductWorkflowService<ID> {

    List<Product> getAuthorisedProducts(List<Product> products, Authentication authentication);

    ID create(Product product, Authentication authentication);

    ID copy(Product product, Authentication authentication);

    void update(ID productId, List<ProductVariation> productVariations, Authentication authentication);

    /**
     * Submit requestDelete for approval.
     */
    void requestDelete(ID productId, Authentication authentication);

    void publish(ID productId, Authentication authentication);

    boolean isApprovalAllowed(ID productId, Authentication authentication);

    /**
     * Approve change request.
     */
    void approveChange(ID productId, Authentication authentication);

    /**
     * Submit change for approval.
     */
    void requestApprove(ID productId, Authentication authentication);

    /**
     * Approve delete request.
     */
    void approveDelete(ID productId, Authentication authentication);

    /**
     * Reject change request.
     */
    void rejectChange(ID productId, Authentication authentication);

    /**
     * Reject delete request.
     */
    void rejectDelete(ID productId, Authentication authentication);

    void hardDelete(ID productId, Authentication authentication);

    void suspend(ID productId, Authentication authentication);

    boolean isProductAccessible(ProductTypeEnum productType, Authentication authentication);

    Set<String> getUserActions(StatusEnum productStatus, Authentication authentication);

    Set<String> getUserActions(ID productId, StatusEnum expectedProductStatus, Authentication authentication);

    Set<String> getMakerActions(StatusEnum productStatus);

    Set<String> getCheckerActions(StatusEnum productStatus);

    Map<UserRoles.RoleType, Set<ProductTypeEnum>> getProductTypeACL(Authentication authentication);

    boolean isActionAllowed(String action, StatusEnum productStatus, Authentication authentication);

    void validateAction(String action, ProductTypeEnum productType, StatusEnum productStatus, Authentication authentication);

    void applyJsonSchema(List<com.hsbc.pdm.entities.ProductVariation> variations, JsonSchemaType schemaType, boolean validate);


}
