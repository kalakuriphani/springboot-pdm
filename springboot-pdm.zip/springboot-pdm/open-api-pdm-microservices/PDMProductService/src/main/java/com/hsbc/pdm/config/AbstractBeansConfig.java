package com.hsbc.pdm.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.openbanking.jsonschema.JsonSchemaProvider;
import com.hsbc.openbanking.jsonschema.ProductDetailsProcessor;
import com.hsbc.openbanking.jsonschema.wrapper.ProductWrapperFactory;
import com.hsbc.pdm.common.CustomObjectMapper;
import com.hsbc.pdm.converter.ProductVariationConverter;
import com.hsbc.pdm.repository.ProductAuditRepository;
import com.hsbc.pdm.repository.dynamo.DynamoProductAuditRepository;
import com.hsbc.pdm.service.*;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

public class AbstractBeansConfig {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractBeansConfig.class);

    @Bean
    public ObjectMapper objectMapper() {
        return CustomObjectMapper.INSTANCE;
    }

    @Bean
    public JsonSchemaProvider jsonSchemaProvider(ObjectMapper objectMapper) {
        JsonSchemaProvider provider = new JsonSchemaProvider();
        provider.setObjectMapper(objectMapper);
        return provider;
    }

    @Bean
    public ProductDetailsProcessor productDetailsProcessor(JsonSchemaProvider jsonSchemaProvider, ProductWrapperFactory productWrapperFactory) {
        ProductDetailsProcessor processor = new ProductDetailsProcessor();
        processor.setJsonSchemaProvider(jsonSchemaProvider);
        processor.setProductWrapperFactory(productWrapperFactory);
        return processor;
    }

    @Bean
    public AuthenticationService authenticationService() {
        return new AuthenticationServiceImpl();
    }

    @Bean
    public UserService userService() {
        return new UserServiceImpl();
    }

    @Bean
    public ProductWrapperFactory productWrapperFactory() {
        return new ProductWrapperFactory();
    }

    @Bean
    public ProductVariationConverter productVariationConverter() {
        return new ProductVariationConverter();
    }

    @Bean
    public ProductWorkflowService productWorkflowService() {
        return new ProductWorkflowServiceImpl();
    }

    @Bean
    public ProductService productService() {
        return new ProductServiceImpl();
    }

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        CloseableHttpClient httpClient = HttpClients.custom()
                .setSSLHostnameVerifier(new NoopHostnameVerifier())
                .build();
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setHttpClient(httpClient);

        return builder.requestFactory(requestFactory).build();
    }

    @Bean
    public ProductAuditRepository productAuditRepository() {
        return new DynamoProductAuditRepository();
    }
}
