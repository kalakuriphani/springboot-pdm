package com.hsbc.pdm.config;

import com.hsbc.pdm.auth.AuthenticatePDMTokenFilter;
import com.hsbc.pdm.auth.AuthorityProvider;
import com.hsbc.pdm.auth.PDMAuthenticationProvider;
import com.hsbc.pdm.auth.PDMAuthorityProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.session.MapSessionRepository;
import org.springframework.session.SessionRepository;
import org.springframework.session.config.annotation.web.http.EnableSpringHttpSession;
import org.springframework.session.web.http.HeaderHttpSessionStrategy;
import org.springframework.web.filter.CorsFilter;

/**
 * Created by 44023148 on 23/01/2017.
 */
@Configuration
@EnableSpringHttpSession
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private PDMAuthenticationProvider authenticationProvider;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        super.configure(http);
        http.exceptionHandling()
                .and().sessionManagement()
                .and().anonymous().disable().authorizeRequests().anyRequest().authenticated()
                .and().cors()
                .and().csrf().disable()
                .addFilterAfter(authenticatePDMTokenFilter(), CorsFilter.class);
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        /**
         * The method super.configure() has not been called here deliberately, otherwise
         * our custom AuthenticationProvider is ignored.
         */
        auth.authenticationProvider(authenticationProvider);
    }

    @Bean
    public AuthenticatePDMTokenFilter authenticatePDMTokenFilter() throws Exception {
        AuthenticatePDMTokenFilter filter = new AuthenticatePDMTokenFilter();
        filter.setAuthenticationManager(authenticationManagerBean());
        return filter;
    }

    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Bean
    public SessionRepository sessionRepository() {
        return new MapSessionRepository();
    }

    @Bean
    public HeaderHttpSessionStrategy httpSessionStrategy() {
        return new HeaderHttpSessionStrategy();
    }

    @Bean
    public AuthorityProvider authorityProvider() {
        return new PDMAuthorityProvider();
    }
}
