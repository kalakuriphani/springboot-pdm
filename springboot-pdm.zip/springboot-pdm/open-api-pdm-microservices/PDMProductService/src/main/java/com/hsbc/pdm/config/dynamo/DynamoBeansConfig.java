package com.hsbc.pdm.config.dynamo;

import com.hsbc.pdm.common.ProductFactory;
import com.hsbc.pdm.common.dynamo.DynamoProductFactory;
import com.hsbc.pdm.config.AbstractBeansConfig;
import com.hsbc.pdm.converter.ProductConverter;
import com.hsbc.pdm.repository.ProductRepository;
import com.hsbc.pdm.repository.dynamo.DynamoProductRepository;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile(value = { "dynamo" })
public class DynamoBeansConfig extends AbstractBeansConfig {

    private static final Logger LOG = LoggerFactory.getLogger(DynamoBeansConfig.class);


    public DynamoBeansConfig() {
        LOG.info("guragats: Initialize DynamoBeansConfig for DynamoDB");
    }

    @Bean
    public ProductConverter productConverter() {
        return new ProductConverter<ObjectId>();
    }

    @Bean
    public ProductRepository productRepository() {
        return new DynamoProductRepository();
    }

    @Bean
    public ProductFactory productFactory() {
        return new DynamoProductFactory();
    }
}
