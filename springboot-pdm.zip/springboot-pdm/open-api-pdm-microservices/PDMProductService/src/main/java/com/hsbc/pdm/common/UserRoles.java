package com.hsbc.pdm.common;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.util.Assert;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by 44023148 on 26/01/2017.
 */
public interface UserRoles {

    String ROLE_INFODIR_OBA_PDM_CMB_MAKER = "INFODIR-OBA-PDM-CMB-MAKER";
    String ROLE_INFODIR_OBA_PDM_CMB_CHECKER = "INFODIR-OBA-PDM-CMB-CHECKER";
    String ROLE_INFODIR_OBA_PDM_RWMB_MAKER = "INFODIR-OBA-PDM-RWMB-MAKER";
    String ROLE_INFODIR_OBA_PDM_RWMB_CHECKER = "INFODIR-OBA-PDM-RWMB-CHECKER";
    String ROLE_INFODIR_OBA_PDM_SME_MAKER = "INFODIR-OBA-PDM-SME-MAKER";
    String ROLE_INFODIR_OBA_PDM_SME_CHECKER = "INFODIR-OBA-PDM-SME-CHECKER";
    String ROLE_INFODIR_OBA_PDM_FD_MAKER = "INFODIR-OBA-PDM-FD-MAKER"; // First Direct
    String ROLE_INFODIR_OBA_PDM_FD_CHECKER = "INFODIR-OBA-PDM-FD-CHECKER"; // First Direct
    String ROLE_INFODIR_OBA_PDM_MANDS_MAKER = "INFODIR-OBA-PDM-MANDS-MAKER"; // Marks & Spencer
    String ROLE_INFODIR_OBA_PDM_MANDS_CHECKER = "INFODIR-OBA-PDM-MANDS-CHECKER"; // Marks & Spencer
    String ROLE_INFODIR_OBA_PDM_CMB_CCC_MAKER = "INFODIR-OBA-PDM-CMB-CCC-MAKER";
    String ROLE_INFODIR_OBA_PDM_CMB_CCC_CHECKER = "INFODIR-OBA-PDM-CMB-CCC-CHECKER";

    List<GrantedAuthority> AUTHORITIES = new ArrayList<>();

    enum RoleType {

        MAKER_ROLES(
                ROLE_INFODIR_OBA_PDM_CMB_MAKER,
                ROLE_INFODIR_OBA_PDM_RWMB_MAKER,
                ROLE_INFODIR_OBA_PDM_SME_MAKER,
                ROLE_INFODIR_OBA_PDM_FD_MAKER,
                ROLE_INFODIR_OBA_PDM_MANDS_MAKER,
                ROLE_INFODIR_OBA_PDM_CMB_CCC_MAKER),

        CHECKER_ROLES(
                ROLE_INFODIR_OBA_PDM_CMB_CHECKER,
                ROLE_INFODIR_OBA_PDM_RWMB_CHECKER,
                ROLE_INFODIR_OBA_PDM_SME_CHECKER,
                ROLE_INFODIR_OBA_PDM_FD_CHECKER,
                ROLE_INFODIR_OBA_PDM_MANDS_CHECKER,
                ROLE_INFODIR_OBA_PDM_CMB_CCC_CHECKER);


        private final Set<String> roles = new HashSet<>();


        RoleType(String... roles) {
            Assert.notEmpty(roles, "Roles cannot be empty");
            Assert.noNullElements(roles, "Roles cannot have null elements");
            for (String role : roles) {
                this.roles.add(role.toUpperCase());
            }
        }

        public Set<String> getRoles() {
            return new HashSet<>(roles);
        }

        public boolean containsRole(String role) {
            Assert.notNull(role, "Role cannot be null");
            Assert.hasText(role, "Role cannot be empty");
            return roles.contains(role.toUpperCase());
        }

        public boolean containsAnyOf(Collection<String> roles) {
            for (String role : roles) {
                if (containsRole(role)) {
                    return true;
                }
            }
            return false;
        }

        static {
            AUTHORITIES.addAll(RoleType.MAKER_ROLES.getRoles().stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList()));
            AUTHORITIES.addAll(RoleType.CHECKER_ROLES.getRoles().stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList()));
        }
    }
}
