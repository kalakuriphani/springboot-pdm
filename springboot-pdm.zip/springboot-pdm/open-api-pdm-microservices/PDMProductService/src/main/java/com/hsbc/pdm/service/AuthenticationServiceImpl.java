package com.hsbc.pdm.service;

import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * Created by 44023148 on 26/01/2017.
 */
public class AuthenticationServiceImpl implements AuthenticationService {

    @Override
    public Authentication getCurrentAuthentication() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (!authentication.isAuthenticated()) { // normally should never happen
            throw new AuthenticationServiceException(String.format("User %s is not authenticated", authentication.getName()));
        }
        return authentication;
    }
}
