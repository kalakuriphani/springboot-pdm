package com.hsbc.pdm.service;

import org.springframework.security.core.Authentication;

import java.util.Set;

/**
 * Created by 44023148 on 26/01/2017.
 */
public interface UserService {

    boolean isInRole(Authentication authentication, String role);

    Set<String> getRoles(Authentication authentication);

    boolean isMaker(Authentication authentication);

    boolean isChecker(Authentication authentication);
}
