package com.hsbc.pdm.common.mongo;

import com.hsbc.pdm.common.ProductFactory;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.entities.Product;
import com.hsbc.pdm.entities.mongo.MongoProduct;
import org.bson.types.ObjectId;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

/**
 * Created by 44023148 on 03/02/2017.
 */
@Component
@Profile(value = { "!dynamo", "mongo" })
public class MongoProductFactory implements ProductFactory<ObjectId> {

    @Override
    public Product<ObjectId> create() {
        return new MongoProduct();
    }

    @Override
    public ObjectId createId(String id, ProductTypeEnum productType) {
        return new ObjectId(id);
    }

    @Override
    public ObjectId createId(String id) {
        return new ObjectId(id);
    }

    @Override
    public ObjectId createId() {
        return ObjectId.get();
    }

    @Override
    public String getLocation(ProductTypeEnum productType, String productVersion, StatusEnum productStatus, ObjectId id) {
        return String.format("/%s/%s/%s/%s", productType.name(), productVersion, productStatus.name(), id.toHexString());
    }
}
