package com.hsbc.pdm.common;

public class PreconditionFailedException extends PDMException {

    public PreconditionFailedException(String message) {
        super(message);
    }
}
