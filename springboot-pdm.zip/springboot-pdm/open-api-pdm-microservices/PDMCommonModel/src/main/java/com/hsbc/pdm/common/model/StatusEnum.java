package com.hsbc.pdm.common.model;

public enum StatusEnum {

    DRAFT,
    SUBMITTED_FOR_APPROVAL,
    SUBMITTED_FOR_DELETION,
    APPROVED,
    PUBLISHED, // to Dynamo DB
    SUSPENDED, // hard delete from from Dynamo DB
    DELETED // hard delete from Dynamo DB, soft delete in Mongo DB

}
