package com.hsbc.pdm.common.model;

public enum ProductTypeEnum {

    PCAHSBC("PCA"),
    PCAMNS("PCA"),
    PCAFD("PCA"),
    BCA("BCA"),
    SMEL("SME"),
    CCC("CCC");

    private final String externalName;

    ProductTypeEnum(String externalName) {
        this.externalName = externalName;
    }

    public String getExternalName() {
        return externalName;
    }
}
