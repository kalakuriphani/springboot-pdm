package com.hsbc.pdm.common.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class ProductDetails extends LinkedHashMap<String, Object> {

    /**
     * All the logic to deal with product's internals
     * has been moved into ProductWrapper class.
     */

    public ProductDetails() {

    }

    public ProductDetails(Map<String, Object> map) {
        super(map);
    }
}
