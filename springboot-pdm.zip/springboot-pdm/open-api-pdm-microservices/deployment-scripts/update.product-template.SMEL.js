var PRODUCT_TEMPLATE_ID = '5836e070abd40fb7e9c68e3b';

var schema = {
        "type": "object",
        "title": "Root",
        "description": "An instance of an SME Lending product",
        "widget":"tabs-widget",
        "properties": {
            "core": {
                "title": "Core",
                "type": "object",
                "properties": {
                    "organisationIdentifier": {
                        "type": "string",
                        "maxLength": 100,
                        "title": "Organisation Identifier",
                        "description": "Could be banking license number / reference"

                    },
                    "productName": {
                        "type": "string",
                        "maxLength": 100,
                        "title": "Product Name",
                        "description": "The short product or marketing name assigned by the parent Organisation"
                    },
                    "productTypeName": {
                        "type": "string",
                        "title": "Product Type Name",
                        "widget": "select",
                        "default":"SMEL",
                        "oneOf": [
                            {
                                "description": "SME Lending",
                                "enum": [
                                    "SMELending"
                                ]
                            },
                            {
                                "description": "SME Unsecured Loan",
                                "enum": [
                                    "SMEUnsecuredLoan"
                                ]
                            }
                        ],
                        "description": "Product type"
                    },
                    "productSegment": {
                        "type": "string",
                        "title": "Product Segment",
                        "description": "Marketing or industry segment that the product is applicable for",
                        "widget": "select",
                        "oneOf": [
                            {
                                "description": "Corporate",
                                "enum": [
                                    "Corporate"
                                ]
                            },
                            {
                                "description": "Business",
                                "enum": [
                                    "Business"
                                ]
                            }
                        ],
                        "default": "Business"
                    },
                    "productDescription": {
                        "type": "string",
                        "maxLength": 100,
                        "title": "Product Description",
                        "description": "Description of the product provided by the parent Organisation"
                    },
                    "tAndCs": {
                        "type": "string",
                        "maxLength": 200,
                        "title": "T&Cs",
                        "description": "URL provided by the parent organisation which redirects to the T&Cs"
                    },
                    "productUrl": {
                        "type": "string",
                        "maxLength": 200,
                        "title": "Product URL",
                        "description": "URL provided by the parent organisation which redirects to the product information pages"
                    },
                    "managementAccessChannels": {
                        "type": "array",
                        "title": "Management Access Channels",
                        "description": "Ways to interact with the bank.",
                        "items": {
                            "type": "boolean",
                            "enum": [
                                "Branch",
                                "Post",
                                "Internet",
                                "Phone",
                                "Smartphone"
                            ]
                        }
                    },
                    "currency": {
                        "type": "string",
                        "title": "Currency",
                        "description": "Currency of the Account",
                        "widget": "select",
                        "oneOf": [
                            {
                                "description": "Sterling",
                                "enum": [
                                    "GBP"
                                ]
                            },
                            {
                                "description": "US Dollar",
                                "enum": [
                                    "USD"
                                ]
                            },
                            {
                                "description": "Euro",
                                "enum": [
                                    "EUR"
                                ]
                            }
                        ],
                        "default": "GBP"
                    }
                }
            },
            "loan": {
                "title": "Loan",
                "type": "object",
                "properties": {
                    "minimumLoanTerm": {
                        "type": "integer",
                        "multipleOf": 1,
                        "maximum": 10000,
                        "minimum": 1,
                        "title": "Minimum loan term (Days)",
                        "description": "Minimum loan term (Days)"
                    },
                    "maximumLoanTerm": {
                        "type": "integer",
                        "multipleOf": 1,
                        "maximum": 10000,
                        "minimum": 1,
                        "title": "Maximum loan term (Days)",
                        "description": "Maximum loan term (Days)"
                    },
                    "minimumLoanAmount": {
                        "type": "number",
                        "multipleOf": 0.01,
                        "minimum": 0,
                        "maximum": 999999999,
                        "title": "Minimum Loan Amount",
                        "description": "Minimum loan amount"
                    },
                    "maximumLoanAmount": {
                        "type": "number",
                        "multipleOf": 0.01,
                        "minimum": 0,
                        "maximum": 999999999,
                        "title": "Maximum loan amount",
                        "description": "Maximum loan amount"
                    },
                    "repaymentType": {
                        "type": "string",
                        "title": "Repayment Type",
                        "description": "Repayment frequency",
                        "widget": "select",
                        "default":"Monthly",
                        "oneOf": [{
                            "description": "Daily",
                            "enum": ["Daily"]
                        }, {
                            "description": "Weekly",
                            "enum": ["Weekly"]
                        }, {
                            "description": "Monthly",
                            "enum": ["Monthly"]
                        }, {
                            "description": "Yearly",
                            "enum": ["Yearly"]
                        }, {
                            "description": "Flexible",
                            "enum": ["Flexible"]
                        }]
                    },
                    "paymentHolidayFlag": {
                        "type": "boolean",
                        "title": "Payment Holiday Flag",
                        "description": "Indicates if a payment holiday is allowed",
                        "default": true
                    }
                }
            },
            "rate": {
                "title": "Rate",
                "type": "array",
                "items": [{
                    "type": "object",
                    "title": "Rate Entry",
                    "required": ["interestRateType", "rate", "rateComparisonType"],
                    "properties": {
                        "interestRateType": {
                            "title": "Interest Rate Type",
                            "type": "array",
                            "description": "Description of what this interest rate applies to",
                            "items": [{
                                "type":"string",
                                "enum": [
                                    "Interest only",
                                    "Repayment annuity style fully amortising",
                                    "Repayment with a bullet",
                                    "Custom schedule",
                                    "Fixed capital fully amortising",
                                    "Fixed capital with a bullet"
                                ]
                            }]
                        },
                        "tierLower": {
                            "type": "number",
                            "title": "Tier Lower",
                            "description": "Defines the lower limit of the tier",
                            "minimum": 0,
                            "maximum": 999999999,
                            "multipleOf": 0.01
                        },
                        "tierHigher": {
                            "type": "number",
                            "title": "Tier Higher",
                            "description": "Defines the upper limit of the tier",
                            "minimum": 0,
                            "maximum": 999999999,
                            "multipleOf": 0.01
                        },
                        "appliedTo": {
                            "type": "string",
                            "title": "Applied To",
                            "description": "Indicates what portion of the balance this rate is applied to",
                            "widget": "select",
                            "default":"Portion",
                            "oneOf": [{
                                "description": "Full Balance",
                                "enum": ["Full_Balance"]
                            }, {
                                "description": "Portion",
                                "enum": ["Portion"]
                            }]
                        },
                        "rate": {
                            "type": "number",
                            "title": "Rate",
                            "description": "Rate amount being charged"
                        },
                        "rateComparisonType": {
                            "type": "string",
                            "description": "Rate chargin period for comparison",
                            "title": "Rate Comparison Type",
                            "widget": "select",
                            "default":"APR",
                            "oneOf": [{
                                "description": "Annual Equivalent Rate",
                                "enum": ["AER"]
                            }, {
                                "description": "Annual Percentage Rate",
                                "enum": ["APR"]
                            }]
                        }
                    }
                }]
            },
            "availability": {
                "title": "Availability",
                "type": "object",
                "properties": {
                    "validFrom": {
                        "type": "string",
                        "format": "date",
                        "title": "Valid From",
                        "description": "The date from which this specification is valid"
                    },
                    "validTo": {
                        "type": "string",
                        "format": "date",
                        "title": "Valid To",
                        "description": "The date until which this specification is valid"
                    }
                }
            },
            "product": {
                "type": "object",
                "title": "Product",
                "properties": {
                    "fcaRegulated": {
                        "type": "boolean",
                        "title": "FCA Regulated",
                        "description": "Is the loan is FCA regulated"
                    },
                    "lowInterestRepaymentStartPossible": {
                        "type": "boolean",
                        "title": "Low interest repayment start possible",
                        "description": "Is a lower interest repayment start possible"
                    },
                    "interestOnly": {
                        "type": "boolean",
                        "title": "Interest Only",
                        "description": "Is this an interest only loan"
                    },
                    "capitalRepaymentHolidays": {
                        "type": "boolean",
                        "title": "Capital Rayment Holidays",
                        "description": "Is a capital repayment holiday possible"
                    },
                    "trancheDrawdown": {
                        "type": "boolean",
                        "title": "Tranch Drawdown",
                        "description": "Is the loan paid out to a pre-arranged schedule"
                    },
                    "negociable": {
                        "type": "boolean",
                        "title": "Negociable",
                        "description": "Indicates that the stated terms are negociable"
                    },
                    "productSubType": {
                        "type": "string",
                        "title": "Product Sub Type",
                        "widget": "select",
                        "default":"Regular",
                        "oneOf": [{
                            "description": "Promotional",
                            "enum": ["Promotional"]
                        }, {
                            "description": "Regular",
                            "enum": ["Regular"]
                        }, {
                            "description": "Future Regular terms",
                            "enum": ["Future Regular terms"]
                        }]
                    },
                    "startPromotionOrFutureTerms": {
                        "title": "Start Promotion or Future terms",
                        "description": "",
                        "type": "string",
                        "format": "date"
                    },
                    "stopPromotionOrFutureTerms": {
                        "title": "Stop Promotion or Future terms",
                        "description": "",
                        "type": "string",
                        "format": "date"
                    },
                    "lengthPromotional": {
                        "title": "Length Promotional",
                        "description": "",
                        "type": "number"
                    },
                    "dateOfChange": {
                        "title": "Date of Change",
                        "description": "Date of Change (if known)",
                        "type": "string",
                        "format": "date"
                    },
                    "loanSizeIncrements": {
                        "title": "Loan size increments",
                        "description": "",
                        "widget": "select",
                        "type": "string",
                        "oneOf": [{
                            "description": "5,000",
                            "enum": ["5000"]
                        }, {
                            "description": "10,000",
                            "enum": ["10000"]
                        }, {
                            "description": "15,000",
                            "enum": ["15000"]
                        }, {
                            "description": "20,000",
                            "enum": ["20000"]
                        }, {
                            "description": "25,000",
                            "enum": ["25000"]
                        }]
                    },
                    "loanLengthIncrements": {
                        "title": "Loan length increments in years",
                        "description": "",
                        "type": "string",
                        "oneOf": [{
                            "description": "1 year",
                            "enum": ["1"]
                        }, {
                            "description": "2 year",
                            "enum": ["2"]
                        }, {
                            "description": "3 year",
                            "enum": ["3"]
                        }, {
                            "description": "4 year",
                            "enum": ["4"]
                        }, {
                            "description": "5 year",
                            "enum": ["5"]
                        }]
                    }
                },
                "required": [
                    "fcaRegulated",
                    "lowInterestRepaymentStartPossible",
                    "interestOnly",
                    "capitalRepaymentHolidays",
                    "trancheDrawdown",
                    "negociable",
                    "productSubType"
                ],
            },
            "eligibility": {
                "type": "array",
                "uniqueItems": false,
                "title": "Eligibility",
                "description": "Eligibility description",
                "items": {
                    "type": "object",
                    "title": "Eligibility",
                    "description": "",
                    "properties": {
                        "ageRestricted": {
                            "type": "boolean",
                            "title": "Age Restricted",
                            "description": "Age restricted"
                        },
                        "minimumAge": {
                            "type": "number",
                            "title": "Minimum Age",
                            "description": "Minimum age"
                        },
                        "otherFinancialHolding": {
                            "type": "boolean",
                            "minLength": 1,
                            "title": "Other Financial Holding",
                            "description": "Other financial holding required"
                        },
                        "fullDescription": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 256,
                            "title": "Full Description",
                            "description": "Full description"
                        },
                        "incomeRelated": {
                            "type": "boolean",
                            "minLength": 1,
                            "title": "Income Related",
                            "description": "Income related"
                        },
                        "singleJoinIncome": {
                            "type": "string",
                            "minLength": 0,
                            "maxLength": 256,
                            "title": "Single/Join Income",
                            "description": "Single or join income"
                        },
                        "minimumIncome": {
                            "type": "number",
                            "title": "Minimum Income",
                            "description": "Minimum income amount"
                        },
                        "minimumIncomeCurrency": {
                            "type": "string",
                            "minLength": 3,
                            "title": "Currency",
                            "description": "short description",
                            "default": "GBP",
                            "widget": "select",
                            "oneOf": [{
                                "enum": [
                                    "GBP"
                                ],
                                "description": "GBP"
                            }, {
                                "enum": [
                                    "EUR"
                                ],
                                "description": "EUR"
                            }, {
                                "enum": [
                                    "USD"
                                ],
                                "description": "USD"
                            }]
                        },
                        "minimumIncomeTimePeriod": {
                            "type": "string",
                            "title": "Minimum Income Time Period",
                            "description": "Minimum income time period",
                            "widget": "select",
                            "default":"TimePeriod2",
                            "oneOf": [{
                                "enum": [
                                    "TimePeriod2"
                                ],
                                "description": "TimePeriod2"
                            }]
                        },
                        "waysMinIncomePaidIn": {
                            "type": "string",
                            "minLength": 0,
                            "maxLength": 50,
                            "title": "Ways Minimum Income Paid In",
                            "description": "Ways minimum income paid In"
                        },
                        "minIncomePaidAccountMonth": {
                            "type": "number",
                            "title": "Minimum Income Paid into Account/Month",
                            "description": "Minimum income paid into Account/Month"
                        },
                        "annualCompanyTurnover": {
                            "type": "number",
                            "title": "Annual Company Turnover",
                            "description": "Annual company turnover"
                        },
                        "annualCompanyTurnoverCurrency": {
                            "type": "string",
                            "title": "Annual Company Turnover Currency",
                            "description": "Annual company turnover currency",
                            "default": "AnnualType1",
                            "widget": "select",
                            "oneOf": [{
                                "enum": [
                                    "AnnualType1"
                                ],
                                "description": "AnnualType1"
                            }]
                        },
                        "residencyRestricted": {
                            "type": "boolean",
                            "title": "Residency Restricted",
                            "description": "Residency restricted"
                        },
                        "residencyRegion": {
                            "type": "string",
                            "title": "Residency Region",
                            "description": "Residency Region",
                            "default": "UK",
                            "widget": "select",
                            "oneOf": [{
                                "enum": [
                                    "UK"
                                ],
                                "description": "UK"
                            }]
                        },
                        "maxNoOfAccounts": {
                            "type": "number",
                            "title": "Maximum Number of Accounts",
                            "description": "Maximum number of accounts"
                        },
                        "ThirdSectorOrganisations": {
                            "type": "string",
                            "minLength": 0,
                            "maxLength": 50,
                            "title": "Third Sector Organisations",
                            "description": "Third sector organisations"
                        },
                        "openingDepositMinAmount": {
                            "type": "number",
                            "title": "Opening Deposit Minimum Amount",
                            "description": "Opening deposit minimum amount"
                        },
                        "openingDepositMinCurrency": {
                            "type": "string",
                            "title": "Opening Deposit Minimum Currency",
                            "description": "Opening Deposit Minimum Currency",
                            "default": "GBP",
                            "minLength": 3,
                            "widget": "select",
                            "oneOf": [{
                                "enum": [
                                    "GBP"
                                ],
                                "description": "GBP"
                            }, {
                                "enum": [
                                    "EUR"
                                ],
                                "description": "EUR"
                            }, {
                                "enum": [
                                    "USD"
                                ],
                                "description": "USD"
                            }]
                        },
                        "maxOpeningAmount": {
                            "type": "boolean",
                            "minLength": 1,
                            "title": "Maximum Opening Amount",
                            "description": "Maximum Opening Amount"
                        },
                        "eligibilityName": {
                            "type": "string",
                            "minLength": 0,
                            "maxLength": 50,
                            "title": "Eligibility Name",
                            "description": "Eligibility Name"
                        },
                        "eligibilityType": {
                            "type": "string",
                            "minLength": 0,
                            "maxLength": 50,
                            "title": "Eligibility Type",
                            "description": "Eligibility Type"
                        },
                        "noValue": {
                            "type": "boolean",
                            "minLength": 1,
                            "title": "No Value",
                            "description": "No Value"
                        },
                        "eligibilityNotes": {
                            "type": "string",
                            "minLength": 0,
                            "maxLength": 256,
                            "title": "Eligibility Notes",
                            "description": "Eligibility notes"
                        },
                        "previousBancruptcy": {
                            "type": "boolean",
                            "minLength": 1,
                            "title": "Previous Bancruptcy",
                            "description": "Previous Bancruptcy"
                        }
                    },
                    "required": [
                        "ageRestricted",
                        "otherFinancialHolding",
                        "fullDescription",
                        "incomeRelated",
                        "residencyRestricted",
                        "openingDepositMinAmount",
                        "openingDepositMinCurrency",
                        "previousBancruptcy"
                    ]
                }
            },
            "feature": {
                "type": "array",
                "uniqueItems": false,
                "title": "Feature",
                "description": "An explanation about the purpose of this instance.",
                "items": {
                    "type": "object",
                    "title": "",
                    "description": "An explanation about the purpose of this instance.",
                    "properties": {
                        "name": {
                            "type": "string",
                            "minLength": 1,
                            "title": "Name",
                            "description": "An explanation about the purpose of this instance.",
                            "default": ""
                        },
                        "type": {
                            "type": "string",
                            "minLength": 1,
                            "title": "Type",
                            "description": "An explanation about the purpose of this instance.",
                            "enum": ["Statements online", "Overdraft"],
                            "default": ""
                        },
                        "optionalIndicator": {
                            "type": "boolean",
                            "title": "Optional Indicator",
                            "description": "An explanation about the purpose of this instance.",
                            "default": true
                        },
                        "notes": {
                            "type": "string",
                            "minLength": 1,
                            "title": "Notes",
                            "description": "An explanation about the purpose of this instance.",
                            "default": ""
                        }
                    },
                    "required": [
                        "name",
                        "type",
                        "optionalIndicator",
                        "notes"
                    ]
                }
            },
            "fee": {
                "type": "array",
                "uniqueItems": false,
                "title": "Fee",
                "description": "short description",
                "items": {
                    "type": "object",
                    "title": "",
                    "description": "",
                    "properties": {
                        "feeType": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 50,
                            "title": "Type",
                            "description": "short description",
                            "default": "Paper statements",
                            "widget": "select",
                            "oneOf": [{
                                "enum": [
                                    "Paper statements"
                                ],
                                "description": "Paper statements"
                            }, {
                                "enum": [
                                    "etc"
                                ],
                                "description": "etc"
                            }]
                        },
                        "frequency": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 30,
                            "title": "Frequency",
                            "description": "short description"
                        },
                        "feeAmount": {
                            "type": "number",
                            "minimum": 0,
                            "title": "Amount",
                            "description": "short description"
                        },
                        "feeRate": {
                            "type": "number",
                            "minimum": 0,
                            "title": "Lower Tier",
                            "description": "short description"
                        },
                        "lowerTier": {
                            "type": "number",
                            "minimum": 0,
                            "title": "Lower Tier",
                            "description": "short description"
                        },
                        "higherTier": {
                            "type": "number",
                            "minimum": 0,
                            "title": "Higher Tier",
                            "description": "short description"
                        },
                        "feesAndChargesNotes": {
                            "type": "string",
                            "minLength": 0,
                            "title": "Higher Tier",
                            "description": "short description"
                        }
                    },
                    "required": [
                        "feeType",
                        "frequency",
                        "feeAmount",
                        "feeRate"
                    ]
                }
            }
        },

        "required": [
            "core",
            "loan",
            "rate",
            "availability",
            "product",
            "fee",
            "eligibility",
            "feature"
        ],
        "fieldsets": [
            {
                "fields": [
                    "core"
                ],
                "title": "Core"
            },
            {
                "fields": [
                    "loan"
                ],
                "title": "Loan"
            },
            {
                "fields": [
                    "rate"
                ],
                "title": "Rate"
            },
            {
                "fields": [
                    "availability"
                ],
                "title": "Availability"
            },
            {
                "fields": [
                    "product"
                ],
                "title": "Product"
            },
            {
                "fields": [
                    "eligibility"
                ],
                "title": "Eligibility"
            },
            {
                "fields": [
                    "feature"
                ],
                "title": "Feature"
            },
            {
                "fields": [
                    "fee"
                ],
                "title": "Fee"
            }
        ]
    };

var query = { 
	_id: ObjectId(PRODUCT_TEMPLATE_ID) 
};

var values = { 
	$inc : { version: 1 },
	$set : { schema: schema }
};

db.productTemplate.update(query, values);

print('success');
