var PRODUCT_TEMPLATE_ID = '582c57a1a7b1bf48c6bc0680';

var productTemplate = {
	"_id": ObjectId(PRODUCT_TEMPLATE_ID),
	"title": "Person Current Account (Marks & Spencers)",
	"type": "PCAMNS",
	"createdAt": new Date(),
	"createdBy": "dev-ops-team",
	"status": "ACTIVE",
	"schema" : {},
	"version": 1
};
db.productTemplate.save(productTemplate);

print('success');