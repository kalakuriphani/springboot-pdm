# Deployment Scripts for PDM

## Usage

The following script must be run from the shell:

    mongo localhost:27017/pdm create.product-template.PCA-HSBC.js
    mongo localhost:27017/pdm create.product-template.PCA-FD.js
    mongo localhost:27017/pdm create.product-template.PCA-MNS.js
    mongo localhost:27017/pdm update.product-template.PCA.js

    mongo localhost:27017/pdm create.product-template.SMEL.js
    mongo localhost:27017/pdm update.product-template.SMEL.js

    mongo localhost:27017/pdm create.product-template.BCA.js
    mongo localhost:27017/pdm update.product-template.BCA.js
