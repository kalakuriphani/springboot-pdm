var PRODUCT_TEMPLATE_ID = '582c57a1a7b1bf48c6bc04d2';
var schema =
{
    "documentVersion": "1.0.0",
    "type": "object",
    "title": "Root",
    "widget": "tabs-widget",
    "description": "Business Current Account",
    "properties": {
        "organisation": {
            "type": "object",
            "title": "Organisation",
            "description": "",
            "properties": {
                "parentGroupName": {
                    "type": "string",
                    "minLength": 1,
                    "title": "Parent Group Name",
                    "description": "Name of the Parent Description",
                    "default": "HSBC Group UK"
                },
                "brandName": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 350,
                    "title": "Brand Name",
                    "description": "Name by which Organisation is known"
                },
                "brandId": {
                    "type": "string",
                    "minLength": 1,
                    "title": "Brand ID",
                    "description": "Unique and unambigous way to identify"
                }
            },
            "required": [
                "parentGroupName",
                "brandName",
                "brandId"
            ]
        },
        "product": {
            "type": "object",
            "title": "Product",
            "description": "",
            "properties": {
                "productType": {
                    "type": "string",
                    "title": "Product Type",
                    "description": "Product type",
                    "default": "BCA",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "BCA"
                            ],
                            "description": "Personal Current Account"
                        }
                    ]
                },
                "productName": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 50,
                    "title": "Product Name",
                    "description": "The name of the product used for marketing purposes from customer perspective"
                },
                "productSegment": {
                    "type": "string",
                    "title": "Product Segment",
                    "description": "Marketing or industry segment that the product is designed for",
                    "default": "Student",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "Student",
                                "Graduate"
                            ],
                            "description": "Student"
                        },
                        {
                            "enum": [
                                "Graduate"
                            ],
                            "description": "Graduate"
                        },
                        {
                            "enum": [
                                "Child"
                            ],
                            "description": "Child"
                        },
                        {
                            "enum": [
                                "Package"
                            ],
                            "description": "Package"
                        },
                        {
                            "enum": [
                                "Basic"
                            ],
                            "description": "Basic"
                        },
                        {
                            "enum": [
                                "General"
                            ],
                            "description": "General"
                        },
                        {
                            "enum": [
                                "Business"
                            ],
                            "description": "Business"
                        },
                        {
                            "enum": [
                                "Youth"
                            ],
                            "description": "Youth"
                        }
                    ]
                },
                "productIdentifier": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 40,
                    "title": "Product Identifier",
                    "description": "Identifer within the parent organsation for the product. Must be unique in the organisation."
                },
                "productDescription": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 256,
                    "title": "Product Description",
                    "description": "Description of the product provided by the parent organisation."
                },
                "ATMLimit": {
                    "type": "number",
                    "title": "ATM Limit",
                    "description": "The daily limit that a customer can get via the ATM."
                },
                "tAndCs": {
                    "type": "array",
                    "title": "T&Cs",
                    "description": "URL provided by the parent organisation which redirects to current T&C's",
                    "items": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 256
                    }
                },
                "accessChannels": {
                    "type": "string",
                    "widget": "select",
                    "title": "Access Channels",
                    "description": "Ways to interact with the bank",
                    "default": "Text",
                    "oneOf": [
                        {
                            "enum": [
                                "Branch"
                            ],
                            "description": "Branch"
                        },
                        {
                            "enum": [
                                "Post"
                            ],
                            "description": "Post"
                        },
                        {
                            "enum": [
                                "Internet"
                            ],
                            "description": "Internet"
                        },
                        {
                            "enum": [
                                "Phone"
                            ],
                            "description": "Phone"
                        },
                        {
                            "enum": [
                                "Smartphone"
                            ],
                            "description": "Smartphone"
                        },
                        {
                            "enum": [
                                "Text"
                            ],
                            "description": "Text"
                        }
                    ]
                },
                "cardType": {
                    "type": "string",
                    "title": "Card Type",
                    "description": "Card Type available",
                    "default": "Cashcard",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "Cashcard"
                            ],
                            "description": "Cashcard"
                        },
                        {
                            "enum": [
                                "Debit Visa"
                            ],
                            "description": "Debit Visa"
                        },
                        {
                            "enum": [
                                "Debit Matercard"
                            ],
                            "description": "Debit Matercard"
                        }
                    ]
                },
                "contactless": {
                    "type": "boolean",
                    "title": "Contactless",
                    "default": false,
                    "description": "Does the card issued have contactless facility"
                },
                "mobileWallet": {
                    "type": "string",
                    "title": "Mobile Wallet",
                    "widget": "select",
                    "default":"Apple Pay",
                    "description": "Mobile Vallet products",
                    "oneOf": [
                        {
                            "enum": [
                                "Apple Pay"
                            ],
                            "description": "Apple Pay"
                        },
                        {
                            "enum": [
                                "Android Pay"
                            ],
                            "description": "Android Pay"
                        },
                        {
                            "enum": [
                                "Samsung Pay"
                            ],
                            "description": "Samsung Pay"
                        },
                        {
                            "enum": [
                                "Vodophone Pay"
                            ],
                            "description": "Vodophone Pay"
                        },
                        {
                            "enum": [
                                "Issuer Mobile App"
                            ],
                            "description": "Issuer Mobile App"
                        }
                    ]
                },
                "cardNotes": {
                    "type": "array",
                    "title": "Card Notes",
                    "description": "Optional additional notes to supplement the card details",
                    "items": {
                        "type": "string",
                        "minLength": 0,
                        "maxLength": 256

                    }
                },
                "chequebookAvailable": {
                    "type": "boolean",
                    "title": "Cheque Book Available",
                    "default": false,
                    "description": "Can a chequebook be issued"
                },
                "creditScoringAccount": {
                    "type": "boolean",
                    "title": "Credit Score Open Account",
                    "description": "Credit scoring part for opening an account",
                    "default": false
                },
                "creditScoringType": {
                    "type": "string",
                    "title": "Credit Score Open Account",
                    "description": "Credit scoring part for opening an account",
                    "widget": "select",
                    "default":"Hard",
                    "oneOf": [
                        {
                            "enum": [
                                "Hard"
                            ],
                            "description": "Hard"
                        },
                        {
                            "enum": [
                                "Soft"
                            ],
                            "description": "Soft"
                        }
                    ]
                },
                "creditScoringDetails": {
                    "type": "string",
                    "minLength": 0,
                    "maxLength": 256,
                    "title": "Credit Scoring Details",
                    "description": "Details on the specific credit scoring"
                },
                "creditScoringIdVerification": {
                    "type": "boolean",
                    "title": "Credit Score Open Account",
                    "description": "Credit scoring part of account opening for ID verification",
                    "default": false
                },
                "maximumMonthlyCharge": {
                    "type": "number",
                    "minimum": 0,
                    "title": "Maximum Monthly Charge",
                    "description": "The maximum amount of administrative costs fro overdrafts the customer can occur on a monthly base."
                },
                "productUrl": {
                    "type": "array",
                    "title": "Product URL",
                    "description": "Url provided by the organisation which redirects to the product.",
                    "items": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 256
                    }
                },
                "currency": {
                    "type": "string",
                    "title": "Currency",
                    "description": "Currency",
                    "default": "GBP",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "GBP"
                            ],
                            "description": "GBP"
                        }
                    ]
                }
            },
            "required": [
                "productType",
                "productName",
                "productSegment",
                "productIdentifier",
                "productDescription",
                "tAndCs",
                "ATMLimit",
                "accessChannels",
                "cardType",
                "contactless",
                "chequebookAvailable",
                "creditScoringAccount",
                "creditScoringIdVerification",
                "productUrl",
                "currency"
            ]
        },
        "card": {
            "type": "object",
            "title": "Product",
            "description": "",
            "properties": {
                "paymentSchemeExchangeRate": {
                    "type": "number",
                    "minimum": 1,
                    "title": "Payment Schema Exchange Rate",
                    "description": "The base exchnage rate used in settlement of the traction between issuer and scheme"
                },
                "exchangeRateAdjustment": {
                    "type": "number",
                    "minimum": 1,
                    "title": "Exchange Rate Adjustment",
                    "description": "The margin added, by certain card issuers, to the schme rate in order to arrive at the exchange rate quoted as the reference exchange rate"
                },
                "paymentSchemeExchangeFeeRate": {
                    "type": "array",
                    "title": "Payment scheme Exchange Fee",
                    "description": "Any payment network fee rate applied to some or all non-sterling transactions",
                    "items": {
                        "type": "number",
                        "minimum": 0
                    }
                },
                "nonSterlingTransactionFee": {
                    "type": "array",
                    "title": "Non Sterling Transaction Fee",
                    "description": "A fee applied to all non-sterling card transactions",
                    "items": {
                        "type": "number",
                        "minimum": 0

                    }
                },
                "nonSterlingTransactionfeeRate": {
                    "type": "array",
                    "title": "Non Sterling Transaction Fee Rate",
                    "description": "A fee rate applied to all non-sterling card transactions",
                    "items": {
                        "type": "number",
                        "minimum": 0

                    }
                },
                "nonSterlingPurchaseFee": {
                    "type": "array",
                    "title": "Non Sterling purchase fee",
                    "description": "Retail Transactions",
                    "items": {
                        "type": "number",
                        "minimum": 0

                    }
                },
                "nonSterlingPurchaseFeeRate": {
                    "type": "array",
                    "title": "Non Sterling Purchase Fee Rate",
                    "description": "An additional fee applied to certain purchases",
                    "items": {
                        "type": "number",
                        "minimum": 0

                    }
                },
                "nonSterlingCashFee": {
                    "type": "array",
                    "title": "Non Sterling Cash Fee",
                    "description": "An additional fee applied to certain card",
                    "items": {
                        "type": "number",
                        "minimum": 0
                    }
                },
                "nonSterlingCashFeeRate": {
                    "type": "array",
                    "title": "Non Sterling Cash Fee Rate",
                    "description": "A fee rate applied to all non-sterling card transactions",
                    "items": {
                        "type": "number",
                        "minimum": 0

                    }
                },
                "foreignPurchaseFee": {
                    "type": "array",
                    "title": "Foreign Purchase fee",
                    "description": "Additional card fee applied to sterling retail transactions made abroad.",
                    "items": {
                        "type": "number",
                        "minimum": 0
                    }
                },
                "foreignPurchaseFeeRate": {
                    "type": "array",
                    "title": "Foreign purchase Fee Rate",
                    "description": "Additional card  fee applied to sterling retail transactions made abroad.",
                    "items": {
                        "type": "number",
                        "minimum": 0

                    }
                },
                "foreignCashFee": {
                    "type": "array",
                    "title": "Foreign Cash Fee",
                    "description": "Additional card fee applied to sterling cash withdrawl made abroad.",
                    "items": {
                        "type": "number",
                        "minimum": 0

                    }
                },
                "foreignCashFeeRate": {
                    "type": "array",
                    "title": "Foreign Cash Fee rate",
                    "description": "Additional card fee applied to sterling cash withdrawl made abroad.",
                    "items": {
                        "type": "number",
                        "minimum": 0
                    }
                },
                "overdraftEligibility": {
                    "type": "boolean",
                    "title": "Overdraft Eligibility",
                    "description": "Is the account eligible for overdrafts"
                }
            },
            "required": [
                "paymentSchemeExchangeRate",
                "exchangeRateAdjustment",
                "overdraftEligibility"
            ]

        },

        "eligibility": {
            "type": "object",
            "title": "Eligibility",
            "description": "",
            "properties": {
                "ageRestricted": {
                    "type": "boolean",
                    "title": "Age Restricted",
                    "description": "Indicates a customer's age is part of eligiblity criteria"
                },
                "minimumAge": {
                    "type": "number",
                    "title": "Minimum Age",
                    "description": "Minimum age"
                },
                "maximumAge": {
                    "type": "number",
                    "title": "Maximum Age",
                    "description": "Maximum age, in years allowed to hold the account"
                },
                "otherFinancialHolding": {
                    "type": "boolean",
                    "title": "Other Financial Holding",
                    "description": "Other financial holding required"
                },
                "eligibilityDescription": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 256,
                    "title": "Eligibility Description",
                    "description": "One paragraph detailing the eligibility"
                },
                "incomeRelated": {
                    "type": "boolean",
                    "title": "Income Related",
                    "description": "Indicates if eligibility linked to income"
                },
                "singleJointIncome": {
                    "type": "string",
                    "title": "Currency",
                    "description": "Minimum income source for certain products minimum income is required",
                    "widget": "select",
                    "default":"Single",
                    "oneOf": [
                        {
                            "enum": [
                                "Single"
                            ],
                            "description": "Single"
                        },
                        {
                            "enum": [
                                "Joint"
                            ],
                            "description": "Joint"
                        },
                        {
                            "enum": [
                                "Single or Joint"
                            ],
                            "description": "Single or Joint"
                        }
                    ]
                },
                "minimumIncomeAmount": {
                    "type": "number",
                    "title": "Minimum Income Amount",
                    "description": "Minimum income/ turnover required to hold the product "
                },
                "minimumIncomeCurrency": {
                    "type": "string",
                    "title": "Currency",
                    "description": "Minimum Income Currency",
                    "default": "GBP",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "GBP"
                            ],
                            "description": "GBP"
                        },
                        {
                            "enum": [
                                "EUR"
                            ],
                            "description": "EUR"
                        },
                        {
                            "enum": [
                                "USD"
                            ],
                            "description": "USD"
                        }
                    ]
                },
                "minimumIncomeTimePeriod": {
                    "type": "string",
                    "title": "Minimum Income Time Period",
                    "description": "Minimum income time period",
                    "default": "Weekly",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "Weekly"
                            ],
                            "description": "Weekly"
                        },
                        {
                            "enum": [
                                "Monthly"
                            ],
                            "description": "Weekly"
                        },
                        {
                            "enum": [
                                "Yearly"
                            ],
                            "description": "Yearly"
                        }
                    ]
                },
                "waysMinIncomePaidIn": {
                    "type": "string",
                    "minLength": 0,
                    "maxLength": 50,
                    "title": "Ways Minimum Income Paid In",
                    "description": "Eg. DD Salary"
                },
                "minIncomePaidAccountMonth": {
                    "type": "number",
                    "title": "Minimum Income Paid into Account/Month",
                    "description": "Minimum income paid into Account/Month"
                },
                "annualCompanyTurnover": {
                    "type": "number",
                    "title": "Annual Company Turnover",
                    "description": "Annual company turnover"
                },
                "annualCompanyTurnoverCurrency": {
                    "type": "number",
                    "title": "Annual Company Turnover currency",
                    "description": "Annual company turnover"
                },
                "residencyRestricted": {
                    "type": "boolean",
                    "title": "Residency Restricted",
                    "description": "Indicates a customer's residency forms part of the eligibility criteria."
                },
                "residencyRegion": {
                    "type": "string",
                    "title": "Residency Region",
                    "description": "Residency Region",
                    "default": "UK",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "UK"
                            ],
                            "description": "UK"
                        }
                    ]
                },
                "maxNoOfAccounts": {
                    "type": "number",
                    "title": "Maximum Number of Accounts",
                    "description": "Maximum number of accounts"
                },
                "ThirdSectorOrganisations": {
                    "type": "boolean",
                    "title": "Third Sector Organisations",
                    "description": "This defines if the account holder is neither a person nor a business, such as a sports club."
                },
                "minimumDeposit": {
                    "type": "boolean",
                    "title": "Minimum Deposit",
                    "description": ""
                },
                "openingDepositMinAmount": {
                    "type": "array",
                    "title": "Opening Deposit Minimum Amount",
                    "description": "Opening deposit minimum amount",
                    "items": {
                        "type": "number"

                    }
                },
                "openingDepositMinCurrency": {
                    "type": "string",
                    "title": "Opening Deposit Minimum Currency",
                    "description": "Opening Deposit Minimum Currency",
                    "default": "GBP",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "GBP"
                            ],
                            "description": "GBP"
                        },
                        {
                            "enum": [
                                "EUR"
                            ],
                            "description": "EUR"
                        },
                        {
                            "enum": [
                                "USD"
                            ],
                            "description": "USD"
                        }
                    ]
                },
                "maximumOpeningAmount": {
                    "type": "boolean",
                    "title": "Maximum Opening Amount",
                    "description": "Maximum Opening Amount"
                },
                "openingDepositMaximumAmount": {
                    "type": "array",
                    "title": "Opening Deposit Maximum Amount",
                    "description": "Opening deposit maximum amount",
                    "items": {
                        "type": "number"

                    }
                },
                "openingDepositMaxCurrency": {
                    "type": "string",
                    "title": "Opening Deposit Maximum Currency",
                    "description": "Opening Deposit Maximum Currency",
                    "default": "GBP",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "GBP"
                            ],
                            "description": "GBP"
                        },
                        {
                            "enum": [
                                "EUR"
                            ],
                            "description": "EUR"
                        },
                        {
                            "enum": [
                                "USD"
                            ],
                            "description": "USD"
                        }
                    ]
                },
                "eligibilityName": {
                    "type": "string",
                    "minLength": 0,
                    "maxLength": 50,
                    "title": "Eligibility Name",
                    "description": "Eligibility Name"
                },
                "eligibilityType": {
                    "type": "string",
                    "title": "Eligibility Type",
                    "description": "List of reference data for eligibility constraints",
                    "default": "Business Only",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "Business Only"
                            ],
                            "description": "Business Only"
                        },
                        {
                            "enum": [
                                "Students Only"
                            ],
                            "description": "Students Only"
                        },
                        {
                            "enum": [
                                "NTB Business"
                            ],
                            "description": "NTB Business"
                        },
                        {
                            "enum": [
                                "Credit Scoring"
                            ],
                            "description": "Credit Scoring"
                        },
                        {
                            "enum": [
                                "Sole UK Account"
                            ],
                            "description": "Sole UK Account"
                        }
                    ]
                },
                "eligibilityNotes": {
                    "type": "array",
                    "title": "Eligibility Notes",
                    "description": "Optional additional notes to supplement the eligibility conditions",
                    "items": {
                        "type": "string",
                        "minLength": 0,
                        "maxLength": 256
                    }
                },
                "previousBancruptcy": {
                    "type": "boolean",
                    "title": "Previous Bancruptcy",
                    "description": "Describes if a previous bankcruptcy disqualifies for this account"
                },
                "marketingEligibility": {
                    "type": "string",
                    "title": "Marketing Eligibility",
                    "description": "Specifiy Eligibility for marketing",
                    "widget": "select",
                    "default":"Switchers Only",
                    "oneOf": [
                        {
                            "enum": [
                                "Switchers Only"
                            ],
                            "description": "Switchers Only"
                        },
                        {
                            "enum": [
                                "New Customers Only"
                            ],
                            "description": "New Customers Only"
                        }
                    ]
                }
            },
            "required": [
                "ageRestricted",
                "otherFinancialHolding",
                "incomeRelated",
                "residencyRestricted",
                "minimumDeposit",
                "maximumOpeningAmount",
                "previousBancruptcy"
            ]
        },
        "fee": {
            "type": "object",
            "title": "Fee",
            "description": "",
            "properties": {
                "feeType": {
                    "type": "string",
                    "title": "Type",
                    "description": "short description",
                    "default": "Account Fee",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "Account Fee"
                            ],
                            "description": "Account Fee"
                        },
                        {
                            "enum": [
                                "Incoming CHAPS Fee"
                            ],
                            "description": "Incoming CHAPS Fee"
                        },
                        {
                            "enum": [
                                "Outgoing CHAPS Fee"
                            ],
                            "description": "Outgoing CHAPS Fee"
                        },
                        {
                            "enum": [
                                "Foreign Currency"
                            ],
                            "description": "Foreign Currency"
                        },
                        {
                            "enum": [
                                "Foreign Currency Withdrawl Fee(% of Tx-Min £2 - Max £5)"
                            ],
                            "description": "Foreign Currency Withdrawl Fee(% of Tx-Min £2 - Max £5)"
                        },
                        {
                            "enum": [
                                "Non Sterling Transaction Fee (Cash Withdrawl)"
                            ],
                            "description": "Non Sterling Transaction Fee (Cash Withdrawl)"
                        },
                        {
                            "enum": [
                                "Foreign Purchase Fee"
                            ],
                            "description": "Foreign Purchase Fee"
                        },
                        {
                            "enum": [
                                "SEPA Fee"
                            ],
                            "description": "SEPA Fee"
                        },
                        {
                            "enum": [
                                "Stopped Cheque Fee"
                            ],
                            "description": "Stopped Cheque Fee"
                        },
                        {
                            "enum": [
                                "Copy of Cheque Fee"
                            ],
                            "description": "Copy of Cheque Fee"
                        },
                        {
                            "enum": [
                                "Cheque Transaction Fee"
                            ],
                            "description": "Cheque Transaction Fee"
                        },
                        {
                            "enum": [
                                "Manual Debit Fee"
                            ],
                            "description": "Manual Debit Fee"
                        },
                        {
                            "enum": [
                                "Counter Draft"
                            ],
                            "description": "Counter Draft"
                        },
                        {
                            "enum": [
                                "Unpaid Transaction Fee"
                            ],
                            "description": "Unpaid Transaction Fee"
                        },
                        {
                            "enum": [
                                "Special Cheque Presentation"
                            ],
                            "description": "Special Cheque Presentation"
                        },
                        {
                            "enum": [
                                "Court Order Fee"
                            ],
                            "description": "Court Order Fee"
                        },
                        {
                            "enum": [
                                "Bankers Draft Fee"
                            ],
                            "description": "Bankers Draft Fee"
                        },
                        {
                            "enum": [
                                "Statement Copy Fee"
                            ],
                            "description": "Statement Copy Fee"
                        },
                        {
                            "enum": [
                                "Bankers Reference Fee"
                            ],
                            "description": "Bankers Reference Fee"
                        },
                        {
                            "enum": [
                                "Personalised Card Fee"
                            ],
                            "description": "Personalised Card Fee"
                        },
                        {
                            "enum": [
                                "Sterling Travellers Cheque (% of Tx - Min £2 - Max£5)"
                            ],
                            "description": "Sterling Travellers Cheque (% of Tx - Min £2 - Max£5)"
                        },
                        {
                            "enum": [
                                "International Payments Charge"
                            ],
                            "description": "International Payments Charge"
                        },
                        {
                            "enum": [
                                "Other"
                            ],
                            "description": "Other"
                        },
                        {
                            "enum": [
                                "Cash Payment In"
                            ],
                            "description": "Cash Payment In"
                        },
                        {
                            "enum": [
                                "Cash Payment Out"
                            ],
                            "description": "Cash Payment Out"
                        },
                        {
                            "enum": [
                                "Daily Monitoring"
                            ],
                            "description": "Daily Monitoring"
                        },
                        {
                            "enum": [
                                "Weekly Monitoring"
                            ],
                            "description": "Weekly Monitoring"
                        },
                        {
                            "enum": [
                                "Monthly Monitoring"
                            ],
                            "description": "Monthly Monitoring"
                        },
                        {
                            "enum": [
                                "Status Enquiry"
                            ],
                            "description": "Status Enquiry"
                        },
                        {
                            "enum": [
                                "Audit Letter"
                            ],
                            "description": "Audit Letter"
                        },
                        {
                            "enum": [
                                "Credits paid in via night Safe"
                            ],
                            "description": "Credits paid in via night Safe"
                        },
                        {
                            "enum": [
                                "Credit paid in via Depos ATM"
                            ],
                            "description": "Credit paid in via Depos ATM"
                        },
                        {
                            "enum": [
                                "Telepay or Teledebit Item"
                            ],
                            "description": "Telepay or Teledebit Item"
                        }
                    ]
                },
                "feeSubType": {
                    "type": "string",
                    "title": "Fee Sub Type",
                    "description": "Fee Sub Type",
                    "widget": "select",
                    "default":"Promotional",
                    "oneOf": [
                        {
                            "enum": [
                                "Promotional"
                            ],
                            "description": "Promotional"
                        },
                        {
                            "enum": [
                                "Regular"
                            ],
                            "description": "Regular"
                        },
                        {
                            "enum": [
                                "Future Regular terms (mulitple times)"
                            ],
                            "description": "Future Regular terms (mulitple times)"
                        }
                    ]
                },
                "startPromotion": {
                    "type": "string",
                    "format": "date",
                    "widget" :"date",
                    "title": "Start Pomotion",
                    "description": "Start Promotion"
                },
                "stopPromotion": {
                    "type": "string",
                    "format": "date",
                    "widget" :"date",
                    "title": "Stop Promotion",
                    "description": "Stop Promotion"
                },
                "lengthPromotional": {
                    "type": "number",
                    "title": "Length Promotional",
                    "description": "Number of Days"
                },
                "dateOfChange": {
                    "type": "string",
                    "format": "date",
                    "widget" :"date",
                    "title": "Date of Change",
                    "description": "Date of Change"
                },
                "frequency": {
                    "type": "string",
                    "title": "Frequency",
                    "description": "Triggering frequency of the fee",
                    "widget": "select",
                    "default":"Monthly",
                    "oneOf": [
                        {
                            "enum": [
                                "Monthly"
                            ],
                            "description": "Monthly"
                        },
                        {
                            "enum": [
                                "Per Transaction - Amount"
                            ],
                            "description": "Per Transaction - Amount"
                        },
                        {
                            "enum": [
                                "Per Transaction - Percentage"
                            ],
                            "description": "Per Transaction - Percentage"
                        },
                        {
                            "enum": [
                                "Per Occurence"
                            ],
                            "description": "Per Occurence"
                        }
                    ]
                },
                "feeAmount": {
                    "type": "array",
                    "title": "Fee Amount",
                    "description": "Fee Amount",
                    "items": {
                        "type": "number",
                        "minimum": 0
                    }
                },
                "feeRate": {
                    "type": "array",
                    "title": "Fee Rate",
                    "description": "Fee Rate",
                    "items": {
                        "type": "number",
                        "minimum": 0

                    }
                },
                "negotiable": {
                    "type": "array",
                    "title": "Negotiable",
                    "description": "Negotiable",
                    "items": {
                        "type": "boolean"
                    }
                },
                "representativeRate": {
                    "type": "number",
                    "minimum": 0,
                    "title": "Representative Rate",
                    "description": "Representative Rate"
                },
                "feeLowerTier": {
                    "type": "array",
                    "title": "Fee Lower Tier",
                    "description": "Lower Occurence / range boundary",
                    "items": {
                        "type": "number",
                        "minimum": 0
                    }
                },
                "feeHigherTier": {
                    "type": "array",
                    "title": "Fee Higher Tier",
                    "description": "Higher Occurence / range boundary",
                    "items": {
                        "type": "number",
                        "minimum": 0
                    }
                },
                "feeAndCharges": {
                    "type": "array",
                    "title": "Fee And Charges",
                    "description": "Supplementary information for fees and charges",
                    "items": {
                        "type": "string",
                        "minLength": 0,
                        "maxLength": 256
                    }
                }
            },
            "required": [
                "feeType",
                "feeSubType",
                "frequency",
                "feeAmount",
                "feeRate",
                "negotiable"
            ]
        },
        "creditInterest": {
            "type": "object",
            "title": "Credit Interest",
            "description": "Credit Interest",
            "properties": {
                "creditCharged": {
                    "type": "boolean",
                    "title": "Credit Charged",
                    "description": "Is credit charged on account"
                },
                "interestRateType": {
                    "type": "string",
                    "title": "Type",
                    "description": "is the Interest fixed or variable",
                    "default": "Fixed",
                    "widget": "select",
                    "oneOf": [
                        {
                            "enum": [
                                "Fixed"
                            ],
                            "description": "Fixed"
                        },
                        {
                            "enum": [
                                "Variable"
                            ],
                            "description": "Variable"
                        }
                    ]
                },
                "startDate": {
                    "type": "array",
                    "title": "Start Date",
                    "description": "If interest is charged on a specific date range as start date",
                    "items": {
                        "type": "string",
                        "widget":"date",
                        "format": "date"
                    }
                },
                "period": {
                    "type": "array",
                    "description": "If interest is charged on a specific date range in month",
                    "title": "Period",
                    "items": {
                        "type": "number",
                        "minimum": 0
                    }
                },
                "endDate": {
                    "type": "string",
                    "format": "date",
                    "widget":"date",
                    "title": "End Date",
                    "description": "If interest is charged on a specific date range as end date"
                },
                "calculationFrequency": {
                    "type": "string",
                    "title": "calculationFrequency",
                    "description": "calculationFrequency",
                    "widget": "select",
                    "default":"Annualy",
                    "oneOf": [
                        {
                            "enum": [
                                "Annualy"
                            ],
                            "description": "Annualy"
                        },
                        {
                            "enum": [
                                "Quartely"
                            ],
                            "description": "Quartely"
                        },
                        {
                            "enum": [
                                "Haf Yearly"
                            ],
                            "description": "Haf Yearly"
                        },
                        {
                            "enum": [
                                "Monthly"
                            ],
                            "description": "Monthly"
                        }
                    ]
                },
                "paymentMethod": {
                    "type": "string",
                    "title": "calculationFrequency",
                    "description": "Calculation Frequency",
                    "widget": "select",
                    "default":"Pay Away",
                    "oneOf": [
                        {
                            "enum": [
                                "Pay Away"
                            ],
                            "description": "Pay Away"
                        },
                        {
                            "enum": [
                                "Compound"
                            ],
                            "description": "Ccompound"
                        }
                    ]
                },
                "fixedInterestLength": {
                    "type": "number",
                    "minimum": 0,
                    "title": "Fixed Interest Length",
                    "description": "Fixed Interest Length"
                },
                "fixedInterestUnit": {
                    "type": "string",
                    "title": "Fixed Interest Unit",
                    "description": "Fixed Interest Unit",
                    "widget": "select",
                    "default":"Week",
                    "oneOf": [
                        {
                            "enum": [
                                "Week"
                            ],
                            "description": "Week"
                        },
                        {
                            "enum": [
                                "Month"
                            ],
                            "description": "Month"
                        },
                        {
                            "enum": [
                                "Year"
                            ],
                            "description": "Year"
                        }
                    ]
                },
                "calculationMethod": {
                    "type": "string",
                    "title": "Calculation Method",
                    "description": "Calculation method",
                    "widget": "select",
                    "default":"Branded",
                    "oneOf": [
                        {
                            "enum": [
                                "Branded"
                            ],
                            "description": "Branded"
                        },
                        {
                            "enum": [
                                "Tiered"
                            ],
                            "description": "Tiered"
                        }
                    ]
                },
                "interestTier": {
                    "type": "string",
                    "description": "Identifier of the tier",
                    "title": "Interest Tier",
                    "items": {
                        "type": "string",
                        "minLength": 0,
                        "maxLength": 256

                    }
                },
                "tierValueMaximum": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 256,
                    "title": "Tier Value Maximum",
                    "description": "Tier value maximum"
                },
                "tierValueMinimum": {
                    "type": "string",
                    "minLength": 0,
                    "maxLength": 256,
                    "title": "Tier Value Minimum",
                    "description": "Tier value minimum"
                },
                "rate": {
                    "type": "array",
                    "description": "Rate",
                    "title": "Rate",
                    "items": {
                        "type": "number"
                    }
                },
                "rateComparisionType": {
                    "type": "string",
                    "title": "Rate Comparision Type",
                    "description": "Comparision Type",
                    "widget": "select",
                    "default":"APR",
                    "oneOf": [
                        {
                            "enum": [
                                "APR"
                            ],
                            "description": "APR"
                        },
                        {
                            "enum": [
                                "AER"
                            ],
                            "description": "AER"
                        }
                    ]
                },
                "interestNotes": {
                    "type": "string",
                    "minLength": 0,
                    "maxLength": 256,
                    "title": "Interest Notes",
                    "description": "Additional notes to supplement the interest details"
                },
                "interestSubType": {
                    "type": "string",
                    "title": "Interest Sub Type",
                    "description": "Interest Sub Type",
                    "widget": "select",
                    "default":"Promotional",
                    "oneOf": [
                        {
                            "enum": [
                                "Promotional"
                            ],
                            "description": "Promotional"
                        },
                        {
                            "enum": [
                                "Regular"
                            ],
                            "description": "Regular"
                        },
                        {
                            "enum": [
                                "Future Regular terms (multiple times)"
                            ],
                            "description": "Future Regular terms (multiple times)"
                        }
                    ]
                },
                "startPromotion": {
                    "type": "array",
                    "description": "Start Promotion",
                    "title": "Start Promotion",
                    "items": {
                        "type": "string",
                        "format": "date",
                        "widget":"date"
                    }
                },
                "stopPromotion": {
                    "type": "array",
                    "description": "Stop Promotion",
                    "title": "Stop Promotion",
                    "items": {
                        "type": "string",
                        "format": "date",
                        "widget" :"date"
                    }
                },
                "lengthPromotional": {
                    "type": "array",
                    "description": "lengthPromotional",
                    "title": "Length Promotional",
                    "items": {
                        "type": "number"
                    }
                },
                "dateOfChange": {
                    "type": "array",
                    "description": "Date of Change",
                    "title": "Date Of Change",

                    "items": {
                        "type": "string",
                        "format": "date",
                        "widget":"date"
                    }
                }
            },
            "required": [
                "interestRateType",
                "tierValueMinimum"
            ]
        },
        "availability": {
            "type": "object",
            "title": "Availability",
            "description": "",
            "properties": {
                "onSaleFrom": {
                    "type": "string",
                    "widget": "date",
                    "title": "On Sale From",
                    "description": "short description"
                },
                "onSaleTo": {
                    "type": "string",
                    "widget": "date",
                    "title": "On Sale To",
                    "description": "short description"
                }
            },
            "required": [
                "onSaleFrom",
                "onSaleTo"
            ]
        },
        "overdraft": {
            "type": "object",
            "title": "Overdraft",
            "description": "Overdraft",
            "properties": {
                "interestTierSME": {
                    "type": "string",
                    "title": "Interest Tier (SME)",
                    "description": "Identifier for the tier",
                    "widget": "select",
                    "default":"5,100",
                    "oneOf": [
                        {
                            "enum": [
                                "5,100"
                            ],
                            "description": "5,100"
                        },
                        {
                            "enum": [
                                "10,000"
                            ],
                            "description": "10,000"
                        },
                        {
                            "enum": [
                                "15,000"
                            ],
                            "description": "15,000"
                        },
                        {
                            "enum": [
                                "20,000"
                            ],
                            "description": "20,000"
                        },
                        {
                            "enum": [
                                "25,000"
                            ],
                            "description": "25,000"
                        }
                    ]
                },
                "interestTierPersonal": {
                    "type": "string",
                    "minLength": 0,
                    "maxLength": 250,
                    "title": "Interest Tier (Personal)",
                    "description": "Identifier for the tier"
                },
                "tierValueMinimum": {
                    "type": "number",
                    "title": "Tier Value Minimum",
                    "description": "Lower value of interest tier"
                },
                "tierValueMaximum": {
                    "type": "number",
                    "title": "Tier Value Maximum",
                    "description": "Max of interest tier"
                },
                "interestRateGross": {
                    "type": "number",
                    "minimum": 0,
                    "title": "Interest Rate Gross p.a",
                    "description": "Interest rate applied to tier"
                },
                "interestNotes": {
                    "type": "string",
                    "title": "Interest Notes",
                    "description": "Optional additional notes to supplement the interest details",
                    "widget": "select",
                    "default":"Week",
                    "oneOf": [
                        {
                            "enum": [
                                "Week"
                            ],
                            "description": "Week"
                        },
                        {
                            "enum": [
                                "Month"
                            ],
                            "description": "Month"
                        },
                        {
                            "enum": [
                                "Year"
                            ],
                            "description": "Year"
                        }
                    ]
                },
                "totalOverDraftChargeAmount": {
                    "type": "string",
                    "title": "Total Overdraft Charge Amount",
                    "description": "'total charge' means all charges that a customer could incur as result of exceeding or attempting to exceed a Pre-agreed credit limit.",
                    "widget": "select",
                    "default":"Branded",
                    "oneOf": [
                        {
                            "enum": [
                                "Branded"
                            ],
                            "description": "Branded"
                        },
                        {
                            "enum": [
                                "Tiered"
                            ],
                            "description": "Tiered"
                        }
                    ]
                },
                "maxUnarrangedOverdraftAmount": {
                    "type": "array",
                    "title": "Maximum Unarranged Overdraft amount",
                    "description": "Max unarranged Overdraft Amount",
                    "items": {
                        "type": "number",
                        "minLength": 0
                    }
                },
                "minUnarrangedOverdraftAmount": {
                    "type": "number",
                    "title": "Minimum Unarranged Overdraft amount",
                    "description": "Min unarranged Overdraft Amount"
                },
                "dailyOverdraftFeeCap": {
                    "type": "number",
                    "title": "Daily Overdraft Fee Cap",
                    "description": "Maximum daily overdraft charge"
                },
                "monthlyOverdraftFeeCap": {
                    "type": "number",
                    "title": "Monthly Overdraft Fee Cap",
                    "description": "Maximum monthly overdraft charge"
                },
                "arrangedOverdraftInterestTiers": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 256,
                    "title": "Arranged Overdraft Interest Tiers",
                    "description": "Arranged overdraft interest tiers"
                },
                "interestRate": {
                    "type": "array",
                    "title": "Interest Rate",
                    "description": "Interest rate applied to tier",
                    "items": {
                        "type": "number",
                        "minLength": 0
                    }
                },
                "interestRateCalculationFrequency": {
                    "type": "string",
                    "title": "Interest Rate Calculation Frequency",
                    "description": "According to draft order",
                    "widget": "select",
                    "default":"Daily",
                    "oneOf": [
                        {
                            "enum": [
                                "Daily"
                            ],
                            "description": "Daily"
                        },
                        {
                            "enum": [
                                "Monthly"
                            ],
                            "description": "Monthly"
                        },
                        {
                            "enum": [
                                "Quarterly"
                            ],
                            "description": "Quarterly"
                        },
                        {
                            "enum": [
                                "Yearly"
                            ],
                            "description": "Yearly"
                        }
                    ]
                },
                "unArrangedOverdraftInterestTiers": {
                    "type": "number",
                    "title": "Unarranged Overdraft Interest Tiers",
                    "description": "Array of interest rates"
                },
                "representative": {
                    "type": "array",
                    "title": "Representative",
                    "description": "representative",
                    "items": {
                        "type": "boolean"
                    }
                },
                "dailyCharge": {
                    "type": "array",
                    "title": "Daily Charge",
                    "description": "Arranged overdraft daily charge",
                    "items": {
                        "type": "number"
                    }
                },
                "monthlyCharge": {
                    "type": "array",
                    "title": "Monthly Charge",
                    "description": "Arranged overdraft monthly charge",
                    "items": {
                        "type": "number"
                    }
                },
                "itemCharge": {
                    "type": "array",
                    "title": "Item Charge",
                    "description": "Arranged overdraft item charge",
                    "items": {
                        "type": "number"
                    }
                },
                "otherCharge": {
                    "type": "array",
                    "title": "Other Charge",
                    "description": "Other flat charge levied when overdrawn (Arranged)",
                    "items": {
                        "type": "number"
                    }
                },
                "unArrangedDailyCharge": {
                    "type": "array",
                    "title": "Unarranged Daily Charge",
                    "description": "Unarranged overdraft daily charge",
                    "items": {
                        "type": "number"
                    }
                },
                "unArrangedMonthlyCharge": {
                    "type": "array",
                    "title": "Unarranged Monthly Charge",
                    "description": "Unarranged overdraft Monthly charge",
                    "items": {
                        "type": "number"
                    }
                },
                "unArrangedItemCharge": {
                    "type": "array",
                    "title": "Unarranged Item Charge",
                    "description": "Unarranged overdraft Item charge",
                    "items": {
                        "type": "number"
                    }
                },
                "unArrangedOtherCharge": {
                    "type": "array",
                    "title": "Unarranged Other Charge",
                    "description": "Unarranged overdraft Other charge",
                    "items": {
                        "type": "number"
                    }
                },
                "overdraftNotes": {
                    "type": "array",
                    "title": "Overdraft Notes",
                    "description": "Supplementary notes for overdrafts",
                    "items": {
                        "type": "string"
                    }
                },
                "ratesAreNegotiable": {
                    "type": "array",
                    "title": "Rates are negotiable",
                    "description": "Rates are Negotiable",
                    "items": {
                        "type": "boolean"
                    }
                },
                "representativeRate": {
                    "type": "array",
                    "title": "Representative Rate",
                    "description": "Representative Rate",
                    "items": {
                        "type": "boolean"
                    }
                },
                "bufferAmount": {
                    "type": "array",
                    "title": "Buffer Amount",
                    "description": "Buffer Amount",
                    "items": {
                        "type": "number"
                    }
                },
                "commited": {
                    "type": "array",
                    "title": "Commited",
                    "description": "Opposite of repayable on demand",
                    "items": {
                        "type": "number"
                    }
                },
                "term": {
                    "type": "array",
                    "title": "Term (duration) in days",
                    "description": "The duration of the overdraft, if it is non permanent",
                    "items": {
                        "type": "number"
                    }
                },
                "setUpFeesAmount": {
                    "type": "array",
                    "title": "Setup Fees Amount",
                    "description": "setup Fees Amount",
                    "items": {
                        "type": "number"
                    }
                },
                "setUpFeesRate": {
                    "type": "array",
                    "title": "Setup Fees Rate",
                    "description": "setup Fees Rate",
                    "items": {
                        "type": "number"
                    }
                },
                "reviewFee": {
                    "type": "array",
                    "title": "Review Fee",
                    "description": "Review Fee",
                    "items": {
                        "type": "number"
                    }
                },
                "minimumFee": {
                    "type": "array",
                    "title": "Minimum Fee",
                    "description": "Review Fee",
                    "items": {
                        "type": "number"
                    }
                },
                "interestTierSubType": {
                    "type": "string",
                    "title": "Interest Tier Sub-Type",
                    "description": "Interest Tier Sub-Type",
                    "widget": "select",
                    "default":"Promotional",
                    "oneOf": [
                        {
                            "enum": [
                                "Promotional"
                            ],
                            "description": "Promotional"
                        },
                        {
                            "enum": [
                                "Regular"
                            ],
                            "description": "Regular"
                        },
                        {
                            "enum": [
                                "Future Regular Terms (multiple times)"
                            ],
                            "description": "Future Regular Terms (multiple times)"
                        }
                    ]
                },
                "startPromotion": {
                    "type": "array",
                    "title": "Start Promotion",
                    "description": "Start Promotion or Future Terms",
                    "items": {
                        "type": "string",
                        "format": "date",
                        "widget" :"date"
                    }
                },
                "stopPromotion": {
                    "type": "array",
                    "title": "Stop Promotion",
                    "description": "Stop Promotion or Future Terms",
                    "items": {
                        "type": "string",
                        "format": "date",
                        "widget" :"date"

                    }
                },
                "lengthPromotional": {
                    "type": "array",
                    "title": "Length Promotional",
                    "description": "Promotional Length",
                    "items": {
                        "type": "number"
                    }
                },
                "dateOfChange": {
                    "type": "array",
                    "title": "Date of change (if known)",
                    "description": "Date of change",
                    "items": {
                        "type": "string",
                        "widget" :"date",
                        "format":"date"
                    }
                },
                "unAuthorizedFee": {
                    "type": "array",
                    "title": "Unauthorized Fee",
                    "description": "Unauthorized, but arranged fee",
                    "items": {
                        "type": "number"
                    }
                },
                "unAuthorizedFeeCap": {
                    "type": "array",
                    "title": "Unauthorized Fee Cap",
                    "description": "Unauthorized fee cap",
                    "items": {
                        "type": "number"
                    }
                }
            },
            "required": [
                "arrangedOverdraftInterestTiers",
                "tierValueMinimum"
            ]
        },
        "benefits": {
            "type": "object",
            "title": "Benefits",
            "description": "Benefits",
            "properties": {
                "featureType": {
                    "type": "array",
                    "title": "Feature Type",
                    "description": "Type that represents the nature of the benefit",
                    "items": {
                        "type": "string",
                        "minLength": 0,
                        "maxLength": 256
                    }
                },
                "featureName": {
                    "type": "array",
                    "title": "Feature Name",
                    "description": "The name of the benefit",
                    "items": {
                        "type": "string",
                        "minLength": 0,
                        "maxLength": 256
                    }
                },
                "featureDescription": {
                    "type": "array",
                    "title": "Feature Description",
                    "description": "A textual explanation of what the benefit is",
                    "items": {
                        "type": "string",
                        "minLength": 0,
                        "maxLength": 256
                    }
                },
                "featureValue": {
                    "type": "array",
                    "title": "Feature Value",
                    "description": "The value or values permissible fo a specific benefit for an individual product representing a product characteristic",
                    "items": {
                        "type": "string",
                        "minLength": 0,
                        "maxLength": 256
                    }
                },
                "defaultToAccounts": {
                    "type": "array",
                    "title": "Default to Accounts",
                    "description": "Is the benefit part of the default account",
                    "items": {
                        "type": "boolean"
                    }
                },
                "benefitId": {
                    "type": "array",
                    "title": "Benefit Id",
                    "description": "Unique benefit identifier per organisation",
                    "items": {
                        "type": "number"
                    }
                },
                "benefitType": {
                    "type": "array",
                    "title": "Benefit Type",
                    "description": "Title of the benefit not listed above",
                    "items": {
                        "type": "string"
                    }
                },
                "criteriaType": {
                    "type": "array",
                    "title": "Criteria Type",
                    "description": "Criteria Type",
                    "items": {
                        "type": "string",
                        "minLength": 0
                    }
                },
                "minimumCriteria": {
                    "type": "array",
                    "title": "Minimum Criteria",
                    "description": "Minimum amount of the criteria",
                    "items": {
                        "type": "number"
                    }
                },
                "maximumCriteria": {
                    "type": "array",
                    "title": "Maximum Criteria",
                    "description": "Maximum amount of the criteria",
                    "items": {
                        "type": "number"
                    }
                },
                "counter": {
                    "type": "array",
                    "title": "Counter",
                    "description": "Counter for the criteria (eg., number of DD)",
                    "items": {
                        "type": "string",
                        "minLength": 0,
                        "maxLength": 256
                    }
                },
                "description": {
                    "type": "array",
                    "title": "Description",
                    "description": "Description of the benefit",
                    "items": {
                        "type": "string",
                        "minLength": 0,
                        "maxLength": 256
                    }
                },
                "endDate": {
                    "type": "array",
                    "title": "End Date",
                    "description": "End Date",
                    "items": {
                        "type": "string",
                        "format": "date",
                        "widget": "date"
                    }
                },
                "promotionStartDate": {
                    "type": "array",
                    "title": "Promotion Start Date",
                    "description": "If the benefit is temporal the start date is when the benefit comes into effect",
                    "items": {
                        "type": "string",
                        "format": "date",
                        "widget": "date"
                    }
                },
                "promotionEndtDate": {
                    "type": "array",
                    "title": "Promotion End Date",
                    "description": "If the benefit is temporal the start date is when the benefit comes into effect",
                    "items": {
                        "type": "string",
                        "format": "date",
                        "widget": "date"
                    }
                },
                "benefitSubType": {
                    "type": "string",
                    "title": "Benefit Sub-Type",
                    "description": "Benefit Sub type",
                    "widget": "select",
                    "default":"Promotional",
                    "oneOf": [
                        {
                            "enum": [
                                "Promotional"
                            ],
                            "description": "Promotional"
                        },
                        {
                            "enum": [
                                "Regular"
                            ],
                            "description": "Regular"
                        },
                        {
                            "enum": [
                                "Future Regular Terms (multiple times)"
                            ],
                            "description": "Future Regular Terms (multiple times)"
                        }
                    ]
                },
                "startPromotion": {
                    "type": "array",
                    "title": "Start Promotion or Future terms",
                    "description": "Start Promotion or Future terms",
                    "items": {
                        "type": "string",
                        "format": "date",
                        "widget": "date"
                    }
                },
                "stopPromotion": {
                    "type": "array",
                    "title": "Stop Promotion or Future terms",
                    "description": "Stop Promotion or Future terms",
                    "items": {
                        "type": "string",
                        "format": "date",
                        "widget": "date"
                    }
                },
                "lengthPromotional": {
                    "type": "array",
                    "title": "Promtional Length",
                    "description": "Promotional Length",
                    "items": {
                        "type": "number"
                    }
                },
                "dateOfChange": {
                    "type": "array",
                    "title": "Date of Change",
                    "description": "Date of Change",
                    "items": {
                        "type": "string",
                        "format": "date",
                        "widget": "date"
                    }
                }
            },
            "required": [
                "benefitSubType"
            ]
        }
    },
    "required": [
        "organisation",
        "product",
        "card",
        "eligibility",
        "fee",
        "creditInterest",
        "availability",
        "overdraft",
        "benefits"
    ],
    "fieldsets": [
        {
            "fields": [
                "organisation"
            ],
            "title": "Organisation"
        },
        {
            "fields": [
                "product"
            ],
            "title": "Product"
        },
        {
            "fields": [
                "card"
            ],
            "title": "Card"
        },
        {
            "fields": [
                "eligibility"
            ],
            "title": "Eligibility"
        },
        {
            "fields": [
                "fee"
            ],
            "title": "Fee"
        },
        {
            "fields": [
                "creditInterest"
            ],
            "title": "Credit Interest"
        },
        {
            "fields": [
                "availability"
            ],
            "title": "Availability"
        },
        {
            "fields": [
                "overdraft"
            ],
            "title": "Overdraft"
        },
        {
            "fields": [
                "benefits"
            ],
            "title": "Benefit"
        }
    ]
};




var query = {
    _id: ObjectId(PRODUCT_TEMPLATE_ID)
};

var values = {
    $inc: {version: 1},
    $set: {schema: schema}
};

db.productTemplate.update(query, values);

print('success');