var PRODUCT_TEMPLATE_ID = '5836e070abd40fb7e9c68e5b';

var productTemplate = {
	"_id": ObjectId(PRODUCT_TEMPLATE_ID),
	"title": "Commercial Credit Cards",
	"type": "CCC",
	"createdAt": new Date(),
	"createdBy": "dev-ops-team",
	"status": "ACTIVE",
	"schema" : {},
	"version": 1
};
db.productTemplate.save(productTemplate);

print('success');