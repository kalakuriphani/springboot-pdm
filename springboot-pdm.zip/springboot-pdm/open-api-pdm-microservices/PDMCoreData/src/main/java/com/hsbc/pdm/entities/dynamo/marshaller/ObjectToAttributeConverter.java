package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

import java.util.Arrays;
import java.util.List;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class ObjectToAttributeConverter implements AttributeConverter {

    private static final List<AttributeConverter> STANDARD_CONVERTERS = Arrays.asList(
            new NullableToAttributeConverter(),
            DateToAttributeConverter.CONVERTER_INSTANCE, // must come before StringToAttributeConverter converter
            new StringToAttributeConverter(),
            new NumberToAttributeConverter(),
            new BooleanToAttributeConverter(),
            new StringCollectionToAttributeConverter(),
            MapToAttributeConverter.CONVERTER_INSTANCE,
            new MapCollectionToAttributeConverter(MapToAttributeConverter.CONVERTER_INSTANCE)
    );

    @Override
    public AttributeValue convert(Object o) {
        for (AttributeConverter converter : STANDARD_CONVERTERS) {
            if (converter.isConvertible(o)) {
                return converter.convert(o);
            }
        }
        // normally must never hit this, fail fast
        throw new RuntimeException(String.format("No converter available for value = %s (class = %s)", o, o.getClass()));
    }

    @Override
    public Object convert(AttributeValue attribute) {
        for (AttributeConverter converter : STANDARD_CONVERTERS) {
            if (converter.isConvertible(attribute)) {
                return converter.convert(attribute);
            }
        }
        // normally must never hit this, fail fast
        throw new RuntimeException(String.format("No converter available for AttributeValue = %s", attribute));
    }

    @Override
    public boolean isConvertible(Object o) {
        for (AttributeConverter converter : STANDARD_CONVERTERS) {
            if (converter.isConvertible(o)) {
                return true;
            }
        }
        // normally must never hit this, fail fast
        throw new RuntimeException(String.format("No converter available for value = %s (class = %s)", o, o.getClass()));
    }

    @Override
    public boolean isConvertible(AttributeValue attribute) {
        if (attribute.getS() == null
                && attribute.getN() == null
                && attribute.getM() == null
                && attribute.getL() == null
                && attribute.getSS() == null
                && attribute.getBOOL() == null
                && attribute.getNULL() == null) {
            return false;
        }
        return true;
    }
}
