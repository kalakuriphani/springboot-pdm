package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.hsbc.pdm.common.UTCDateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class DateToAttributeConverter implements AttributeConverter {

    private static final Logger LOG = LoggerFactory.getLogger(DateToAttributeConverter.class);

    public static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

    public static final DateToAttributeConverter CONVERTER_INSTANCE = new DateToAttributeConverter();

    @Override
    public AttributeValue convert(Object o) {
        if (!isConvertible(o)) {
            throw new IllegalStateException("Object must be instance of Float");
        }
        return new AttributeValue().withS(UTCDateUtils.format((Date) o, DATETIME_FORMATTER));
    }

    @Override
    public Object convert(AttributeValue attribute) {
        try {
            return UTCDateUtils.parse(attribute.getS(), DATETIME_FORMATTER);
        } catch (DateTimeParseException e) {
            throw new RuntimeException("Failure to convert AttributeValue(S) = '" + attribute.getS() + "' into Date", e);
        }
    }

    @Override
    public boolean isConvertible(Object o) {
        return o instanceof Date;
    }

    @Override
    public boolean isConvertible(AttributeValue attribute) {
        if (attribute.getS() == null) {
            return false;
        }
        try {
            UTCDateUtils.parse(attribute.getS(), DATETIME_FORMATTER);
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }
}
