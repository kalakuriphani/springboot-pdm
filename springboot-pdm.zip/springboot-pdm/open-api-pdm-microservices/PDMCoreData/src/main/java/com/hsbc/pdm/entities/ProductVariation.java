package com.hsbc.pdm.entities;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.hsbc.pdm.entities.dynamo.marshaller.ObjectPropertyToAttributeConverter;

import java.util.Date;
import java.util.Map;

/**
 * Created by 44023148 on 27/01/2017.
 */
@DynamoDBDocument
public class ProductVariation {

    public static final String ID_FIELD = "Id";
    public static final String VARIATION_NAME_FIELD = "VariationName";
    public static final String START_DATE_FIELD = "StartDate";
    public static final String EXPIRY_DATE_FIELD = "ExpiryDate";
    public static final String DETAILS_FIELD = "Details";

    @DynamoDBAttribute(attributeName = ID_FIELD)
    private String id;

    @DynamoDBAttribute(attributeName = VARIATION_NAME_FIELD)
    private String variationName;

    @DynamoDBAttribute(attributeName = START_DATE_FIELD)
    private Date startDate;

    @DynamoDBAttribute(attributeName = EXPIRY_DATE_FIELD)
    private Date expiryDate;

    @DynamoDBAttribute(attributeName = DETAILS_FIELD)
    @DynamoDBTypeConverted(converter = ObjectPropertyToAttributeConverter.class)
    private Map<String, Object> details;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVariationName() {
        return variationName;
    }

    public void setVariationName(String variationName) {
        this.variationName = variationName;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Map<String, Object> getDetails() {
        return details;
    }

    public void setDetails(Map<String, Object> details) {
        this.details = details;
    }
}
