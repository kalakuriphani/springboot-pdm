package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class StringCollectionToAttributeConverter extends CollectionToAttributeConverter<String> {

    private StringToAttributeConverter stringToAttributeConverter = new StringToAttributeConverter();

    @Override
    protected Class<String> getCollectionItemType() {
        return String.class;
    }

    @Override
    protected List<AttributeValue> convertInternal(Collection<String> collection) {
        return collection.stream()
                .map(stringToAttributeConverter::convert)
                .collect(Collectors.toList());
    }

    @Override
    protected Collection<String> convertInternal(List<AttributeValue> attributes) {
        return attributes.stream()
                .map(item -> (String) stringToAttributeConverter.convert(item))
                .collect(Collectors.toList());
    }

    @Override
    protected boolean isConvertible(List<AttributeValue> attributes) {
        return attributes.get(0).getS() != null;
    }
}
