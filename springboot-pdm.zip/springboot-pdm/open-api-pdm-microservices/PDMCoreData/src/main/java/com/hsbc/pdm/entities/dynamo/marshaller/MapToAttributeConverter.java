package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class MapToAttributeConverter implements AttributeConverter {

    public static final MapToAttributeConverter CONVERTER_INSTANCE = new MapToAttributeConverter();

    private List<AttributeConverter> standardConverters = Arrays.asList(
            // NOTE : we believe order matters for better performance
            new NullableToAttributeConverter(),
            DateToAttributeConverter.CONVERTER_INSTANCE, // must come before DateToAttributeConverter converter
            new StringToAttributeConverter(),
            new NumberToAttributeConverter(),
            new BooleanToAttributeConverter(),
            new StringCollectionToAttributeConverter(),
            new MapCollectionToAttributeConverter(this),
            this
    );


    @Override
    public AttributeValue convert(Object o) {
        Map<String, AttributeValue> result = new LinkedHashMap<>();

        for (Map.Entry<String, Object> entry : ((Map<String, Object>) o).entrySet()) {
            for (AttributeConverter converter : standardConverters) {
                if (converter.isConvertible(entry.getValue())) {
                    result.put(entry.getKey(), converter.convert(entry.getValue()));
                    break; // inner for loop
                }
            }

        }

        return new AttributeValue().withM(result);
    }

    @Override
    public Object convert(AttributeValue attribute) {
        Map<String, Object> result = new LinkedHashMap<>();


        for (Map.Entry<String, AttributeValue> entry : attribute.getM().entrySet()) {
            for (AttributeConverter converter : standardConverters) {
                if (converter.isConvertible(entry.getValue())) {
                    result.put(entry.getKey(), converter.convert(entry.getValue()));
                    break; // inner for loop
                }
            }
        }

        return result;
    }

    @Override
    public boolean isConvertible(Object o) {
        return o instanceof Map;
    }

    @Override
    public boolean isConvertible(AttributeValue attribute) {
        if (attribute.getM() == null) {
            return false;
        }
        return true;
    }

}
