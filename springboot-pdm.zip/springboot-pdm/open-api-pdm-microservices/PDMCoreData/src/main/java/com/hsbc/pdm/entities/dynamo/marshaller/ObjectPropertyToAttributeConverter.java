package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.pdm.common.CustomObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class ObjectPropertyToAttributeConverter implements DynamoDBTypeConverter<AttributeValue, Object> {

    private static final Logger LOG = LoggerFactory.getLogger(ObjectPropertyToAttributeConverter.class);

    private ObjectToAttributeConverter converter = new ObjectToAttributeConverter();

    private ObjectMapper objectMapper = CustomObjectMapper.INSTANCE;


    @Override
    public AttributeValue convert(Object o) {
        if (LOG.isDebugEnabled()) {
            try {
                LOG.debug("DUMP OBJECT BEFORE CONVERT INTO ATTRIBUTE:\r\n{}", objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(o));
            } catch (JsonProcessingException e1) {
                LOG.error("Could not dump object", e1);
            }
        }
        return converter.convert(o);
    }

    @Override
    public Object unconvert(AttributeValue attribute) {
        Object o = converter.convert(attribute);
        if (LOG.isDebugEnabled()) {
            try {
                LOG.info("DUMP OBJECT AFTER CONVERT BACK FROM ATTRIBUTE:\r\n{}", objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(o));
            } catch (JsonProcessingException e1) {
                LOG.error("Could not dump object", e1);
            }
        }
        return o;
    }
}
