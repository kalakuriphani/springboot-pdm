package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.hsbc.pdm.entities.ProductVariation;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class ProductVariationsToAttributeConverter implements DynamoDBTypeConverter<AttributeValue, List<ProductVariation>> {

    private ProductVariationToAttributeConverter converter = new ProductVariationToAttributeConverter();

    public ProductVariationsToAttributeConverter() {

    }

    @Override
    public AttributeValue convert(List<ProductVariation> variations) {
        List<AttributeValue> result = variations.stream()
                .map(variation -> converter.convert(variation))
                .collect(Collectors.toList());

        return new AttributeValue().withL(result);
    }

    @Override
    public List<ProductVariation> unconvert(AttributeValue attribute) {
        List<ProductVariation> variations = new ArrayList<>(attribute.getL().size());

        variations.addAll(attribute.getL().stream()
                .map(attr -> converter.unconvert(attr))
                .collect(Collectors.toList()));

        return variations;
    }
}
