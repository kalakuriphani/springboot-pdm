package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

import java.util.Arrays;
import java.util.List;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class NumberToAttributeConverter implements AttributeConverter {

    private List<AttributeConverter> standardConverters = Arrays.asList(
            new ByteToAttributeConverter(),
            new ShortToAttributeConverter(),
            new IntegerToAttributeConverter(),
            new LongToAttributeConverter(),
            new FloatToAttributeConverter(),
            new DoubleToAttributeConverter()
    );

    @Override
    public AttributeValue convert(Object o) {
        for (AttributeConverter converter : standardConverters) {
            if (converter.isConvertible(o)) {
                return converter.convert(o);
            }
        }

        throw new IllegalStateException("Converter not found for value '" + o + "' of type " + o.getClass());
    }

    @Override
    public Object convert(AttributeValue attribute) {
        for (AttributeConverter converter : standardConverters) {
            if (converter.isConvertible(attribute)) {
                return converter.convert(attribute);
            }
        }

        throw new IllegalStateException("Converter not found for value " + attribute.getN());
    }

    @Override
    public boolean isConvertible(Object o) {
        return o instanceof Number;
    }

    @Override
    public boolean isConvertible(AttributeValue attribute) {
        return attribute.getN() != null;
    }

}
