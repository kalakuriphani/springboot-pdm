package com.hsbc.pdm.entities;

import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by 44023148 on 03/02/2017.
 */
public interface Product<ID> extends Serializable {

    ID getId();

    void setId(ID id);

    String getProductName();

    void setProductName(String productName);

    String getProductType();

    void setProductType(String productType);

    String getProductTypeInternal();

    void setProductTypeInternal(String productType);

    ProductTypeEnum getProductTypeInternalEnum();

    void setProductTypeInternalEnum(ProductTypeEnum productType);

    String getProductTypeVersion();

    void setProductTypeVersion(String productTypeVersion);

    Date getCreatedAt();

    void setCreatedAt(Date createdAt);

    String getCreatedBy();

    void setCreatedBy(String createdBy);

    Date getUpdatedAt();

    void setUpdatedAt(Date updatedAt);

    String getUpdatedBy();

    void setUpdatedBy(String updatedBy);

    Date getApprovedAt();

    void setApprovedAt(Date approvedAt);

    String getApprovedBy();

    void setApprovedBy(String approvedBy);

    String getStatus();

    void setStatus(String status);

    StatusEnum getStatusEnum();

    void setStatusEnum(StatusEnum status);

    String getCountry();

    void setCountry(String country);

    List<ProductVariation> getVariations();

    void setVariations(List<ProductVariation> variations);

    Integer getVersion();

    void setVersion(Integer version);

    List<ProductVariation> getApprovedVariations();

    void setApprovedVariations(List<ProductVariation> approvedVariations);
}
