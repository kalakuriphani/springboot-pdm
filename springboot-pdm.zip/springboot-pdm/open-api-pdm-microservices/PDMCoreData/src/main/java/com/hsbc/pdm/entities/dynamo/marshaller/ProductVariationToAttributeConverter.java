package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.util.DateUtils;
import com.hsbc.pdm.entities.ProductVariation;
import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.Map;

import static com.hsbc.pdm.entities.ProductVariation.*;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class ProductVariationToAttributeConverter implements DynamoDBTypeConverter<AttributeValue, ProductVariation> {

    private MapToAttributeConverter converter = MapToAttributeConverter.CONVERTER_INSTANCE;

    public ProductVariationToAttributeConverter() {

    }

    @Override
    public AttributeValue convert(ProductVariation variation) {
        Assert.notNull(variation, "Variation cannot be null");
        Map<String, AttributeValue> result = new HashMap<>();

        Assert.hasText(variation.getId(), "Variation Id cannot be null or empty");
        result.put(ID_FIELD, new AttributeValue().withS(variation.getId()));

        Assert.hasText(variation.getVariationName(), "Variation Name cannot be null or empty");
        result.put(VARIATION_NAME_FIELD, new AttributeValue().withS(variation.getVariationName()));

        Assert.notNull(variation.getStartDate(), "Variation Start Date cannot be null");
        result.put(START_DATE_FIELD, new AttributeValue().withS(DateUtils.formatISO8601Date(variation.getStartDate())));

        Assert.notNull(variation.getExpiryDate(), "Variation Expiry Date cannot be null");
        result.put(EXPIRY_DATE_FIELD, new AttributeValue().withS(DateUtils.formatISO8601Date(variation.getExpiryDate())));

        Assert.notNull(variation.getDetails(), "Variation Details cannot be null");
        Assert.notEmpty(variation.getDetails(), "Variation Details cannot be empty");
        result.put(DETAILS_FIELD, converter.convert(variation.getDetails()));

        return new AttributeValue().withM(result);
    }

    @Override
    public ProductVariation unconvert(AttributeValue attribute) {
        Map<String, AttributeValue> attributes = attribute.getM();

        ProductVariation variation = new ProductVariation();
        variation.setId(attributes.get(ID_FIELD).getS());
        variation.setVariationName(attributes.get(VARIATION_NAME_FIELD).getS());
        variation.setStartDate(DateUtils.parseISO8601Date(attributes.get(START_DATE_FIELD).getS()));
        variation.setExpiryDate(DateUtils.parseISO8601Date(attributes.get(EXPIRY_DATE_FIELD).getS()));
        variation.setDetails((Map<String, Object>) converter.convert(attributes.get(DETAILS_FIELD)));

        return variation;
    }
}
