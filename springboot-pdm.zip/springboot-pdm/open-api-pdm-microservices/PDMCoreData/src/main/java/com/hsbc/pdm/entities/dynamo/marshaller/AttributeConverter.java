package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

/**
 * Created by 44023148 on 06/02/2017.
 */
public interface AttributeConverter {

    AttributeValue convert(Object o);

    Object convert(AttributeValue attribute);

    boolean isConvertible(Object o);

    boolean isConvertible(AttributeValue attribute);
}
