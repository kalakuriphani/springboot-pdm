package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class IntegerToAttributeConverter implements AttributeConverter {

    @Override
    public AttributeValue convert(Object o) {
        return new AttributeValue().withN(o.toString());
    }

    @Override
    public Object convert(AttributeValue attribute) {
        return Integer.valueOf(attribute.getN());
    }

    @Override
    public boolean isConvertible(Object o) {
        return o instanceof Integer;
    }

    @Override
    public boolean isConvertible(AttributeValue attribute) {
        if (attribute.getN() == null) {
            return false;
        }
        try {
            Integer.parseInt(attribute.getN());
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }
}
