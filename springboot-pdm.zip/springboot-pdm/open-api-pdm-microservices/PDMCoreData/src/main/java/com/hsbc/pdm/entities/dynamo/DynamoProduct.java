package com.hsbc.pdm.entities.dynamo;

import com.amazonaws.services.dynamodbv2.datamodeling.*;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.entities.ProductVariation;

import java.util.Date;
import java.util.List;

@DynamoDBDocument
@DynamoDBTable(tableName = "pdm-products")
public class DynamoProduct implements com.hsbc.pdm.entities.Product<String> {

    public static final String ID_FIELD = "Id";
    public static final String PRODUCT_NAME_FIELD = "ProductName";
    public static final String PRODUCT_TYPE_FIELD = "ProductType";
    public static final String PRODUCT_TYPE_INTERNAL_FIELD = "ProductTypeInternal";
    public static final String PRODUCT_TYPE_VERSION_FIELD = "ProductTypeVersion";
    public static final String CREATED_AT_FIELD = "CreatedAt";
    public static final String CREATED_BY_FIELD = "CreatedBy";
    public static final String UPDATED_AT_FIELD = "UpdatedAt";
    public static final String UPDATED_BY_FIELD = "UpdatedBy";
    public static final String APPROVED_AT_FIELD = "ApprovedAt";
    public static final String APPROVED_BY_FIELD = "ApprovedBy";
    public static final String STATUS_FIELD = "ProductStatus";
    public static final String COUNTRY_FIELD = "Country";
    public static final String VARIATIONS_FIELD = "Variations";
    public static final String APPROVED_VARIATIONS_FIELD = "ApprovedVariations";
    public static final String VERSION_FIELD = "Version";

    @DynamoDBRangeKey(attributeName = ID_FIELD)
    private String id;

    @DynamoDBAttribute(attributeName = PRODUCT_NAME_FIELD)
    private String productName;

    @DynamoDBHashKey(attributeName = PRODUCT_TYPE_INTERNAL_FIELD)
    private String productTypeInternal;

    @DynamoDBAttribute(attributeName = PRODUCT_TYPE_FIELD)
    private String productType;

    @DynamoDBAttribute(attributeName = PRODUCT_TYPE_VERSION_FIELD)
    private String productTypeVersion;

    @DynamoDBAttribute(attributeName = CREATED_AT_FIELD)
    private Date createdAt;

    @DynamoDBAttribute(attributeName = CREATED_BY_FIELD)
    private String createdBy;

    @DynamoDBAttribute(attributeName = UPDATED_AT_FIELD)
    private Date updatedAt;

    @DynamoDBAttribute(attributeName = UPDATED_BY_FIELD)
    private String updatedBy;

    @DynamoDBAttribute(attributeName = APPROVED_AT_FIELD)
    private Date approvedAt;

    @DynamoDBAttribute(attributeName = APPROVED_BY_FIELD)
    private String approvedBy;

    @DynamoDBAttribute(attributeName = STATUS_FIELD)
    private String status;

    @DynamoDBAttribute(attributeName = COUNTRY_FIELD)
    private String country;

    @DynamoDBAttribute(attributeName = VARIATIONS_FIELD)
    private List<ProductVariation> variations;

    @DynamoDBAttribute(attributeName = APPROVED_VARIATIONS_FIELD)
    private List<ProductVariation> approvedVariations;

    @DynamoDBVersioned
    @DynamoDBAttribute(attributeName = VERSION_FIELD)
    private Integer version;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    @Override
    public String getProductTypeInternal() {
        return productTypeInternal;
    }

    @Override
    public void setProductTypeInternal(String productType) {
        productTypeInternal = productType;
    }

    @DynamoDBIgnore
    public ProductTypeEnum getProductTypeInternalEnum() {
        return ProductTypeEnum.valueOf(productTypeInternal);
    }

    @DynamoDBIgnore
    public void setProductTypeInternalEnum(ProductTypeEnum productType) {
        this.productTypeInternal = productType.name();
    }

    public String getProductTypeVersion() {
        return productTypeVersion;
    }

    public void setProductTypeVersion(String productTypeVersion) {
        this.productTypeVersion = productTypeVersion;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @deprecated The getStatusEnum() should be used instead.
     */
    public String getStatus() {
        return status;
    }

    /**
     * @deprecated The setStatusEnum(ProductTypeEnum productType) should be used instead.
     */
    public void setStatus(String status) {
        this.status = status;
    }

    @DynamoDBIgnore
    public StatusEnum getStatusEnum() {
        return StatusEnum.valueOf(status);
    }

    @DynamoDBIgnore
    public void setStatusEnum(StatusEnum status) {
        this.status = status.name();
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public List<ProductVariation> getVariations() {
        return variations;
    }

    public void setVariations(List<ProductVariation> variations) {
        this.variations = variations;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public List<ProductVariation> getApprovedVariations() {
        return approvedVariations;
    }

    public void setApprovedVariations(List<ProductVariation> approvedVariations) {
        this.approvedVariations = approvedVariations;
    }

    public Date getApprovedAt() {
        return approvedAt;
    }

    public void setApprovedAt(Date approvedAt) {
        this.approvedAt = approvedAt;
    }

    public String getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }


    public static class Id {

        private String hashKey;

        private String rangeKey;

        public Id(String hashKey, String rangeKey) {
            this.hashKey = hashKey;
            this.rangeKey = rangeKey;
        }

        public String getHashKey() {
            return hashKey;
        }

        public void setHashKey(String hashKey) {
            this.hashKey = hashKey;
        }

        public String getRangeKey() {
            return rangeKey;
        }

        public void setRangeKey(String rangeKey) {
            this.rangeKey = rangeKey;
        }

        @Override
        public String toString() {
            return "{ hashKey: " + hashKey + ", rangeKey:" + rangeKey + " }";
        }
    }
}
