package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class StringToAttributeConverter implements AttributeConverter {

    @Override
    public AttributeValue convert(Object o) {
        return new AttributeValue(o.toString());
    }

    @Override
    public Object convert(AttributeValue attribute) {
        return attribute.getS();
    }

    @Override
    public boolean isConvertible(Object o) {
        return o instanceof String;
    }

    @Override
    public boolean isConvertible(AttributeValue attribute) {
        if (attribute.getS() == null) {
            return false;
        }
        return true;
    }
}
