package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.pdm.common.CustomObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class ProductDetailsToAttributeConverter implements DynamoDBTypeConverter<AttributeValue, Map<String, Object>> {

    private static final Logger LOG = LoggerFactory.getLogger(ProductDetailsToAttributeConverter.class);

    private MapToAttributeConverter converter = MapToAttributeConverter.CONVERTER_INSTANCE;

    private ObjectMapper objectMapper = CustomObjectMapper.INSTANCE;

    public ProductDetailsToAttributeConverter() {

    }

    public Map<String, Object> setEmptyStringsToNull(Map<String, Object> map) {
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (entry.getValue() == null) {
                continue;
            }
            if (entry.getValue() instanceof String) {
                if (StringUtils.isEmpty(entry.getValue())) {
                    entry.setValue(null);
                }
            } else if (entry.getValue() instanceof Collection) {
                Collection<Object> collection = (Collection<Object>) entry.getValue();
                collection = collection.stream().filter(o -> o != null).collect(Collectors.toList());
                entry.setValue(collection);
            } else if (entry.getValue() instanceof Map) {
                setEmptyStringsToNull((Map<String, Object>) entry.getValue());
            } else {
                throw new RuntimeException("Unexpected value type = " + entry.getValue().getClass());
            }
        }
        return map;
    }

    public Map<String, Object> removeNullValues(Map<String, Object> map) {
        map.values().removeIf(o -> o == null);
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (entry.getValue() instanceof Map) {
                removeNullValues((Map<String, Object>) entry.getValue());
            }
        }
        return map;
    }

    @Override
    public AttributeValue convert(Map<String, Object> details) {
        if (LOG.isDebugEnabled()) {
            try {
                LOG.debug("DUMP OBJECT BEFORE CONVERT INTO ATTRIBUTE:\r\n{}", objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(details));
            } catch (JsonProcessingException e1) {
                LOG.error("Could not dump object", e1);
            }
        }
        return converter.convert(details);
    }

    @Override
    public Map<String, Object> unconvert(AttributeValue attribute) {
        Map<String, Object> details = (Map<String, Object>) converter.convert(attribute);
        if (LOG.isDebugEnabled()) {
            try {
                LOG.info("DUMP OBJECT AFTER CONVERT BACK FROM ATTRIBUTE:\r\n{}", objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(details));
            } catch (JsonProcessingException e1) {
                LOG.error("Could not dump object", e1);
            }
        }
        return details;
    }
}
