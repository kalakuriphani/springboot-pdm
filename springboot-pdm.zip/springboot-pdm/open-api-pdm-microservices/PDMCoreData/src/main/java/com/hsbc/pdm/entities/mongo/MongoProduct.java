package com.hsbc.pdm.entities.mongo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import com.hsbc.pdm.entities.ProductVariation;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Document(collection = "product")
@CompoundIndexes({ @CompoundIndex(unique = true,
        name = "uix_productName_productTypeInternal_productTypeVersion",
        def = "{ productName : 1, productTypeInternal : 1, productTypeVersion : -1 }") })
public class MongoProduct implements com.hsbc.pdm.entities.Product<ObjectId> {

    @Id
    private ObjectId id;

    @Indexed(name = "ix_productName")
    private String productName;

    @Indexed(name = "ix_productType")
    private String productType;

    @Indexed(name = "ix_productTypeInternal")
    private String productTypeInternal;

    @Indexed(name = "ix_productTypeVersion")
    private String productTypeVersion;

    @Indexed(name = "ix_createdAt")
    private Date createdAt;

    @Indexed(name = "ix_createdBy")
    private String createdBy;

    @Indexed(name = "ix_updatedAt")
    private Date updatedAt;

    @Indexed(name = "ix_updatedBy")
    private String updatedBy;

    @Indexed(name = "ix_approvedAt")
    private Date approvedAt;

    @Indexed(name = "ix_approvedBy")
    private String approvedBy;

    @Indexed(name = "ix_status")
    private String status;

    @Indexed(name = "ix_country")
    private String country;

    private List<ProductVariation> variations;

    private List<ProductVariation> approvedVariations;

    @Version
    private Integer version;


    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    @Override
    public String getProductTypeInternal() {
        return productTypeInternal;
    }

    @Override
    public void setProductTypeInternal(String productType) {
        productTypeInternal = productType;
    }

    @JsonIgnore
    public ProductTypeEnum getProductTypeInternalEnum() {
        return ProductTypeEnum.valueOf(productTypeInternal);
    }

    @JsonIgnore
    public void setProductTypeInternalEnum(ProductTypeEnum productType) {
        this.productTypeInternal = productType.name();
    }

    public String getProductTypeVersion() {
        return productTypeVersion;
    }

    public void setProductTypeVersion(String productTypeVersion) {
        this.productTypeVersion = productTypeVersion;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public Date getApprovedAt() {
        return approvedAt;
    }

    @Override
    public void setApprovedAt(Date approvedAt) {
        this.approvedAt = approvedAt;
    }

    @Override
    public String getApprovedBy() {
        return approvedBy;
    }

    @Override
    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }

    /**
     * @deprecated The getStatusEnum() should be used instead.
     */
    @Deprecated
    public String getStatus() {
        return status;
    }

    /**
     * @deprecated The setStatusEnum(ProductTypeEnum productType) should be used instead.
     */
    @Deprecated
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonIgnore
    public StatusEnum getStatusEnum() {
        return StatusEnum.valueOf(status);
    }

    @JsonIgnore
    public void setStatusEnum(StatusEnum status) {
        this.status = status.name();
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public List<ProductVariation> getVariations() {
        return variations;
    }

    public void setVariations(List<ProductVariation> variations) {
        this.variations = variations;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public List<ProductVariation> getApprovedVariations() {
        return approvedVariations;
    }

    public void setApprovedVariations(List<ProductVariation> approvedVariations) {
        this.approvedVariations = approvedVariations;
    }
}
