package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class MapCollectionToAttributeConverter extends CollectionToAttributeConverter<Map> {

    private MapToAttributeConverter mapToAttributeConverter;

    public MapCollectionToAttributeConverter(MapToAttributeConverter converter) {
        mapToAttributeConverter = converter;
    }

    @Override
    protected Class<Map> getCollectionItemType() {
        return Map.class;
    }

    @Override
    protected List<AttributeValue> convertInternal(Collection<Map> collection) {
        return collection.stream()
                .map(mapToAttributeConverter::convert)
                .collect(Collectors.toList());
    }

    @Override
    protected Collection<Map> convertInternal(List<AttributeValue> attributes) {
        return attributes.stream()
                .map(item -> (Map) mapToAttributeConverter.convert(item))
                .collect(Collectors.toList());
    }

    @Override
    protected boolean isConvertible(List<AttributeValue> attributes) {
        return attributes.get(0).getM() != null;
    }
}
