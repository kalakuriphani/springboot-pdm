/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2016. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.hsbc.pdm.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hsbc.pdm.common.model.ProductTypeEnum;
import com.hsbc.pdm.common.model.StatusEnum;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class ProductTemplate implements Serializable {

    /**
     * <p>
     * <b> TODO : Insert description of the field. </b>
     * </p>
     */
    private static final long serialVersionUID = 1L;


    private ObjectId id;

    private String title;

    private String type;

    private Document schema;

    private Date createdAt;

    private String createdBy;

    private String status;

    private int version;

    /**
     * @return the template
     */
    public Document getSchema() {
        return this.schema;
    }

    /**
     * @param template
     *            the template to set
     */
    public void setSchema(final Document template) {
        this.schema = template;
    }

    /**
     * @return the id
     */
    public ObjectId getId() {
        return this.id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(ObjectId id) {
        this.id = id;
    }


    /**
     * @return the createdAt
     */
    public Date getCreatedAt() {
        return this.createdAt;
    }

    /**
     * @param createdAt
     *            the createdAt to set
     */
    public void setCreatedAt(final Date createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return this.createdBy;
    }

    /**
     * @param createdBy
     *            the createdBy to set
     */
    public void setCreatedBy(final String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @deprecated The getStatusEnum() should be used instead.
     */
    @Deprecated
    public String getStatus() {
        return status;
    }

    /**
     * @deprecated The setStatusEnum(StatusEnum status) should be used instead.
     */
    @Deprecated
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonIgnore
    public StatusEnum getStatusEnum() {
        return StatusEnum.valueOf(status);
    }

    @JsonIgnore
    public void setStatusEnum(StatusEnum status) {
        this.status = status.name();
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return this.title;
    }

    /**
     * @param title
     *            the title to set
     */
    public void setTitle(final String title) {
        this.title = title;
    }

    /**
     * @deprecated The getTypeEnum() should be used instead.
     */
    @Deprecated
    public String getType() {
        return this.type;
    }

    /**
     * @deprecated The setTypeEnum(ProductTypeEnum type) should be used instead.
     */
    @Deprecated
    public void setType(final String type) {
        this.type = type;
    }

    @JsonIgnore
    public ProductTypeEnum getTypeEnum() {
        return ProductTypeEnum.valueOf(type);
    }

    @JsonIgnore
    public void setTypeEnum(ProductTypeEnum type) {
        this.type = type.name();
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }
}
