package com.hsbc.pdm.common;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class UTCDateUtils {

    public static final ZoneId UTC_ZONE = ZoneId.of("UTC");

    private UTCDateUtils() {}

    public static String format(Date date, DateTimeFormatter formatter) {
        return date.toInstant().atZone(UTC_ZONE).format(formatter);
    }

    public static Date parse(String date, DateTimeFormatter formatter) {
        return new Date(LocalDateTime.parse(date, formatter).atZone(UTC_ZONE).toInstant().toEpochMilli());
    }
}
