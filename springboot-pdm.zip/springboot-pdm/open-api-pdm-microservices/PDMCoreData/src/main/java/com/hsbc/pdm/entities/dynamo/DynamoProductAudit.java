package com.hsbc.pdm.entities.dynamo;

import com.amazonaws.services.dynamodbv2.datamodeling.*;
import com.hsbc.pdm.entities.dynamo.marshaller.ObjectPropertyToAttributeConverter;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by 44023148 on 28/02/2017.
 */
@DynamoDBTable(tableName = "pdm-product-audits")
public class DynamoProductAudit implements Serializable {

    public static final String USERNAME_FIELD = "Id";
    public static final String TIMESTAMP_FIELD = "Timestamp";
    public static final String KEYS_FIELD = "Keys";
    public static final String PRODUCT_ID_FIELD = "Id";
    public static final String PRODUCT_TYPE_INTERNAL_FIELD = "ProductTypeInternal";

    @DynamoDBHashKey(attributeName = "Id")
    private String username;

    @DynamoDBRangeKey(attributeName = "Timestamp")
    private Date timestamp;

    @DynamoDBAttribute(attributeName = "EventType")
    private String eventType;

    @DynamoDBAttribute(attributeName = "Keys")
    private ProductKey productKey;

    @DynamoDBAttribute(attributeName = "Entry")
    private DynamoProduct productEntry;

    @DynamoDBAttribute(attributeName = "Difference")
    private List<ProductDifference> productDifferences;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public ProductKey getProductKey() {
        return productKey;
    }

    public void setProductKey(ProductKey productKey) {
        this.productKey = productKey;
    }

    public DynamoProduct getProductEntry() {
        return productEntry;
    }

    public void setProductEntry(DynamoProduct productEntry) {
        this.productEntry = productEntry;
    }

    public List<ProductDifference> getProductDifferences() {
        return productDifferences;
    }

    public void setProductDifferences(List<ProductDifference> productDifferences) {
        this.productDifferences = productDifferences;
    }


    @DynamoDBDocument
    public static class ProductKey {

        @DynamoDBAttribute(attributeName = "Id")
        private String id;

        @DynamoDBAttribute(attributeName = "ProductTypeInternal")
        private String productTypeInternal;

        public ProductKey() {

        }

        public ProductKey(String id, String productTypeInternal) {
            this.id = id;
            this.productTypeInternal = productTypeInternal;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getProductTypeInternal() {
            return productTypeInternal;
        }

        public void setProductTypeInternal(String productTypeInternal) {
            this.productTypeInternal = productTypeInternal;
        }
    }

    @DynamoDBDocument
    public static class ProductDifference {

        @DynamoDBAttribute(attributeName = "at")
        private String propertyPath;

        @DynamoDBAttribute(attributeName = "was")
        @DynamoDBTypeConverted(converter = ObjectPropertyToAttributeConverter.class)
        private Object previousValue;

        @DynamoDBAttribute(attributeName = "now")
        @DynamoDBTypeConverted(converter = ObjectPropertyToAttributeConverter.class)
        private Object currentValue;

        public ProductDifference() {

        }

        public ProductDifference(String propertyPath, Object previousValue, Object currentValue) {
            this.propertyPath = propertyPath;
            this.previousValue = previousValue;
            this.currentValue = currentValue;
        }

        public String getPropertyPath() {
            return propertyPath;
        }

        public void setPropertyPath(String propertyPath) {
            this.propertyPath = propertyPath;
        }

        public Object getPreviousValue() {
            return previousValue;
        }

        public void setPreviousValue(Object previousValue) {
            this.previousValue = previousValue;
        }

        public Object getCurrentValue() {
            return currentValue;
        }

        public void setCurrentValue(Object currentValue) {
            this.currentValue = currentValue;
        }
    }
}
