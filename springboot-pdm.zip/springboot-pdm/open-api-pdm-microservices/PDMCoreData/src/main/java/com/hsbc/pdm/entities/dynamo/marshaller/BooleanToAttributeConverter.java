package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class BooleanToAttributeConverter implements AttributeConverter {

    @Override
    public AttributeValue convert(Object o) {
        return new AttributeValue().withBOOL((Boolean) o);
    }

    @Override
    public Object convert(AttributeValue attribute) {
        return attribute.getBOOL();
    }

    @Override
    public boolean isConvertible(Object o) {
        return o instanceof Boolean;
    }

    @Override
    public boolean isConvertible(AttributeValue attribute) {
        if (attribute.getBOOL() == null) {
            return false;
        }
        return true;
    }
}
