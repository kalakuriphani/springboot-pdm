package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

import java.util.Collection;
import java.util.List;

/**
 * Created by 44023148 on 06/02/2017.
 */
abstract class CollectionToAttributeConverter<T> implements AttributeConverter {

    protected abstract Class<T> getCollectionItemType();

    protected abstract List<AttributeValue> convertInternal(Collection<T> collection);

    protected abstract Collection<T> convertInternal(List<AttributeValue> attributes);

    protected abstract boolean isConvertible(List<AttributeValue> attributes);


    @Override
    public AttributeValue convert(Object o) {
        if (!isConvertible(o)) {
            throw new IllegalArgumentException("Expected collection with items of type " + getCollectionItemType() + ", but was " + o.getClass());
        }
        return new AttributeValue().withL(convertInternal((Collection<T>) o));
    }

    @Override
    public Object convert(AttributeValue attribute) {
        return convertInternal(attribute.getL());
    }

    @Override
    public boolean isConvertible(Object o) {
        if (!(o instanceof Collection)) {
            return false;
        }
        Collection<?> collection = (Collection<?>) o;
        if (collection.size() == 0) {
            return true; // it does not matter the type of the collection as long as it's empty
        }

        // the collection is not empty, find if items are of T type
        return getCollectionItemType().isAssignableFrom(collection.iterator().next().getClass());
    }

    @Override
    public boolean isConvertible(AttributeValue attribute) {
        if (attribute.getL() == null) {
            return false;
        }
        if (attribute.getL().size() == 0) {
            return true; // it does not matter the type of the collection as long as it's empty
        }

        // the collection is not empty, find if items are convertible to T
        return isConvertible(attribute.getL());
    }
}
