package com.hsbc.pdm.entities.dynamo.marshaller;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

/**
 * Created by 44023148 on 06/02/2017.
 */
public class FloatToAttributeConverter implements AttributeConverter {

    @Override
    public AttributeValue convert(Object o) {
        if (!isConvertible(o)) {
            throw new IllegalStateException("Object must be instance of Float");
        }
        return new AttributeValue().withN(o.toString());
    }

    @Override
    public Object convert(AttributeValue attribute) {
        return Float.valueOf(attribute.getN());
    }

    @Override
    public boolean isConvertible(Object o) {
        return o instanceof Float;
    }

    @Override
    public boolean isConvertible(AttributeValue attribute) {
        if (attribute.getN() == null) {
            return false;
        }
        try {
            Float.parseFloat(attribute.getN());
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }
}
