package com.hsbc.pdm.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Created by 44023148 on 15/02/2017.
 */
public class CustomObjectMapper extends ObjectMapper {

    public static final ObjectMapper INSTANCE = new CustomObjectMapper();

    private CustomObjectMapper() {
        configure(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES, true);
        configure(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS, true);
        configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        setSerializationInclusion(JsonInclude.Include.NON_NULL);
        setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
    }
}
